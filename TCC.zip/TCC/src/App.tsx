import './index.css';
import Navbar from '@/components/Navbar';
import Hero from '@/components/Hero';
import Stats from '@/components/Stats';
import About from '@/components/About';
import Calculator from '@/components/Calculator';
import Timeline from '@/components/Timeline';
import Transparency from '@/components/Transparency';
import Incentives from '@/components/Incentives';
import Ranking from '@/components/Ranking';
import FAQ from '@/components/FAQ';
import Footer from '@/components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Navbar />
      <Hero />
      <Stats />
      <About />
      <Calculator />
      <Timeline />
      <Transparency />
      <Incentives />
      <Ranking />
      <FAQ />
      <Footer />
    </div>
  );
}

export default App;
