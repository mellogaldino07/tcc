import React, { useState } from 'react';
import { useInView } from '@/hooks/useAnimations';
import { Mail, CheckCircle2, AlertCircle } from 'lucide-react';
import { isValidEmail } from '@/lib/utils';

const Contact = () => {
  const { ref, inView } = useInView();
  const [submitted, setSubmitted] = useState(false);
  const [emailError, setEmailError] = useState<string | null>(null);

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setEmailError(null);
    const form = e.currentTarget;
    const data = new FormData(form);
    const emailValue = String(data.get('email') || '');

    if (!isValidEmail(emailValue)) {
      setEmailError('E-mail inválido. Informe no formato exemplo@dominio.com');
      return;
    }
    const subject = `Contato sobre o protótipo — ${String(data.get('organizacao') || '')}`;
    const body = [
      `Organização: ${data.get('organizacao')}`,
      `E-mail: ${data.get('email')}`,
      `Tipo: ${data.get('tipo')}`,
      '',
      'Mensagem:',
      data.get('mensagem'),
    ].join('\n');
    window.location.href = `mailto:contato@correntesolidaria.org.br?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    setSubmitted(true);
  };

  return (
    <section id="contact" className="py-20 bg-gradient-to-br from-emerald-600 to-emerald-700 relative overflow-hidden" ref={ref as React.RefObject<HTMLDivElement>}>
      {/* Background decorations */}
      <div className="absolute top-0 left-0 w-full h-full overflow-hidden z-0 opacity-20 pointer-events-none">
        <div className="absolute -top-24 -left-24 w-96 h-96 bg-white rounded-full blur-3xl"></div>
        <div className="absolute bottom-0 right-0 w-full h-full bg-[radial-gradient(ellipse_at_bottom_right,_var(--tw-gradient-stops))] from-white/20 via-transparent to-transparent"></div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          
          <div className={`transition-all duration-700 ${inView ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-8'}`}>
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 leading-tight">
              Cadastre sua organização na rede
            </h2>
            <p className="text-emerald-50 text-lg mb-8 leading-relaxed">
              Use o formulário para preparar uma mensagem no seu aplicativo de e-mail. Nenhum envio é feito diretamente pelo site.
            </p>
            
            <div className="flex items-center gap-3 text-white mb-10 bg-white/10 w-fit px-5 py-3 rounded-full backdrop-blur-sm border border-white/20">
              <Mail className="w-5 h-5 text-emerald-200" />
              <span className="font-medium">contato@correntesolidaria.org.br</span>
            </div>

            <div className="flex flex-wrap gap-3">
              <span className="px-4 py-2 bg-emerald-800/40 text-emerald-100 rounded-full text-sm font-medium border border-emerald-500/30">
                Comércios, entidades beneficentes e parceiros ESG
              </span>
              <span className="px-4 py-2 bg-emerald-800/40 text-emerald-100 rounded-full text-sm font-medium border border-emerald-500/30">
                Alimentos, roupas e logística solidária
              </span>
            </div>
          </div>

          <div className={`transition-all duration-700 delay-200 ${inView ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-8'}`}>
            <div className="bg-white/95 backdrop-blur-md p-8 sm:p-10 rounded-3xl shadow-2xl border border-white/20">
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <label htmlFor="nome" className="block text-sm font-medium text-slate-700 mb-2">Nome da organização</label>
                  <input 
                    type="text" 
                    id="nome"
                    name="organizacao"
                    autoComplete="organization"
                    required
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-colors bg-white/50"
                    placeholder="Ex: Supermercado XYZ"
                  />
                </div>

                <div>
                  <label htmlFor="email" className="block text-sm font-medium text-slate-700 mb-2">Email institucional</label>
                  <input 
                    type="email" 
                    id="email"
                    name="email"
                    autoComplete="email"
                    required
                    onChange={() => setEmailError(null)}
                    className={`w-full px-4 py-3 rounded-xl border focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-colors bg-white/50 ${emailError ? 'border-rose-300' : 'border-slate-200'}`}
                    placeholder="contato@empresa.com.br"
                  />
                </div>

                <div>
                  <label htmlFor="tipo" className="block text-sm font-medium text-slate-700 mb-2">Tipo</label>
                  <select 
                    id="tipo"
                    name="tipo"
                    required
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-colors bg-white/50 appearance-none"
                  >
                    <option value="">Selecione uma opção</option>
                    <option value="comercio">Comércio</option>
                    <option value="ong">ONG / Entidade</option>
                    <option value="esg">Parceiro ESG</option>
                    <option value="outro">Outro</option>
                  </select>
                </div>

                <div>
                  <label htmlFor="mensagem" className="block text-sm font-medium text-slate-700 mb-2">Mensagem</label>
                  <textarea 
                    id="mensagem"
                    name="mensagem"
                    rows={4}
                    required
                    className="w-full px-4 py-3 rounded-xl border border-slate-200 focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500 transition-colors bg-white/50 resize-none"
                    placeholder="Conte um pouco sobre sua operação..."
                  ></textarea>
                </div>

                {emailError && (
                  <div className="p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 shrink-0 text-rose-600" />
                    <span>{emailError}</span>
                  </div>
                )}

                <button 
                  type="submit" 
                  disabled={submitted}
                  className={`w-full py-4 rounded-xl font-bold text-white transition-all flex items-center justify-center gap-2 ${
                    submitted 
                      ? 'bg-emerald-500 hover:bg-emerald-500 cursor-default' 
                      : 'bg-emerald-600 hover:bg-emerald-700 hover:shadow-lg hover:-translate-y-0.5'
                  }`}
                >
                  {submitted ? (
                    <>
                      <CheckCircle2 className="w-5 h-5" />
                      Rascunho preparado no seu e-mail
                    </>
                  ) : (
                    'Preparar e-mail de cadastro'
                  )}
                </button>
                <p className="text-xs text-slate-500 text-center" role="status">
                  {submitted
                    ? 'Seu aplicativo de e-mail deve abrir com a mensagem preenchida. Revise e envie por lá.'
                    : 'O formulário prepara um e-mail para você revisar; seus dados não são enviados pelo site.'}
                </p>
              </form>
            </div>
          </div>

        </div>
      </div>
    </section>
  );
};

export default Contact;
