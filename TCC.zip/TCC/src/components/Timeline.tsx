import React from 'react';
import { FileText, Truck, Scale, BadgeCheck } from 'lucide-react';
import { useInView } from '@/hooks/useAnimations';

const Timeline = () => {
  const { ref, inView } = useInView({ threshold: 0.1 });

  const steps = [
    {
      icon: <FileText className="w-8 h-8 text-emerald-600" />,
      title: 'Registro do lote',
      description: 'O doador cadastra os itens, volume e condições do excedente diretamente na plataforma de forma simples e rápida.'
    },
    {
      icon: <Truck className="w-8 h-8 text-emerald-600" />,
      title: 'Coleta combinada',
      description: 'Doador e organização receptora alinham a melhor logística de retirada e registram a confirmação do transporte.'
    },
    {
      icon: <Scale className="w-8 h-8 text-emerald-600" />,
      title: 'Conferência e triagem',
      description: 'A organização parceira realiza a conferência dos itens recebidos e valida a conformidade e qualidade do lote.'
    },
    {
      icon: <BadgeCheck className="w-8 h-8 text-emerald-600" />,
      title: 'Registro de destinação',
      description: 'A destinação é homologada com geração de comprovante digital para impacto ESG e liberação do cashback.'
    }
  ];

  return (
    <section id="timeline" className="py-20 bg-white">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Como funciona o fluxo</h2>
          <p className="text-lg text-slate-600 max-w-3xl mx-auto">
            Etapas estruturadas e integradas para garantir agilidade, transparência e segurança em cada doação realizada.
          </p>
        </div>

        <div 
          ref={ref as React.RefObject<HTMLDivElement>} 
          className={`transition-all duration-1000 transform ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'}`}
        >
          <div className="relative">
            {/* Connection Line */}
            <div className="hidden md:block absolute top-12 left-0 w-full h-1 bg-emerald-100 -z-10"></div>
            <div className="md:hidden absolute top-0 left-6 h-full w-1 bg-emerald-100 -z-10"></div>

            <div className="flex flex-col md:flex-row gap-8 md:gap-4">
              {steps.map((step, index) => (
                <div key={index} className="flex-1 relative flex flex-col items-start md:items-center">
                  <div className="flex items-center justify-center w-12 h-12 rounded-full bg-emerald-500 text-white font-bold text-xl mb-4 shadow-lg ring-4 ring-white md:mx-auto transition-transform duration-300 hover:scale-110">
                    {index + 1}
                  </div>
                  
                  <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 shadow-sm hover:shadow-xl hover:border-emerald-200 hover:-translate-y-1.5 transition-all duration-300 w-full md:text-center group">
                    <div className="bg-emerald-50 w-16 h-16 rounded-2xl flex items-center justify-center mb-4 md:mx-auto group-hover:bg-emerald-600 group-hover:text-white transition-all duration-300 shadow-sm group-hover:shadow-md">
                      {React.cloneElement(step.icon, {
                        className: 'w-8 h-8 text-emerald-600 group-hover:text-white transition-colors duration-300'
                      })}
                    </div>
                    <h3 className="text-lg font-bold text-slate-900 mb-2 group-hover:text-emerald-800 transition-colors">{step.title}</h3>
                    <p className="text-slate-600 text-sm leading-relaxed">
                      {step.description}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Timeline;
