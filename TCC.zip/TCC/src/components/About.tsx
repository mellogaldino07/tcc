import React from 'react';
import {
  CheckCircle2,
  Building2,
  Heart,
  TrendingUp,
  Award,
  Coins,
  ShieldCheck,
  Target,
  ArrowRight,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useInView } from '@/hooks/useAnimations';

export default function About() {
  const { ref, inView } = useInView({ threshold: 0.1 });

  const differentials = [
    'Conexão direta entre comércios doadores e ONGs homologadas.',
    'Doações e vendas sociais de alimentos, roupas e cosméticos.',
    'Planos de anuidade para comércios com retorno garantido em cashback.',
    'Metas de solidariedade com recompensas em dinheiro e selos ESG.',
    'Rankings mensal e anual com pontuação por impacto social.',
  ];

  return (
    <section id="about" className="py-20 bg-slate-50 border-b border-slate-200/60">
      <div className="container mx-auto px-4 max-w-6xl">
        <div
          ref={ref as React.RefObject<HTMLDivElement>}
          className={`transition-all duration-1000 transform ${
            inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
          } flex flex-col lg:flex-row gap-12 items-center`}
        >
          {/* Lado Esquerdo: Apresentação da Plataforma */}
          <div className="flex-1 space-y-6">
            <div>
              <span className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold tracking-wide uppercase mb-3">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                Como a Plataforma Funciona
              </span>
              <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 leading-tight tracking-tight">
                Transformando excedentes em dignidade, benefícios e desenvolvimento
              </h2>
            </div>

            <div className="space-y-4 text-base md:text-lg text-slate-600 leading-relaxed">
              <p>
                O desperdício de alimentos, roupas e cosméticos pode se transformar na maior rede de impacto do país. A <strong className="text-slate-900 font-semibold">Corrente Solidária</strong> conecta o comércio varejista diretamente a ONGs e instituições de acolhimento socialmente auditadas.
              </p>
              <p className="text-sm md:text-base text-slate-600">
                Através de planos de anuidade acessíveis, sua empresa destina produtos que seriam descartados, conquista retorno financeiro através de cashback direto em cada lote entregue e sobe de posição nos rankings de sustentabilidade.
              </p>
            </div>

            <ul className="space-y-3 pt-2">
              {differentials.map((item, index) => (
                <li key={index} className="flex items-start gap-3">
                  <div className="p-1 rounded-full bg-emerald-100 text-emerald-700 shrink-0 mt-0.5">
                    <CheckCircle2 className="w-4 h-4" />
                  </div>
                  <span className="text-slate-700 text-sm md:text-base font-medium">{item}</span>
                </li>
              ))}
            </ul>

            <div className="pt-2">
              <Link
                to="/login"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-sm transition-all shadow-md shadow-emerald-700/20"
              >
                Cadastrar meu negócio na rede
                <ArrowRight className="w-4 h-4" />
              </Link>
            </div>
          </div>

          {/* Lado Direito: Substituição dos 3 cards genéricos por Informações Reais da Plataforma */}
          <div className="flex-1 w-full max-w-lg">
            <div className="relative rounded-3xl overflow-hidden bg-gradient-to-br from-emerald-800 via-emerald-700 to-teal-900 p-6 sm:p-8 text-white shadow-2xl border border-emerald-600/30">
              {/* Efeitos de iluminação */}
              <div className="absolute top-0 right-0 w-72 h-72 bg-white/10 rounded-full blur-3xl pointer-events-none" />
              <div className="absolute bottom-0 left-0 w-72 h-72 bg-teal-400/10 rounded-full blur-3xl pointer-events-none" />

              <div className="relative z-10 space-y-4">
                <div className="border-b border-emerald-600/50 pb-3">
                  <span className="text-xs uppercase tracking-wider font-bold text-emerald-300">
                    Ecossistema Completo
                  </span>
                  <h3 className="text-xl font-black text-white mt-0.5">
                    Os 4 Pilares da Corrente Solidária
                  </h3>
                </div>

                {/* Card 1: Conexão Comércio ⇄ ONG */}
                <div className="bg-white/10 hover:bg-white/15 backdrop-blur-md rounded-2xl p-4 border border-white/15 transition-all">
                  <div className="flex items-start gap-3.5">
                    <div className="p-2.5 rounded-xl bg-emerald-500/30 border border-emerald-300/30 text-emerald-200 shrink-0">
                      <Building2 className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-white flex items-center gap-1.5">
                        Conexão Comércios ⇄ ONGs
                        <span className="text-[10px] bg-emerald-400/20 text-emerald-200 px-2 py-0.5 rounded-full font-semibold">
                          Doações & Vendas
                        </span>
                      </h4>
                      <p className="text-xs text-emerald-100/90 mt-1 leading-relaxed">
                        Destinação ágil de alimentos perecíveis, lotes de vestuário e cosméticos com transporte e triagem organizados.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Card 2: Planos & Cashback */}
                <div className="bg-white/10 hover:bg-white/15 backdrop-blur-md rounded-2xl p-4 border border-white/15 transition-all">
                  <div className="flex items-start gap-3.5">
                    <div className="p-2.5 rounded-xl bg-amber-500/30 border border-amber-300/30 text-amber-200 shrink-0">
                      <Coins className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-white flex items-center gap-1.5">
                        Planos de Anuidade & Cashback
                        <span className="text-[10px] bg-amber-400/20 text-amber-200 px-2 py-0.5 rounded-full font-semibold">
                          Até 8% de Retorno
                        </span>
                      </h4>
                      <p className="text-xs text-emerald-100/90 mt-1 leading-relaxed">
                        Comércios assinantes acumulam saldo de cashback socioambiental proporcional ao valor estimado de cada entrega concluída.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Card 3: Metas & Recompensas */}
                <div className="bg-white/10 hover:bg-white/15 backdrop-blur-md rounded-2xl p-4 border border-white/15 transition-all">
                  <div className="flex items-start gap-3.5">
                    <div className="p-2.5 rounded-xl bg-teal-500/30 border border-teal-300/30 text-teal-200 shrink-0">
                      <Target className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-white flex items-center gap-1.5">
                        Metas Solidárias & Recompensas
                        <span className="text-[10px] bg-teal-400/20 text-teal-200 px-2 py-0.5 rounded-full font-semibold">
                          Badges & Bônus
                        </span>
                      </h4>
                      <p className="text-xs text-emerald-100/90 mt-1 leading-relaxed">
                        Ao atingir metas de peso doado ou famílias atendidas, seu comércio desbloqueia troféus digitais e bônus financeiros.
                      </p>
                    </div>
                  </div>
                </div>

                {/* Card 4: Ranking Mensal & Anual */}
                <div className="bg-white/10 hover:bg-white/15 backdrop-blur-md rounded-2xl p-4 border border-white/15 transition-all">
                  <div className="flex items-start gap-3.5">
                    <div className="p-2.5 rounded-xl bg-indigo-500/30 border border-indigo-300/30 text-indigo-200 shrink-0">
                      <Award className="w-5 h-5" />
                    </div>
                    <div>
                      <h4 className="font-bold text-sm text-white flex items-center gap-1.5">
                        Rankings Mensal & Anual
                        <span className="text-[10px] bg-indigo-400/20 text-indigo-200 px-2 py-0.5 rounded-full font-semibold">
                          Visibilidade ESG
                        </span>
                      </h4>
                      <p className="text-xs text-emerald-100/90 mt-1 leading-relaxed">
                        Pontuação pública e transparente que reconhece as empresas com maior impacto na comunidade e atrai clientes conscientes.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
