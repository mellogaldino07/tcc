import React from 'react';
import { Recycle, Mail, MapPin, ExternalLink, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-slate-900 text-white">
      {/* CTA Section */}
      <div className="bg-gradient-to-r from-emerald-800 via-emerald-700 to-teal-800 py-16">
        <div className="max-w-4xl mx-auto text-center px-4">
          <h2 className="text-3xl md:text-4xl font-extrabold mb-4 text-white tracking-tight">
            Pronto para levar governança e solidariedade ao seu negócio?
          </h2>
          <p className="text-emerald-100 text-base md:text-lg mb-8 max-w-2xl mx-auto leading-relaxed">
            Conecte sua empresa diretamente a ONGs receptoras, reduza perdas, acumule cashback socioambiental e fortaleça o posicionamento ESG da sua marca.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link
              to="/login"
              className="inline-flex items-center justify-center gap-2 px-8 py-4 bg-white text-emerald-800 font-bold rounded-xl hover:bg-emerald-50 transition-all duration-300 shadow-lg hover:shadow-xl text-sm"
            >
              <span>Cadastrar minha organização</span>
              <ArrowRight className="w-4 h-4 text-emerald-700" />
            </Link>
            <Link
              to="/login"
              className="inline-flex items-center justify-center px-8 py-4 border-2 border-white/60 text-white font-semibold rounded-xl hover:bg-white/10 transition-all duration-300 text-sm"
            >
              Acessar plataforma
            </Link>
          </div>
        </div>
      </div>

      {/* Footer Content */}
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Brand */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-emerald-600 rounded-lg flex items-center justify-center">
                <Recycle className="w-5 h-5 text-white" />
              </div>
              <span className="text-xl font-bold">CorrenteSolidária</span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed">
              Plataforma de intermediação entre comércio e entidades beneficentes para doações e vendas sociais com governança e cashback.
            </p>
          </div>

          {/* Navigation */}
          <div>
            <h3 className="text-sm font-semibold text-emerald-400 uppercase tracking-wider mb-4">
              Navegação
            </h3>
            <ul className="space-y-3">
              {[
                { label: 'Quem Somos', href: '#about' },
                { label: 'Calculadora de Impacto', href: '#calculator' },
                { label: 'Fluxo de Doação', href: '#timeline' },
                { label: 'Transparência & Conformidade', href: '#transparency' },
                { label: 'Ranking Solidário', href: '#ranking' },
              ].map((item) => (
                <li key={item.href}>
                  <a
                    href={item.href}
                    className="text-slate-400 hover:text-emerald-400 transition-colors text-sm"
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="text-sm font-semibold text-emerald-400 uppercase tracking-wider mb-4">
              Conformidade Legal
            </h3>
            <ul className="space-y-3">
              {[
                'Lei nº 15.224/2025 (Doação e Segurança Alimentar)',
                'Marco Regulatório do Terceiro Setor',
              ].map((item) => (
                <li key={item}>
                  <a
                    href="https://www.planalto.gov.br"
                    target="_blank"
                    rel="noreferrer"
                    className="text-slate-400 hover:text-emerald-400 transition-colors text-sm inline-flex items-center gap-1"
                  >
                    {item}
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-sm font-semibold text-emerald-400 uppercase tracking-wider mb-4">
              Contato Institucional
            </h3>
            <div className="space-y-3">
              <a
                href="mailto:contato@correntesolidaria.org.br"
                className="text-slate-400 hover:text-emerald-400 transition-colors text-sm flex items-center gap-2"
              >
                <Mail className="w-4 h-4 text-emerald-400" />
                contato@correntesolidaria.org.br
              </a>
              <p className="text-slate-400 text-xs flex items-start gap-2 leading-relaxed">
                <MapPin className="w-4 h-4 mt-0.5 flex-shrink-0 text-emerald-400" />
                Central de atendimento integrada para comércios, doadores e instituições receptoras.
              </p>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-slate-800 mt-12 pt-8 text-center">
          <p className="text-slate-500 text-sm">
            © {currentYear} Corrente Solidária — Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  );
}
