import { useState } from 'react';
import { CheckCircle2, Circle, Search, Truck } from 'lucide-react';

type Stage = { title: string; detail: string; done: boolean; date: string };
type Lot = { id: string; item: string; quantity: string; origin: string; destination: string; status: string; stages: Stage[] };

const lots: Lot[] = [
  { id: 'CS-2026-001', item: 'Hortifruti variado', quantity: '120 kg', origin: 'Mercado Exemplo · São Paulo, SP', destination: 'Instituição Exemplo · São Paulo, SP', status: 'Entregue · exemplo', stages: [
    { title: 'Doação registrada', detail: 'Itens e quantidade informados pelo doador.', date: '02/10/2026 · exemplo', done: true },
    { title: 'Coleta confirmada', detail: 'Recebimento do lote pela organização receptora.', date: '03/10/2026 · exemplo', done: true },
    { title: 'Triagem e conferência', detail: 'Conferência de quantidade e condições dos itens.', date: '03/10/2026 · exemplo', done: true },
    { title: 'Destinação registrada', detail: 'Encerramento demonstrativo do fluxo do lote.', date: '04/10/2026 · exemplo', done: true },
  ] },
  { id: 'CS-2026-002', item: 'Alimentos não perecíveis', quantity: '85 kg', origin: 'Mercado Exemplo · São Paulo, SP', destination: 'Instituição Exemplo · São Paulo, SP', status: 'Em triagem · exemplo', stages: [
    { title: 'Doação registrada', detail: 'Itens e quantidade informados pelo doador.', date: '08/10/2026 · exemplo', done: true },
    { title: 'Coleta confirmada', detail: 'Recebimento do lote pela organização receptora.', date: '09/10/2026 · exemplo', done: true },
    { title: 'Triagem e conferência', detail: 'Etapa ilustrativa aguardando atualização de exemplo.', date: 'Pendente · exemplo', done: false },
    { title: 'Destinação registrada', detail: 'Etapa ilustrativa ainda não concluída.', date: 'Pendente · exemplo', done: false },
  ] },
  { id: 'CS-2026-003', item: 'Roupas em bom estado', quantity: '42 peças', origin: 'Loja Exemplo · Campinas, SP', destination: 'Instituição Exemplo · Campinas, SP', status: 'Aguardando coleta · exemplo', stages: [
    { title: 'Doação registrada', detail: 'Itens e quantidade informados pelo doador.', date: '09/10/2026 · exemplo', done: true },
    { title: 'Coleta confirmada', detail: 'Etapa ilustrativa aguardando atualização de exemplo.', date: 'Pendente · exemplo', done: false },
    { title: 'Triagem e conferência', detail: 'Etapa ilustrativa ainda não iniciada.', date: 'Pendente · exemplo', done: false },
    { title: 'Destinação registrada', detail: 'Etapa ilustrativa ainda não concluída.', date: 'Pendente · exemplo', done: false },
  ] },
];

export default function Tracker() {
  const [query, setQuery] = useState('CS-2026-001');
  const [lot, setLot] = useState<Lot | null>(lots[0]);
  const [error, setError] = useState('');

  function search(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const found = lots.find((entry) => entry.id.toLowerCase() === query.trim().toLowerCase());
    setLot(found ?? null);
    setError(found ? '' : 'Não encontramos esse código entre os lotes de exemplo. Tente CS-2026-001, CS-2026-002 ou CS-2026-003.');
  }

  return (
    <section id="tracking" className="py-20 bg-slate-50 scroll-mt-24">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-10">
          <span className="inline-flex items-center gap-2 rounded-full border border-amber-200 bg-amber-50 px-3 py-1 text-sm font-semibold text-amber-800">Demonstração com dados fictícios</span>
          <h2 className="mt-4 text-3xl md:text-4xl font-bold text-slate-900">Consulta de rastreio</h2>
          <p className="mt-3 text-lg text-slate-600">Pesquise um código e veja como poderia ser apresentada a evolução de um lote. Os registros abaixo não representam doações reais.</p>
        </div>

        <form onSubmit={search} className="max-w-2xl mx-auto flex flex-col sm:flex-row gap-3 mb-8">
          <label className="sr-only" htmlFor="tracking-code">Código do lote</label>
          <input id="tracking-code" value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Ex.: CS-2026-001" className="min-w-0 flex-1 rounded-xl border border-slate-300 bg-white px-4 py-3 text-slate-900" />
          <button className="inline-flex items-center justify-center gap-2 rounded-xl bg-emerald-700 px-6 py-3 font-semibold text-white hover:bg-emerald-800"><Search className="w-5 h-5" /> Consultar</button>
        </form>
        {error && <p role="alert" className="mb-6 text-center text-sm text-red-700">{error}</p>}

        {lot && <article className="rounded-3xl border border-slate-200 bg-white p-6 sm:p-8 shadow-sm">
          <div className="flex flex-col md:flex-row md:items-start md:justify-between gap-5 border-b border-slate-100 pb-6">
            <div>
              <p className="font-mono text-sm font-semibold text-emerald-800">{lot.id}</p>
              <h3 className="mt-2 text-2xl font-bold text-slate-900">{lot.item}</h3>
              <p className="mt-1 text-slate-600">Quantidade: <strong>{lot.quantity}</strong></p>
            </div>
            <span className="inline-flex w-fit items-center gap-2 rounded-full bg-emerald-50 px-3 py-2 text-sm font-semibold text-emerald-800"><Truck className="w-4 h-4" />{lot.status}</span>
          </div>
          <div className="grid sm:grid-cols-2 gap-4 py-5 border-b border-slate-100 text-sm">
            <p><span className="block text-slate-500">Origem</span><strong className="text-slate-800">{lot.origin}</strong></p>
            <p><span className="block text-slate-500">Destino</span><strong className="text-slate-800">{lot.destination}</strong></p>
          </div>
          <ol className="mt-6 space-y-5">
            {lot.stages.map((stage) => <li key={stage.title} className="flex gap-4">
              <span className="mt-0.5 shrink-0">{stage.done ? <CheckCircle2 className="w-6 h-6 text-emerald-600" /> : <Circle className="w-6 h-6 text-slate-300" />}</span>
              <div className="flex-1 border-b border-slate-100 pb-4 last:border-0">
                <div className="flex flex-col sm:flex-row sm:justify-between gap-1">
                  <h4 className="font-semibold text-slate-900">{stage.title}</h4><span className="text-xs text-slate-500">{stage.date}</span>
                </div>
                <p className="mt-1 text-sm text-slate-600">{stage.detail}</p>
              </div>
            </li>)}
          </ol>
        </article>}
        <p className="mt-5 text-center text-xs text-slate-500">Protótipo estático: não consulta QR Code, blockchain, banco de dados ou atualizações em tempo real.</p>
      </div>
    </section>
  );
}
