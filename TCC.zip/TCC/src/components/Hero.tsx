import React from 'react';
import { CheckCircle, Package, Truck, QrCode, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

const Hero = () => {
  return (
    <section id="hero" className="relative min-h-screen flex items-center bg-gradient-to-br from-emerald-50 via-white to-sky-50 overflow-hidden pt-20">
      {/* Animated Background Blobs */}
      <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-emerald-200/35 rounded-full mix-blend-screen filter blur-3xl opacity-70 animate-blob"></div>
      <div className="absolute top-1/3 right-1/4 w-96 h-96 bg-sky-200/40 rounded-full mix-blend-screen filter blur-3xl opacity-70 animate-blob animation-delay-2000"></div>
      <div className="absolute -bottom-32 left-1/2 w-96 h-96 bg-lime-200/30 rounded-full mix-blend-screen filter blur-3xl opacity-70 animate-blob animation-delay-4000"></div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
        <div className="flex flex-col lg:flex-row items-center justify-between gap-12">
          {/* Text Content */}
          <div className="flex-1 text-center lg:text-left space-y-8 fade-in-up">
            <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wide">
              Rede Oficial de Solidariedade Comercial
            </div>

            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-extrabold text-slate-900 leading-tight tracking-tight">
              Conecte seu comércio a ONGs com <span className="text-emerald-700">cashback e impacto ESG.</span>
            </h1>
            <p className="text-lg sm:text-xl text-slate-600 max-w-2xl mx-auto lg:mx-0 fade-in-up" style={{ animationDelay: '0.2s' }}>
              Destine excedentes de alimentos, vestuário e cosméticos com segurança jurídica, ganhe cashback em cada entrega e suba nos rankings de responsabilidade socioambiental.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start space-y-4 sm:space-y-0 sm:space-x-4 fade-in-up" style={{ animationDelay: '0.4s' }}>
              <a
                href="#calculator"
                className="w-full sm:w-auto px-8 py-3.5 text-base font-bold rounded-xl bg-emerald-700 text-white hover:bg-emerald-800 transition-all shadow-lg shadow-emerald-700/25 text-center flex items-center justify-center gap-2"
              >
                Simular Impacto & Cashback
                <ArrowRight className="w-4 h-4" />
              </a>
              <Link
                to="/login"
                className="w-full sm:w-auto px-8 py-3.5 text-base font-bold rounded-xl border-2 border-emerald-700 text-emerald-800 hover:bg-emerald-50 transition-colors text-center"
              >
                Cadastrar Organização
              </Link>
            </div>
          </div>

          {/* Floating Tracking Card */}
          <div className="flex-1 w-full max-w-md fade-in-up" style={{ animationDelay: '0.6s' }}>
            <div className="bg-white border border-emerald-100 rounded-3xl p-6 sm:p-7 shadow-2xl relative">
              <div className="flex items-center justify-between border-b border-slate-100 pb-4 mb-5">
                <div className="flex items-center space-x-3">
                  <div className="p-2.5 bg-emerald-50 rounded-xl text-emerald-700">
                    <QrCode className="h-6 w-6" />
                  </div>
                  <div>
                    <h3 className="text-slate-900 font-bold text-sm sm:text-base">Lote CS-2026-089</h3>
                    <p className="text-xs text-slate-500">Supermercado Esperança ➔ ONG Prato Cheio</p>
                  </div>
                </div>
                <div className="px-2.5 py-1 bg-emerald-100 text-emerald-800 text-xs font-bold rounded-full">
                  Ativo
                </div>
              </div>

              <div className="space-y-5 relative before:absolute before:inset-0 before:ml-[1.125rem] before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-emerald-100">
                {/* Step 1 */}
                <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                  <div className="flex items-center justify-center w-9 h-9 rounded-full border-4 border-white bg-emerald-600 text-white shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 shadow absolute left-0 md:left-1/2 -translate-x-1/2">
                    <Package className="h-4 w-4" />
                  </div>
                  <div className="w-[calc(100%-3rem)] md:w-[calc(50%-2rem)] ml-12 md:ml-0 p-3.5 rounded-xl border border-slate-100 bg-slate-50">
                    <div className="flex items-center justify-between mb-0.5">
                      <h4 className="text-xs font-bold text-emerald-800">Doação Cadastrada</h4>
                    </div>
                    <p className="text-[11px] text-slate-600">140 kg hortifrúti fresco</p>
                  </div>
                </div>

                {/* Step 2 */}
                <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                  <div className="flex items-center justify-center w-9 h-9 rounded-full border-4 border-white bg-emerald-600 text-white shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 shadow absolute left-0 md:left-1/2 -translate-x-1/2">
                    <Truck className="h-4 w-4" />
                  </div>
                  <div className="w-[calc(100%-3rem)] md:w-[calc(50%-2rem)] ml-12 md:ml-0 p-3.5 rounded-xl border border-slate-100 bg-slate-50">
                    <div className="flex items-center justify-between mb-0.5">
                      <h4 className="text-xs font-bold text-emerald-800">Transporte em Rota</h4>
                    </div>
                    <p className="text-[11px] text-slate-600">Coleta com veículo refrigerado</p>
                  </div>
                </div>

                {/* Step 3 */}
                <div className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                  <div className="flex items-center justify-center w-9 h-9 rounded-full border-4 border-white bg-emerald-600 text-white shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2 shadow absolute left-0 md:left-1/2 -translate-x-1/2">
                    <CheckCircle className="h-4 w-4" />
                  </div>
                  <div className="w-[calc(100%-3rem)] md:w-[calc(50%-2rem)] ml-12 md:ml-0 p-3.5 rounded-xl border border-emerald-100 bg-emerald-50/70">
                    <h4 className="text-xs font-bold text-emerald-900">Entrega & Cashback</h4>
                    <p className="text-[11px] text-emerald-700">R$ 35,70 creditados · +70 pts ranking</p>
                  </div>
                </div>
              </div>

              <div className="mt-5 pt-3 border-t border-slate-100 text-center">
                <p className="text-xs text-slate-500 font-medium">
                  Rastreamento digital de ponta a ponta com laudo ESG
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style dangerouslySetInnerHTML={{__html: `
        @keyframes blob {
          0% { transform: translate(0px, 0px) scale(1); }
          33% { transform: translate(30px, -50px) scale(1.1); }
          66% { transform: translate(-20px, 20px) scale(0.9); }
          100% { transform: translate(0px, 0px) scale(1); }
        }
        .animate-blob { animation: blob 7s infinite; }
        .animation-delay-2000 { animation-delay: 2s; }
        .animation-delay-4000 { animation-delay: 4s; }
        
        @keyframes fadeInUp {
          from { opacity: 0; transform: translateY(20px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .fade-in-up {
          animation: fadeInUp 0.8s ease-out forwards;
          opacity: 0;
        }
      `}} />
    </section>
  );
};

export default Hero;
