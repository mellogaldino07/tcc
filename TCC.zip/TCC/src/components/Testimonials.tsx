import React from 'react';
import { Quote, Star } from 'lucide-react';
import { useInView } from '@/hooks/useAnimations';

const testimonials = [
  {
    quote: 'A certificação por lote resolveu a insegurança jurídica. Hoje nossa diretoria acompanha impacto, destino e retorno financeiro sem planilhas paralelas.',
    author: 'Diretoria Operacional',
    company: 'Rede Varejista Regional'
  },
  {
    quote: 'Recebemos doações mais previsíveis e com triagem inicial. Isso reduziu perdas e ajudou nossa equipe a atender famílias com mais dignidade.',
    author: 'Coordenação de Projetos',
    company: 'ONG de Assistência Social'
  },
  {
    quote: 'O ranking deu visibilidade real para pequenos mercados do bairro. A comunidade passou a reconhecer quem doa de forma constante.',
    author: 'Liderança Comunitária',
    company: 'Associação de Bairro'
  }
];

const Testimonials = () => {
  const { ref, inView } = useInView();

  return (
    <section id="testimonials" className="py-20 bg-slate-50" ref={ref as React.RefObject<HTMLDivElement>}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`text-center transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Operação social com prova, clareza e recorrência</h2>
          <p className="text-lg text-slate-400 max-w-3xl mx-auto mb-16">
            Relatos simulados de perfis que representam comércios, entidades e associações parceiras da plataforma.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((item, idx) => (
            <div 
              key={idx} 
              className={`bg-white p-8 rounded-2xl border border-slate-100 border-l-4 border-l-emerald-500 shadow-sm relative transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
              style={{ transitionDelay: `${idx * 200}ms` }}
            >
              <Quote className="w-10 h-10 text-emerald-500/20 absolute top-6 right-6" />
              <div className="flex gap-1 mb-6">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star key={star} className="w-5 h-5 fill-emerald-500 text-emerald-500" />
                ))}
              </div>
              <p className="text-slate-300 leading-relaxed mb-8 relative z-10 italic">
                "{item.quote}"
              </p>
              <div>
                <p className="text-slate-900 font-bold">{item.author}</p>
                <p className="text-emerald-500 text-sm">{item.company}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
