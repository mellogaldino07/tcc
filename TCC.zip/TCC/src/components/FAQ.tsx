import React from 'react';
import * as Accordion from '@radix-ui/react-accordion';
import { ChevronDown } from 'lucide-react';
import { useInView } from '@/hooks/useAnimations';

const faqs = [
  {
    q: 'Como funciona o processo de doação?',
    a: 'O comércio parceiro cadastra os lotes de excedentes (alimentos, roupas ou cosméticos) na plataforma. As ONGs homologadas mais próximas recebem o alerta, confirmam o interesse e realizam a coleta no local com registro digital.'
  },
  {
    q: 'Como funciona o cashback socioambiental?',
    a: 'Em cada lote entregue e validado pela instituição receptora, um percentual do valor estimado da mercadoria (2% no plano Básico, 5% no Profissional e 8% no Premium) retorna diretamente como crédito financeiro em conta e pontuação no ranking solidário.'
  },
  {
    q: 'Como as ONGs são homologadas?',
    a: 'Todas as entidades parceiras passam por triagem cadastral rigorosa, checagem documental (estatuto, ata e CNPJ ativo) e validação da capacidade física para armazenamento e distribuição segura dos itens recebidos.'
  },
  {
    q: 'O sistema atende às diretrizes de conformidade e LGPD?',
    a: 'Sim, seguimos as melhores práticas de privacidade de dados conforme a LGPD e documentamos toda a trilha de movimentação dos lotes com segurança jurídica e auditoria transparente.'
  },
  {
    q: 'Posso acompanhar o destino e o impacto das minhas doações?',
    a: 'Sim. Cada lote possui comprovante de destinação e métricas em tempo real no dashboard da empresa, detalhando famílias beneficiadas, quilos de alimentos ou peças doadas e emissões de CO2 evitadas.'
  },
  {
    q: 'Quais são os planos para os comércios participarem?',
    a: 'Oferecemos três planos de anuidade adaptados ao tamanho do comércio: Básico (2% de cashback), Profissional (5% de cashback) e Premium (8% de cashback), com suporte operacional e emissão de selos ESG de sustentabilidade.'
  }
];

const FAQ = () => {
  const { ref, inView } = useInView();

  return (
    <section id="faq" className="py-20 bg-white" ref={ref as React.RefObject<HTMLDivElement>}>
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`text-center transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">Perguntas frequentes</h2>
          <p className="text-lg text-slate-600 mb-12">
            Tudo o que você precisa saber sobre o funcionamento, retorno em cashback e impacto da Corrente Solidária.
          </p>
        </div>

        <div className={`transition-all duration-700 delay-200 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <Accordion.Root type="single" collapsible className="space-y-4">
            {faqs.map((item, idx) => (
              <Accordion.Item 
                key={idx} 
                value={`item-${idx}`}
                className="bg-slate-50 border border-slate-200/80 rounded-2xl overflow-hidden transition-all duration-200 data-[state=open]:border-emerald-500 data-[state=open]:bg-white data-[state=open]:shadow-md"
              >
                <Accordion.Header>
                  <Accordion.Trigger className="w-full px-6 py-5 flex items-center justify-between text-left font-semibold text-slate-900 hover:text-emerald-700 transition-colors [&[data-state=open]>svg]:rotate-180">
                    <span className="text-base sm:text-lg">{item.q}</span>
                    <ChevronDown className="w-5 h-5 text-slate-400 shrink-0 transition-transform duration-200" />
                  </Accordion.Trigger>
                </Accordion.Header>
                <Accordion.Content className="px-6 pb-6 text-slate-600 text-sm sm:text-base leading-relaxed animate-accordion-down">
                  {item.a}
                </Accordion.Content>
              </Accordion.Item>
            ))}
          </Accordion.Root>
        </div>
      </div>
    </section>
  );
};

export default FAQ;
