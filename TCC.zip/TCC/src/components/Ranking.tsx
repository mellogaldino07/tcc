import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useInView } from '@/hooks/useAnimations';
import { Medal, Trophy, Building2, Heart, TrendingUp, Sparkles, Loader2, AlertCircle, Award } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';

interface RankingEntry {
  ranking_id: number;
  posicao: number;
  pontos: number;
  total_doacoes: number;
  total_valor: number;
  periodo: string;
  tipo_periodo: string;
  usuario_id: number;
  usuario_nome: string;
  avatar_url?: string;
  usuario_tipo: string;
  comercio_id?: number;
  ong_id?: number;
  razao_social: string;
  categoria?: string;
  cidade?: string;
  estado?: string;
  plano_nome?: string;
  destaque_ranking?: number;
}

const getMedalStyle = (index: number) => {
  if (index === 0) return 'text-amber-500 fill-amber-400 drop-shadow-[0_2px_4px_rgba(245,158,11,0.3)]';
  if (index === 1) return 'text-slate-400 fill-slate-300 drop-shadow-[0_2px_4px_rgba(148,163,184,0.3)]';
  if (index === 2) return 'text-amber-700 fill-amber-600 drop-shadow-[0_2px_4px_rgba(180,83,9,0.3)]';
  return 'text-slate-300';
};

const COMERCIOS_FALLBACK: RankingEntry[] = [
  {
    ranking_id: 1,
    posicao: 1,
    pontos: 450,
    total_doacoes: 5,
    total_valor: 890,
    periodo: '2026-11',
    tipo_periodo: 'mensal',
    usuario_id: 1,
    usuario_nome: 'Supermercado Esperança',
    usuario_tipo: 'comercio',
    razao_social: 'Supermercado Esperança Ltda',
    categoria: 'supermercado',
    cidade: 'São Paulo',
    estado: 'SP',
    plano_nome: 'Profissional',
    destaque_ranking: 1,
  },
  {
    ranking_id: 2,
    posicao: 2,
    pontos: 320,
    total_doacoes: 3,
    total_valor: 650,
    periodo: '2026-11',
    tipo_periodo: 'mensal',
    usuario_id: 3,
    usuario_nome: 'Padaria Pão Dourado',
    usuario_tipo: 'comercio',
    razao_social: 'Panificadora Pão Dourado ME',
    categoria: 'padaria',
    cidade: 'São Paulo',
    estado: 'SP',
    plano_nome: 'Básico',
    destaque_ranking: 0,
  },
  {
    ranking_id: 3,
    posicao: 3,
    pontos: 210,
    total_doacoes: 2,
    total_valor: 400,
    periodo: '2026-11',
    tipo_periodo: 'mensal',
    usuario_id: 4,
    usuario_nome: 'Boutique Moda Sustentável',
    usuario_tipo: 'comercio',
    razao_social: 'Boutique Moda Sustentável Eireli',
    categoria: 'loja_roupas',
    cidade: 'São Paulo',
    estado: 'SP',
    plano_nome: 'Premium',
    destaque_ranking: 1,
  },
];

const ONGS_FALLBACK: RankingEntry[] = [
  {
    ranking_id: 10,
    posicao: 1,
    pontos: 510,
    total_doacoes: 6,
    total_valor: 1200,
    periodo: '2026-11',
    tipo_periodo: 'mensal',
    usuario_id: 2,
    usuario_nome: 'Instituto Prato Cheio',
    usuario_tipo: 'ong',
    razao_social: 'Instituto Prato Cheio de Assistência Social',
    categoria: 'alimentacao',
    cidade: 'São Paulo',
    estado: 'SP',
  },
  {
    ranking_id: 11,
    posicao: 2,
    pontos: 380,
    total_doacoes: 4,
    total_valor: 900,
    periodo: '2026-11',
    tipo_periodo: 'mensal',
    usuario_id: 5,
    usuario_nome: 'Instituto Mãos que Acolhem',
    usuario_tipo: 'ong',
    razao_social: 'Instituto Mãos que Acolhem de Assistência Social',
    categoria: 'Acolhimento Social',
    cidade: 'São Paulo',
    estado: 'SP',
  },
  {
    ranking_id: 12,
    posicao: 3,
    pontos: 290,
    total_doacoes: 3,
    total_valor: 650,
    periodo: '2026-11',
    tipo_periodo: 'mensal',
    usuario_id: 6,
    usuario_nome: 'Ação Solidária Regional',
    usuario_tipo: 'ong',
    razao_social: 'Associação Ação Solidária Regional',
    categoria: 'Apoio Comunitário',
    cidade: 'Porto Alegre',
    estado: 'RS',
  },
  {
    ranking_id: 13,
    posicao: 4,
    pontos: 190,
    total_doacoes: 2,
    total_valor: 420,
    periodo: '2026-11',
    tipo_periodo: 'mensal',
    usuario_id: 7,
    usuario_nome: 'Rede do Bem Comunitário',
    usuario_tipo: 'ong',
    razao_social: 'Rede do Bem Comunitário Brasil',
    categoria: 'Distribuição Direta',
    cidade: 'Fortaleza',
    estado: 'CE',
  },
  {
    ranking_id: 14,
    posicao: 5,
    pontos: 140,
    total_doacoes: 2,
    total_valor: 310,
    periodo: '2026-11',
    tipo_periodo: 'mensal',
    usuario_id: 8,
    usuario_nome: 'Casa de Apoio Fraterno',
    usuario_tipo: 'ong',
    razao_social: 'Casa de Apoio Fraterno Amparo Social',
    categoria: 'Centro de Apoio',
    cidade: 'Manaus',
    estado: 'AM',
  },
];

const Ranking = () => {
  const { ref, inView } = useInView();
  const { user } = useAuth();

  const [activeTab, setActiveTab] = useState<'geral' | 'mensal'>('mensal');
  const [comerciosList, setComerciosList] = useState<RankingEntry[]>(COMERCIOS_FALLBACK);
  const [ongsList, setOngsList] = useState<RankingEntry[]>(ONGS_FALLBACK);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Armazena posições do usuário logado se ele estiver classificado fora do top 5
  const [minhaPosicao, setMinhaPosicao] = useState<{
    posicao: number;
    pontos: number;
    pontosFaltantesParaTop5: number;
  } | null>(null);

  const activeTabRef = useRef(activeTab);
  activeTabRef.current = activeTab;

  const userRef = useRef(user);
  userRef.current = user;

  // Busca dados de ranking para o tipo especificado
  const fetchRankings = useCallback(async (isInitial = false) => {
    if (isInitial) setLoading(true);
    try {
      const periodoQuery = activeTabRef.current === 'geral' ? 'anual' : 'mensal';

      // Buscar top 5 de comércios e ONGs
      const [resComercios, resOngs] = await Promise.all([
        fetch(`http://localhost:3001/api/ranking?perfil=comercio&periodo=${periodoQuery}&limite=5`),
        fetch(`http://localhost:3001/api/ranking?perfil=ong&periodo=${periodoQuery}&limite=5`)
      ]);

      if (!resComercios.ok || !resOngs.ok) {
        throw new Error('Falha ao obter ranking da API');
      }

      const dataComercios = await resComercios.json();
      const dataOngs = await resOngs.json();

      setComerciosList((dataComercios.ranking && dataComercios.ranking.length > 0) ? dataComercios.ranking : COMERCIOS_FALLBACK);
      setOngsList((dataOngs.ranking && dataOngs.ranking.length > 0) ? dataOngs.ranking : ONGS_FALLBACK);
      setError(null);

      // Verificar posição do usuário logado se ele existir
      const currentUser = userRef.current;
      if (currentUser && currentUser.id) {
        const perfilUser = currentUser.tipo === 'ong' ? 'ong' : 'comercio';
        // Buscar até 100 posições para encontrar o usuário se estiver fora do top 5
        const resUserRanking = await fetch(
          `http://localhost:3001/api/ranking?perfil=${perfilUser}&periodo=${periodoQuery}&limite=100`
        );
        if (resUserRanking.ok) {
          const userRankingData = await resUserRanking.json();
          const allRanked: RankingEntry[] = userRankingData.ranking || [];
          const userEntry = allRanked.find((r) => String(r.usuario_id) === String(currentUser.id));

          if (userEntry) {
            if (userEntry.posicao > 5) {
              const top5Entry = allRanked[4]; // 5º colocado
              const pontosTop5 = top5Entry ? top5Entry.pontos : 0;
              const faltam = Math.max(1, (pontosTop5 - userEntry.pontos) + 1);
              setMinhaPosicao({
                posicao: userEntry.posicao,
                pontos: userEntry.pontos,
                pontosFaltantesParaTop5: faltam
              });
            } else {
              setMinhaPosicao(null);
            }
          } else {
            setMinhaPosicao(null);
          }
        }
      } else {
        setMinhaPosicao(null);
      }
    } catch (err: unknown) {
      console.warn('Ranking offline ou erro de busca:', err);
      setComerciosList((prev) => (prev.length > 0 ? prev : COMERCIOS_FALLBACK));
      setOngsList((prev) => (prev.length > 0 ? prev : ONGS_FALLBACK));
      // Não exibe alerta incômodo se já temos os dados de demonstração
      setError(null);
    } finally {
      if (isInitial) setLoading(false);
    }
  }, []);

  // Fetch ao mudar a aba (Mensal vs Geral)
  useEffect(() => {
    fetchRankings(true);
  }, [activeTab, fetchRankings]);

  // Conexão SSE com fallback para polling a cada 15 segundos
  useEffect(() => {
    let eventSource: EventSource | null = null;
    let pollingInterval: ReturnType<typeof setInterval> | null = null;
    let isMounted = true;

    const iniciarPolling = () => {
      if (pollingInterval) return;
      pollingInterval = setInterval(() => {
        if (isMounted) {
          fetchRankings(false);
        }
      }, 15000);
    };

    const pararPolling = () => {
      if (pollingInterval) {
        clearInterval(pollingInterval);
        pollingInterval = null;
      }
    };

    try {
      eventSource = new EventSource(`http://localhost:3001/api/ranking/stream`);

      eventSource.addEventListener('ranking-atualizado', (event) => {
        try {
          const payload = JSON.parse(event.data);
          const periodoTab = activeTabRef.current === 'geral' ? 'anual' : 'mensal';
          if (payload.tipo_periodo === periodoTab) {
            fetchRankings(false);
          }
        } catch {
          fetchRankings(false);
        }
      });

      eventSource.onerror = () => {
        // Fallback para polling quando a conexão SSE cair
        iniciarPolling();
      };

      eventSource.onopen = () => {
        // SSE funcionando, encerra polling
        pararPolling();
      };
    } catch {
      iniciarPolling();
    }

    return () => {
      isMounted = false;
      if (eventSource) {
        eventSource.close();
      }
      pararPolling();
    };
  }, [fetchRankings]);

  // Calcula maior pontuação para definir largura da barra de progresso relativa
  const maxPontosComercios = comerciosList.length > 0 ? Math.max(...comerciosList.map((c) => c.pontos), 1) : 1;
  const maxPontosOngs = ongsList.length > 0 ? Math.max(...ongsList.map((o) => o.pontos), 1) : 1;

  const isUserEntry = (entry: RankingEntry) => {
    return user && String(user.id) === String(entry.usuario_id);
  };

  return (
    <section id="ranking" className="py-20 bg-slate-50/70" ref={ref as React.RefObject<HTMLDivElement>}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Cabeçalho */}
        <div className={`text-center max-w-4xl mx-auto mb-12 transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-3">
            <Trophy className="w-4 h-4 text-emerald-700" />
            Ranking Solidário em Tempo Real
          </span>
          <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight mb-4">
            Reconhecimento aberto aos comércios mais engajados e às entidades com maior capacidade de acolhimento
          </h2>
          <p className="text-slate-600 text-base md:text-lg max-w-2xl mx-auto">
            Acompanhe o impacto acumulado e celebre as organizações líderes em solidariedade socioambiental.
          </p>

          {/* Seletor de Período / Filtro com animação */}
          <div className="inline-flex p-1 bg-white border border-slate-200 rounded-2xl shadow-sm mt-6">
            <button
              type="button"
              onClick={() => setActiveTab('mensal')}
              className={`px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all duration-300 ${
                activeTab === 'mensal'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Ranking Mensal
            </button>
            <button
              type="button"
              onClick={() => setActiveTab('geral')}
              className={`px-5 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all duration-300 ${
                activeTab === 'geral'
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50'
              }`}
            >
              Geral Acumulado
            </button>
          </div>
        </div>

        {/* Estado de Carregando Inicial */}
        {loading && (
          <div className="flex flex-col items-center justify-center py-20 text-emerald-700 space-y-3">
            <Loader2 className="w-10 h-10 animate-spin text-emerald-600" />
            <p className="text-sm font-semibold text-slate-600">Atualizando classificações em tempo real...</p>
          </div>
        )}

        {/* Estado de Erro de Conexão */}
        {!loading && error && (
          <div className="max-w-md mx-auto mb-8 p-4 rounded-2xl bg-amber-50 border border-amber-200 text-amber-800 text-sm flex items-center gap-3">
            <AlertCircle className="w-5 h-5 text-amber-600 shrink-0" />
            <span>{error} Tentando reconectar automaticamente.</span>
          </div>
        )}

        {/* Tabelas de Ranking */}
        {!loading && (
          <div className="flex flex-col lg:flex-row gap-8">
            {/* Card Comércios */}
            <div
              className={`flex-1 bg-white p-6 sm:p-8 rounded-3xl shadow-md border border-slate-200/80 transition-all duration-700 delay-100 ${
                inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
            >
              <div className="flex items-center justify-between pb-6 mb-6 border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-50 flex items-center justify-center text-emerald-700">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-slate-900">Comércios Destaque</h3>
                    <p className="text-xs text-slate-500">Volume e pontuação em doações destinadas</p>
                  </div>
                </div>
                <span className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-50 text-emerald-700 text-xs font-bold rounded-full border border-emerald-100">
                  <TrendingUp className="w-3.5 h-3.5" />
                  Top Doadores
                </span>
              </div>

              {comerciosList.length === 0 ? (
                <div className="py-12 text-center text-slate-400">
                  <Building2 className="w-12 h-12 mx-auto mb-2 text-slate-300 stroke-[1.5]" />
                  <p className="text-sm font-medium">Ainda sem doações neste {activeTab === 'mensal' ? 'mês' : 'ano'}.</p>
                  <p className="text-xs text-slate-400 mt-1">Seja o primeiro comércio a pontuar!</p>
                </div>
              ) : (
                <ul className="space-y-3.5">
                  {comerciosList.map((item, idx) => {
                    const isUser = isUserEntry(item);
                    const pct = Math.min(100, Math.round((item.pontos / maxPontosComercios) * 100));

                    return (
                      <li
                        key={item.ranking_id || idx}
                        className={`group relative flex flex-col p-4 rounded-2xl border transition-all duration-500 overflow-hidden ${
                          isUser
                            ? 'border-emerald-500 bg-emerald-50/80 shadow-md ring-2 ring-emerald-500/20'
                            : 'border-slate-100 bg-white hover:border-emerald-300 hover:shadow-xl hover:bg-gradient-to-r hover:from-emerald-50/70 hover:via-white hover:to-emerald-50/30 hover:-translate-y-1 hover:scale-[1.01]'
                        }`}
                      >
                        {/* Barra de progresso proporcional */}
                        <div
                          className="absolute bottom-0 left-0 h-1 bg-emerald-500/30 group-hover:bg-emerald-500 transition-all duration-500"
                          style={{ width: `${pct}%` }}
                        />

                        <div className="flex items-center justify-between gap-4">
                          <div className="flex items-center gap-3.5 sm:gap-4">
                            {/* Posição / Medalha */}
                            <div className="relative flex items-center justify-center w-8 h-8 shrink-0">
                              {idx < 3 ? (
                                <Medal
                                  className={`w-7 h-7 ${getMedalStyle(
                                    idx
                                  )} group-hover:scale-125 group-hover:rotate-12 transition-transform duration-300`}
                                />
                              ) : (
                                <span className="w-7 h-7 flex items-center justify-center rounded-xl bg-slate-100 text-slate-600 font-black text-sm group-hover:bg-emerald-100 group-hover:text-emerald-700 transition-colors">
                                  {item.posicao || idx + 1}º
                                </span>
                              )}
                            </div>

                            <div>
                              <div className="flex items-center gap-2 flex-wrap">
                                <p className="font-bold text-slate-900 text-sm sm:text-base group-hover:text-emerald-900 transition-colors">
                                  {item.razao_social || item.usuario_nome}
                                </p>
                                {idx === 0 && (
                                  <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 text-[10px] font-extrabold uppercase">
                                    <Sparkles className="w-3 h-3 text-amber-600" />
                                    Líder
                                  </span>
                                )}
                                {isUser && (
                                  <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-extrabold uppercase">
                                    Você
                                  </span>
                                )}
                                {Boolean(item.destaque_ranking) && (
                                  <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-semibold bg-indigo-50 text-indigo-700 border border-indigo-200">
                                    {item.plano_nome || 'Destaque'}
                                  </span>
                                )}
                              </div>
                              <div className="flex items-center gap-2 mt-0.5">
                                <span className="text-xs text-slate-500">
                                  {item.cidade ? `${item.cidade}, ${item.estado || 'BR'}` : 'Brasil'}
                                </span>
                                <span className="text-slate-300">•</span>
                                <span className="text-[11px] font-semibold text-slate-400 group-hover:text-emerald-700 transition-colors capitalize">
                                  {item.categoria || 'Comércio'}
                                </span>
                              </div>
                            </div>
                          </div>

                          {/* Pontuação */}
                          <div className="text-right shrink-0">
                            <div className="font-extrabold text-emerald-700 bg-emerald-50 group-hover:bg-emerald-600 group-hover:text-white px-3.5 py-1.5 rounded-xl text-xs sm:text-sm border border-emerald-100 group-hover:border-emerald-600 shadow-xs transition-all duration-300">
                              {item.pontos} pts
                            </div>
                            <div className="text-[10px] text-slate-400 mt-1">
                              {item.total_doacoes} {item.total_doacoes === 1 ? 'doação' : 'doações'}
                            </div>
                          </div>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}

              {/* Card de posição do usuário logado (comércio) fora do top 5 */}
              {user && user.tipo === 'comercio' && minhaPosicao && (
                <div className="mt-5 p-4 rounded-2xl bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 text-emerald-900 flex items-center justify-between shadow-xs">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-sm">
                      {minhaPosicao.posicao}º
                    </div>
                    <div>
                      <div className="text-xs font-bold uppercase tracking-wider text-emerald-700">Sua Posição</div>
                      <div className="text-sm font-extrabold text-slate-900">
                        Nº {minhaPosicao.posicao} ({minhaPosicao.pontos} pts)
                      </div>
                    </div>
                  </div>
                  <div className="text-right text-xs">
                    <span className="font-bold text-emerald-800">Faltam {minhaPosicao.pontosFaltantesParaTop5} pts</span>
                    <span className="block text-[11px] text-slate-500">para entrar no top 5</span>
                  </div>
                </div>
              )}
            </div>

            {/* Card ONGs */}
            <div
              className={`flex-1 bg-white p-6 sm:p-8 rounded-3xl shadow-md border border-slate-200/80 transition-all duration-700 delay-200 ${
                inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
              }`}
            >
              <div className="flex items-center justify-between pb-6 mb-6 border-b border-slate-100">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-2xl bg-emerald-50 flex items-center justify-center text-emerald-700">
                    <Heart className="w-5 h-5 text-rose-500" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-slate-900">ONGs Receptoras</h3>
                    <p className="text-xs text-slate-500">Capacidade de acolhimento e distribuição</p>
                  </div>
                </div>
                <span className="inline-flex items-center gap-1 px-3 py-1 bg-emerald-50 text-emerald-700 text-xs font-bold rounded-full border border-emerald-100">
                  <Heart className="w-3.5 h-3.5 text-rose-500 fill-rose-500" />
                  Rede Ativa
                </span>
              </div>

              {ongsList.length === 0 ? (
                <div className="py-12 text-center text-slate-400">
                  <Heart className="w-12 h-12 mx-auto mb-2 text-slate-300 stroke-[1.5]" />
                  <p className="text-sm font-medium">Ainda sem doações concluídas neste {activeTab === 'mensal' ? 'mês' : 'ano'}.</p>
                  <p className="text-xs text-slate-400 mt-1">Conclua entregas para classificar sua ONG!</p>
                </div>
              ) : (
                <ul className="space-y-3.5">
                  {ongsList.map((item, idx) => {
                    const isUser = isUserEntry(item);
                    const pct = Math.min(100, Math.round((item.pontos / maxPontosOngs) * 100));

                    return (
                      <li
                        key={item.ranking_id || idx}
                        className={`group relative flex flex-col p-4 rounded-2xl border transition-all duration-500 overflow-hidden ${
                          isUser
                            ? 'border-emerald-500 bg-emerald-50/80 shadow-md ring-2 ring-emerald-500/20'
                            : 'border-slate-100 bg-white hover:border-emerald-300 hover:shadow-xl hover:bg-gradient-to-r hover:from-emerald-50/70 hover:via-white hover:to-emerald-50/30 hover:-translate-y-1 hover:scale-[1.01]'
                        }`}
                      >
                        {/* Barra de progresso proporcional */}
                        <div
                          className="absolute bottom-0 left-0 h-1 bg-emerald-500/30 group-hover:bg-emerald-500 transition-all duration-500"
                          style={{ width: `${pct}%` }}
                        />

                        <div className="flex items-center justify-between gap-4">
                          <div className="flex items-center gap-3.5 sm:gap-4">
                            {/* Posição / Medalha */}
                            <div className="relative flex items-center justify-center w-8 h-8 shrink-0">
                              {idx < 3 ? (
                                <Medal
                                  className={`w-7 h-7 ${getMedalStyle(
                                    idx
                                  )} group-hover:scale-125 group-hover:rotate-12 transition-transform duration-300`}
                                />
                              ) : (
                                <span className="w-7 h-7 flex items-center justify-center rounded-xl bg-slate-100 text-slate-600 font-black text-sm group-hover:bg-emerald-100 group-hover:text-emerald-700 transition-colors">
                                  {item.posicao || idx + 1}º
                                </span>
                              )}
                            </div>

                            <div>
                              <div className="flex items-center gap-2 flex-wrap">
                                <p className="font-bold text-slate-900 text-sm sm:text-base group-hover:text-emerald-900 transition-colors">
                                  {item.razao_social || item.usuario_nome}
                                </p>
                                {idx === 0 && (
                                  <span className="inline-flex items-center gap-0.5 px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 text-[10px] font-extrabold uppercase">
                                    <Sparkles className="w-3 h-3 text-amber-600" />
                                    Destaque
                                  </span>
                                )}
                                {isUser && (
                                  <span className="inline-flex items-center px-2 py-0.5 rounded-md bg-emerald-600 text-white text-[10px] font-extrabold uppercase">
                                    Sua ONG
                                  </span>
                                )}
                              </div>
                              <div className="flex items-center gap-2 mt-0.5">
                                <span className="text-xs text-slate-500">
                                  {item.cidade ? `${item.cidade}, ${item.estado || 'BR'}` : 'Brasil'}
                                </span>
                                <span className="text-slate-300">•</span>
                                <span className="text-[11px] font-semibold text-slate-400 group-hover:text-emerald-700 transition-colors capitalize">
                                  {item.categoria || 'Assistência Social'}
                                </span>
                              </div>
                            </div>
                          </div>

                          {/* Pontuação */}
                          <div className="text-right shrink-0">
                            <div className="font-extrabold text-emerald-700 bg-emerald-50 group-hover:bg-emerald-600 group-hover:text-white px-3.5 py-1.5 rounded-xl text-xs sm:text-sm border border-emerald-100 group-hover:border-emerald-600 shadow-xs transition-all duration-300">
                              {item.pontos} pts
                            </div>
                            <div className="text-[10px] text-slate-400 mt-1">
                              {item.total_doacoes} {item.total_doacoes === 1 ? 'recebimento' : 'recebimentos'}
                            </div>
                          </div>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}

              {/* Card de posição do usuário logado (ONG) fora do top 5 */}
              {user && user.tipo === 'ong' && minhaPosicao && (
                <div className="mt-5 p-4 rounded-2xl bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 text-emerald-900 flex items-center justify-between shadow-xs">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-sm">
                      {minhaPosicao.posicao}º
                    </div>
                    <div>
                      <div className="text-xs font-bold uppercase tracking-wider text-emerald-700">Sua Posição</div>
                      <div className="text-sm font-extrabold text-slate-900">
                        Nº {minhaPosicao.posicao} ({minhaPosicao.pontos} pts)
                      </div>
                    </div>
                  </div>
                  <div className="text-right text-xs">
                    <span className="font-bold text-emerald-800">Faltam {minhaPosicao.pontosFaltantesParaTop5} pts</span>
                    <span className="block text-[11px] text-slate-500">para entrar no top 5</span>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </section>
  );
};

export default Ranking;
