import React, { useState, useEffect } from 'react';
import { Recycle, Menu, X, LogIn, LayoutDashboard } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

const Navbar = () => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { isAuthenticated, user } = useAuth();

  useEffect(() => {
    const handleScroll = () => setIsMobileMenuOpen(false);
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { name: 'Quem somos', href: '#about' },
    { name: 'Calculadora', href: '#calculator' },
    { name: 'Fluxo', href: '#timeline' },
    { name: 'Transparência', href: '#transparency' },
    { name: 'Ranking', href: '#ranking' },
    { name: 'FAQ', href: '#faq' },
  ];

  const handleNavClick = (e: React.MouseEvent<HTMLAnchorElement>, href: string) => {
    e.preventDefault();
    const target = document.querySelector(href);
    if (target) {
      target.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
  };

  return (
    <nav className="fixed w-full z-50 bg-white/95 shadow-sm py-3 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center">
          {/* Logo */}
          <a
            href="#hero"
            onClick={(e) => handleNavClick(e, '#hero')}
            aria-label="Corrente Solidária — início"
            className="flex items-center space-x-2 rounded-md focus-visible:outline-emerald-600"
          >
            <Recycle className="h-8 w-8 text-emerald-600" />
            <span className="text-xl font-bold text-slate-900">CorrenteSolidária</span>
          </a>

          {/* Desktop Nav */}
          <div className="hidden lg:flex items-center space-x-6">
            <div className="flex space-x-5">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  href={link.href}
                  onClick={(e) => handleNavClick(e, link.href)}
                  className="text-sm font-medium text-slate-600 transition-colors hover:text-emerald-600"
                >
                  {link.name}
                </a>
              ))}
            </div>

            {/* Ações de Autenticação */}
            <div className="flex items-center space-x-3">
              {isAuthenticated ? (
                <Link
                  to="/dashboard"
                  className="inline-flex items-center gap-2 px-4 py-2 text-sm font-bold rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100 transition-all shadow-xs"
                >
                  <LayoutDashboard className="w-4 h-4 text-emerald-700" />
                  <span>Painel ({user?.razao_social ? user.razao_social.split(' ')[0] : user?.nome ? user.nome.split(' ')[0] : 'Painel'})</span>
                </Link>
              ) : (
                <>
                  <Link
                    to="/login"
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 text-sm font-semibold rounded-xl text-slate-700 hover:text-emerald-700 hover:bg-slate-50 transition-colors"
                  >
                    <LogIn className="w-4 h-4 text-emerald-600" />
                    <span>Entrar</span>
                  </Link>

                  <Link
                    to="/login"
                    className="px-4 py-2 text-sm font-bold rounded-xl bg-emerald-700 text-white hover:bg-emerald-800 transition-all shadow-sm hover:shadow-md"
                  >
                    Cadastrar organização
                  </Link>
                </>
              )}
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="lg:hidden flex items-center">
            <button
              type="button"
              aria-label={isMobileMenuOpen ? 'Fechar menu' : 'Abrir menu'}
              aria-expanded={isMobileMenuOpen}
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-slate-900 focus:outline-none p-1 rounded-md"
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Nav */}
      {isMobileMenuOpen && (
        <div className="lg:hidden bg-white shadow-xl absolute top-full left-0 w-full border-t border-slate-100">
          <div className="px-4 pt-3 pb-5 space-y-2">
            {navLinks.map((link) => (
              <a
                key={link.name}
                href={link.href}
                onClick={(e) => handleNavClick(e, link.href)}
                className="block px-3 py-2 text-base font-medium text-slate-700 hover:text-emerald-600 hover:bg-slate-50 rounded-md"
              >
                {link.name}
              </a>
            ))}

            <div className="mt-4 pt-4 border-t border-slate-200 flex flex-col space-y-2">
              {isAuthenticated ? (
                <Link
                  to="/dashboard"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="flex items-center justify-center gap-2 w-full px-4 py-2.5 text-center text-sm font-bold rounded-lg bg-emerald-50 text-emerald-800 border border-emerald-200"
                >
                  <LayoutDashboard className="w-4 h-4 text-emerald-700" />
                  Ir para Meu Painel ({user?.razao_social ? user.razao_social.split(' ')[0] : user?.nome ? user.nome.split(' ')[0] : 'Painel'})
                </Link>
              ) : (
                <>
                  <Link
                    to="/login"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="flex items-center justify-center gap-2 w-full px-4 py-2.5 text-center text-sm font-semibold rounded-lg border border-emerald-600 text-emerald-700 hover:bg-emerald-50"
                  >
                    <LogIn className="w-4 h-4" />
                    Entrar na plataforma
                  </Link>

                  <Link
                    to="/login"
                    onClick={() => setIsMobileMenuOpen(false)}
                    className="block w-full px-4 py-2.5 text-center text-sm font-semibold rounded-lg bg-emerald-700 text-white hover:bg-emerald-800"
                  >
                    Cadastrar organização
                  </Link>
                </>
              )}
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
