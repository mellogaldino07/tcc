import React from 'react';
import { ClipboardCheck, MapPinned, BarChart3 } from 'lucide-react';
import { useInView } from '@/hooks/useAnimations';

const ideas = [
  {
    icon: <ClipboardCheck className="w-8 h-8 text-emerald-700" />,
    title: 'Comprovantes de operação',
    desc: 'Armazenamento digital seguro de registros, comprovantes de entrega e documentação de cada lote movimentado.',
  },
  {
    icon: <MapPinned className="w-8 h-8 text-emerald-700" />,
    title: 'Rede de organizações homologadas',
    desc: 'Localização inteligente e conexão direta com instituições receptoras auditadas e comunidades atendidas por região.',
  },
  {
    icon: <BarChart3 className="w-8 h-8 text-emerald-700" />,
    title: 'Relatórios baseados em dados',
    desc: 'Métricas consolidadas de impacto social, redução da pegada de carbono e destinação transparente para relatórios ESG.',
  },
];

export default function Incentives() {
  const { ref, inView } = useInView();

  return (
    <section id="incentives" className="py-20 bg-slate-50/60" ref={ref as React.RefObject<HTMLDivElement>}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className={`text-center transition-all duration-700 ${inView ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <span className="inline-flex rounded-full bg-emerald-100 border border-emerald-200 px-3.5 py-1 text-xs font-bold uppercase tracking-wider text-emerald-800">
            Recursos da Plataforma
          </span>
          <h2 className="mt-4 text-3xl md:text-4xl font-extrabold text-slate-900 mb-4">
            Recursos que dão suporte à sua operação
          </h2>
          <p className="text-base md:text-lg text-slate-600 max-w-3xl mx-auto mb-12">
            Ferramentas integradas para facilitar a gestão de lotes, auditoria social e geração de relatórios com total eficiência.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {ideas.map((item) => (
            <article
              key={item.title}
              className="bg-white p-7 rounded-2xl shadow-sm border border-slate-200/80 hover:shadow-xl hover:border-emerald-300 hover:-translate-y-1.5 transition-all duration-300 group"
            >
              <div className="w-14 h-14 bg-emerald-50 rounded-2xl flex items-center justify-center mb-5 group-hover:bg-emerald-600 transition-colors duration-300 shadow-sm">
                {React.cloneElement(item.icon, {
                  className: 'w-7 h-7 text-emerald-700 group-hover:text-white transition-colors duration-300',
                })}
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3 group-hover:text-emerald-800 transition-colors">
                {item.title}
              </h3>
              <p className="text-slate-600 leading-relaxed text-sm">
                {item.desc}
              </p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
