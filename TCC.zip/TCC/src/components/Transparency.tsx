import { BookOpenCheck, ClipboardList, Scale } from 'lucide-react';

const sources = [
  { title: 'Lei nº 15.224/2025 — Política Nacional de Combate à Perda e ao Desperdício de Alimentos', href: 'https://www.planalto.gov.br/ccivil_03/_ato2023-2026/2025/lei/l15224.htm' },
  { title: 'Lei nº 14.016/2020 — revogada pela Lei nº 15.224/2025', href: 'https://www.planalto.gov.br/ccivil_03/_ato2019-2022/2020/lei/l14016.htm' },
];

const features = [
  { icon: <ClipboardList className="w-8 h-8 text-emerald-700" />, title: 'Registros claros', description: 'O sistema mantém registros detalhados de quantidade, responsáveis e etapas, garantindo conformidade e integridade no processo de destinação.' },
  { icon: <Scale className="w-8 h-8 text-emerald-700" />, title: 'Regras e Conformidade', description: 'A Lei nº 15.224/2025 instituiu a política nacional de combate ao desperdício. As regras sanitárias, tributárias e locais são observadas em cada operação.' },
  { icon: <BookOpenCheck className="w-8 h-8 text-emerald-700" />, title: 'Segurança Jurídica', description: 'Todas as operações são pautadas nas normas vigentes para doação com segurança jurídica e incentivos socioambientais.' },
];

export default function Transparency() {
  return (
    <section id="transparency" className="py-20 bg-emerald-50 text-slate-900">
      <div className="container mx-auto px-4 max-w-6xl">
        <div className="text-center mb-12">
          <span className="inline-flex rounded-full bg-white border border-emerald-100 px-3 py-1 text-sm font-semibold text-emerald-800">Informação e transparência</span>
          <h2 className="mt-4 text-3xl md:text-4xl font-bold mb-4">Rastreabilidade e Conformidade</h2>
          <p className="text-lg text-slate-600 max-w-4xl mx-auto">Um registro completo de movimentação documenta todas as etapas operacionais em conformidade com as exigências sanitárias e regulatórias.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
          {features.map((feature) => <article key={feature.title} className="bg-white p-7 rounded-2xl border border-emerald-100 shadow-sm hover:shadow-lg hover:border-emerald-200 transition-all">
            <div className="bg-emerald-50 w-14 h-14 rounded-xl flex items-center justify-center mb-5">{feature.icon}</div>
            <h3 className="text-lg font-bold text-slate-900 mb-2">{feature.title}</h3>
            <p className="text-slate-600 leading-relaxed">{feature.description}</p>
          </article>)}
        </div>
        <div className="max-w-4xl mx-auto bg-white rounded-2xl p-6 md:p-8 border border-emerald-100 shadow-sm">
          <h3 className="text-lg font-bold text-slate-900 mb-3">Fontes oficiais consultadas</h3>
          <p className="text-sm text-slate-600 mb-4">A Lei nº 15.224/2025 criou a Política Nacional de Combate à Perda e ao Desperdício de Alimentos, revogando a Lei nº 14.016/2020. A aplicação prática segue as normas sanitárias e regulamentos vigentes.</p>
          <ul className="space-y-2">{sources.map((source) => <li key={source.href}><a href={source.href} target="_blank" rel="noreferrer" className="text-sm font-medium text-emerald-800 underline decoration-emerald-300 underline-offset-4 hover:text-emerald-950">{source.title}</a></li>)}</ul>
        </div>
      </div>
    </section>
  );
}
