import { HeartHandshake, Users, ShieldCheck, Coins } from 'lucide-react';

const items = [
  { icon: HeartHandshake, label: 'Excedentes salvos e destinados', value: '+18.500 kg' },
  { icon: Users, label: 'Famílias atendidas mensalmente', value: '+4.200' },
  { icon: ShieldCheck, label: 'ONGs homologadas e auditadas', value: '100%' },
  { icon: Coins, label: 'Cashback socioambiental gerado', value: '+R$ 45.000' },
];

export default function Stats() {
  return (
    <section id="stats" className="py-12 bg-gradient-to-r from-emerald-800 via-emerald-700 to-teal-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <p className="text-center text-xs font-bold uppercase tracking-wider text-emerald-200 mb-6">
          Impacto Consolidado da Corrente Solidária
        </p>
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {items.map(({ icon: Icon, label, value }) => (
            <div
              key={label}
              className="flex items-center gap-4 p-5 bg-white/10 hover:bg-white/15 backdrop-blur-md rounded-2xl border border-white/15 shadow-sm hover:shadow-md transition-all duration-300 transform hover:-translate-y-1"
            >
              <div className="p-3 rounded-xl bg-white/15 text-emerald-200">
                <Icon className="h-6 w-6 text-emerald-200" />
              </div>
              <div>
                <p className="text-xl sm:text-2xl font-black text-white">{value}</p>
                <p className="text-xs text-emerald-100 font-medium">{label}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
