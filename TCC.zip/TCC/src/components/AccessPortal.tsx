import React from 'react';
import { LogIn, Building2, Heart, ArrowRight, ShieldCheck, CheckCircle2, LayoutDashboard } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

export default function AccessPortal() {
  const { isAuthenticated, user } = useAuth();

  return (
    <section id="access" className="py-20 bg-slate-50/60 scroll-mt-24 border-y border-slate-200/60">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto text-center mb-12">
          <span className="inline-flex items-center gap-2 px-3.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-semibold border border-emerald-200">
            <ShieldCheck className="w-4 h-4 text-emerald-700" />
            Portal Oficial de Acesso
          </span>
          <h2 className="mt-4 text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Área de acesso às organizações
          </h2>
          <p className="mt-3 text-slate-600 text-base max-w-2xl mx-auto">
            Acesse o sistema unificado para gerenciar lotes de alimentos, emitir comprovantes fiscais e acompanhar as etapas de entrega com segurança.
          </p>
        </div>

        {/* Card Principal */}
        <div className="max-w-3xl mx-auto rounded-3xl border border-slate-200 bg-white p-8 sm:p-10 shadow-sm relative overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            {/* Benefícios do Portal */}
            <div className="space-y-4">
              <h3 className="text-xl font-bold text-slate-900">
                Uma única plataforma para toda a cadeia de doação
              </h3>
              <p className="text-sm text-slate-600 leading-relaxed">
                Desenvolvido para conectar o comércio varejista diretamente às entidades sociais cadastradas e aprovadas.
              </p>

              <div className="space-y-2.5 pt-2">
                <div className="flex items-center gap-2.5 text-sm text-slate-700">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Ambiente autenticado com controle de perfis</span>
                </div>
                <div className="flex items-center gap-2.5 text-sm text-slate-700">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>Comércio: Registro de lotes e cálculo de cashback ESG</span>
                </div>
                <div className="flex items-center gap-2.5 text-sm text-slate-700">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>ONGs: Solicitação e confirmação de recebimento</span>
                </div>
              </div>
            </div>

            {/* Ação e Destaques dos Perfis */}
            <div className="bg-slate-50 rounded-2xl border border-slate-200/80 p-6 flex flex-col justify-between space-y-6">
              <div className="space-y-3">
                <div className="flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-200/60 shadow-xs">
                  <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700">
                    <Building2 className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Perfil Comercial</h4>
                    <p className="text-[11px] text-slate-500">Supermercados, padarias e feiras</p>
                  </div>
                </div>

                <div className="flex items-center gap-3 p-3 bg-white rounded-xl border border-slate-200/60 shadow-xs">
                  <div className="p-2 rounded-lg bg-teal-50 text-teal-700">
                    <Heart className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-xs font-bold text-slate-900">Perfil Social (ONG)</h4>
                    <p className="text-[11px] text-slate-500">Instituições e projetos comunitários</p>
                  </div>
                </div>
              </div>

              {/* Botões de Ação */}
              {isAuthenticated ? (
                <div className="space-y-2">
                  <Link
                    to="/dashboard"
                    className="w-full flex items-center justify-center gap-2 py-3 px-5 rounded-xl font-bold text-white bg-emerald-700 hover:bg-emerald-800 transition-all shadow-sm text-sm"
                  >
                    <LayoutDashboard className="w-4 h-4" />
                    Ir para o Meu Painel ({user?.razao_social ? user.razao_social.split(' ')[0] : user?.nome ? user.nome.split(' ')[0] : 'Painel'})
                    <ArrowRight className="w-4 h-4 ml-1" />
                  </Link>
                  <p className="text-center text-[11px] text-slate-500">
                    Você já está autenticado nesta sessão.
                  </p>
                </div>
              ) : (
                <div className="space-y-2.5">
                  <Link
                    to="/login"
                    className="w-full flex items-center justify-center gap-2 py-3 px-5 rounded-xl font-bold text-white bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 transition-all shadow-md shadow-emerald-700/20 text-sm"
                  >
                    <LogIn className="w-4 h-4" />
                    Acessar plataforma
                    <ArrowRight className="w-4 h-4 ml-1" />
                  </Link>

                  <Link
                    to="/login"
                    className="w-full flex items-center justify-center py-2 px-4 rounded-xl font-semibold text-slate-700 hover:text-emerald-800 hover:bg-white text-xs border border-transparent hover:border-slate-200 transition-colors"
                  >
                    Não tem conta? Cadastrar organização
                  </Link>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
