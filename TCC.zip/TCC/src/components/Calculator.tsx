import React, { useState } from 'react';
import {
  Apple,
  Shirt,
  Sparkles,
  Coins,
  Users,
  Award,
  ArrowRight,
} from 'lucide-react';
import { Link } from 'react-router-dom';

type CategoryType = 'alimentos' | 'roupas';

export default function Calculator() {
  const [activeCategory, setActiveCategory] = useState<CategoryType>('alimentos');

  // Sliders por categoria (Alimentos em kg, Roupas e Cosméticos em peças/itens)
  const [kgAlimentos, setKgAlimentos] = useState(250);
  const [itensRoupasCosmeticos, setItensRoupasCosmeticos] = useState(150);

  // Percentual de Cashback conforme plano (2% Básico, 5% Profissional, 8% Premium)
  const [cashbackPercent, setCashbackPercent] = useState(5.0);

  // Valores de referência de mercado para estimativa de retorno
  const PRECO_MEDIO_ALIMENTO_KG = 8.5; // R$ 8,50 por kg de alimento aproveitado
  const PRECO_MEDIO_ROUPA_COSMETICO_ITEM = 25.0; // R$ 25,00 por peça/item de vestuário e cosméticos

  // Cálculos baseados na categoria ativa
  let volumeAtual = 0;
  let unidadeTexto = '';
  let valorEstimadoTotal = 0;
  let familiasAjudadas = 0;

  if (activeCategory === 'alimentos') {
    volumeAtual = kgAlimentos;
    unidadeTexto = 'kg';
    valorEstimadoTotal = kgAlimentos * PRECO_MEDIO_ALIMENTO_KG;
    familiasAjudadas = Math.floor(kgAlimentos / 20) || (kgAlimentos > 0 ? 1 : 0);
  } else {
    volumeAtual = itensRoupasCosmeticos;
    unidadeTexto = 'peças / itens';
    valorEstimadoTotal = itensRoupasCosmeticos * PRECO_MEDIO_ROUPA_COSMETICO_ITEM;
    familiasAjudadas = Math.floor(itensRoupasCosmeticos / 6) || (itensRoupasCosmeticos > 0 ? 1 : 0);
  }

  // Cálculos de Cashback
  const cashbackMensal = valorEstimadoTotal * (cashbackPercent / 100);
  const cashbackAnual = cashbackMensal * 12;

  // Pontos no ranking mensal (1 ponto a cada R$ 2,00 doados + bônus de consistência)
  const pontosRanking = Math.round(valorEstimadoTotal / 2) + (volumeAtual > 100 ? 50 : 20);

  return (
    <section id="calculator" className="py-20 bg-slate-50 scroll-mt-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Cabeçalho da Seção */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="inline-flex items-center gap-1.5 px-3.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-3">
            <Coins className="w-4 h-4 text-emerald-700" />
            Simulador de Impacto & Retorno
          </span>
          <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight">
            Calcule o impacto social e seu cashback garantido
          </h2>
          <p className="mt-3 text-base md:text-lg text-slate-600">
            Descubra quantas famílias seu comércio pode ajudar e o retorno financeiro gerado através do cashback socioambiental em cada plano de anuidade.
          </p>
        </div>

        {/* Caixa Principal da Calculadora */}
        <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-slate-200 flex flex-col lg:flex-row">
          {/* Lado Esquerdo: Controles e Seleção de Categorias */}
          <div className="lg:w-1/2 p-6 sm:p-10 lg:p-12 space-y-8">
            {/* Seletor de Categoria: Alimentos, Roupas e Cosméticos */}
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-500 mb-3">
                1. Escolha a Categoria do Excedente / Doação
              </label>
              <div className="grid grid-cols-2 gap-3">
                <button
                  type="button"
                  onClick={() => setActiveCategory('alimentos')}
                  className={`flex flex-col sm:flex-row items-center justify-center gap-2.5 p-3.5 sm:p-4 rounded-2xl border text-xs sm:text-sm font-bold transition-all ${
                    activeCategory === 'alimentos'
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-900 shadow-sm ring-2 ring-emerald-600/20'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <Apple className="w-5 h-5 text-emerald-600" />
                  <span>Alimentos</span>
                </button>

                <button
                  type="button"
                  onClick={() => setActiveCategory('roupas')}
                  className={`flex flex-col sm:flex-row items-center justify-center gap-2.5 p-3.5 sm:p-4 rounded-2xl border text-xs sm:text-sm font-bold transition-all ${
                    activeCategory === 'roupas'
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-900 shadow-sm ring-2 ring-emerald-600/20'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-1 text-emerald-600">
                    <Shirt className="w-5 h-5" />
                    <Sparkles className="w-3.5 h-3.5 text-amber-500" />
                  </div>
                  <span>Roupas e Cosméticos</span>
                </button>
              </div>
            </div>

            {/* Slider de Volume Conforme Categoria */}
            <div>
              <div className="flex justify-between items-baseline mb-3">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  2. Volume Estimado por Mês
                </label>
                <span className="text-2xl font-black text-emerald-700 tabular-nums">
                  {volumeAtual.toLocaleString('pt-BR')}{' '}
                  <span className="text-sm font-semibold text-slate-600">{unidadeTexto}</span>
                </span>
              </div>

              {activeCategory === 'alimentos' ? (
                <>
                  <input
                    type="range"
                    min="10"
                    max="1500"
                    step="10"
                    value={kgAlimentos}
                    onChange={(e) => setKgAlimentos(Number(e.target.value))}
                    className="w-full h-2.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                  />
                  <div className="flex justify-between text-xs text-slate-400 mt-2 font-medium">
                    <span>10 kg</span>
                    <span>500 kg</span>
                    <span>1.500 kg</span>
                  </div>
                </>
              ) : (
                <>
                  <input
                    type="range"
                    min="10"
                    max="1000"
                    step="10"
                    value={itensRoupasCosmeticos}
                    onChange={(e) => setItensRoupasCosmeticos(Number(e.target.value))}
                    className="w-full h-2.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-emerald-600"
                  />
                  <div className="flex justify-between text-xs text-slate-400 mt-2 font-medium">
                    <span>10 itens</span>
                    <span>500 itens</span>
                    <span>1.000 itens</span>
                  </div>
                </>
              )}
            </div>

            {/* Seletor de Plano de Anuidade (Impacta no Cashback) */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold uppercase tracking-wider text-slate-500">
                  3. Plano de Anuidade Desejado
                </label>
                <span className="text-xs font-semibold text-emerald-700">
                  {cashbackPercent}% de cashback
                </span>
              </div>
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setCashbackPercent(2.0)}
                  className={`p-2.5 rounded-xl border text-xs font-semibold transition-all ${
                    cashbackPercent === 2.0
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                  }`}
                >
                  Básico (2%)
                </button>
                <button
                  type="button"
                  onClick={() => setCashbackPercent(5.0)}
                  className={`p-2.5 rounded-xl border text-xs font-semibold transition-all ${
                    cashbackPercent === 5.0
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                  }`}
                >
                  Profissional (5%)
                </button>
                <button
                  type="button"
                  onClick={() => setCashbackPercent(8.0)}
                  className={`p-2.5 rounded-xl border text-xs font-semibold transition-all ${
                    cashbackPercent === 8.0
                      ? 'border-emerald-600 bg-emerald-50 text-emerald-900 font-bold'
                      : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                  }`}
                >
                  Premium (8%)
                </button>
              </div>
            </div>

            <p className="text-xs text-slate-500 leading-relaxed border-t border-slate-100 pt-4">
              Os valores de cashback são creditados diretamente na conta da sua empresa após a confirmação e triagem da ONG receptora, gerando comprovante digital para incentivo fiscal ESG.
            </p>
          </div>

          {/* Lado Direito: Apenas os 2 Cards Principais (Limpo e Direto) */}
          <div className="lg:w-1/2 bg-gradient-to-br from-emerald-800 via-emerald-700 to-teal-900 p-6 sm:p-10 lg:p-12 text-white flex flex-col justify-between">
            <div className="space-y-6">
              <div className="flex items-center justify-between border-b border-emerald-600/50 pb-4">
                <div>
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-300">
                    Projeção de Impacto & Retorno
                  </span>
                  <h3 className="text-xl sm:text-2xl font-black text-white mt-0.5">
                    Resultados Mensais Estimados
                  </h3>
                </div>
                <div className="px-3 py-1 bg-emerald-500/30 border border-emerald-400/30 rounded-full text-xs font-bold text-emerald-200">
                  {cashbackPercent}% Cashback
                </div>
              </div>

              {/* Apenas 2 Cards Principais com destaque visual */}
              <div className="space-y-4">
                {/* Card 1: Cashback Mensal */}
                <div className="bg-white/10 hover:bg-white/15 backdrop-blur-md rounded-2xl p-5 sm:p-6 border border-white/20 transition-all duration-300 transform hover:-translate-y-1 hover:shadow-xl group">
                  <div className="flex items-center justify-between text-emerald-200 mb-2">
                    <span className="text-xs sm:text-sm font-bold uppercase tracking-wider text-emerald-300">
                      Cashback Mensal Garantido
                    </span>
                    <div className="w-8 h-8 rounded-xl bg-amber-400/20 flex items-center justify-center">
                      <Coins className="w-5 h-5 text-amber-300 group-hover:scale-110 transition-transform" />
                    </div>
                  </div>
                  <div className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                    R$ {cashbackMensal.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </div>
                  <div className="text-xs sm:text-sm text-emerald-200/90 mt-2 font-medium flex items-center gap-1.5">
                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-amber-400" />
                    <span>
                      R$ {cashbackAnual.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} / ano de retorno direto
                    </span>
                  </div>
                </div>

                {/* Card 2: Famílias Ajudadas */}
                <div className="bg-white/10 hover:bg-white/15 backdrop-blur-md rounded-2xl p-5 sm:p-6 border border-white/20 transition-all duration-300 transform hover:-translate-y-1 hover:shadow-xl group">
                  <div className="flex items-center justify-between text-emerald-200 mb-2">
                    <span className="text-xs sm:text-sm font-bold uppercase tracking-wider text-emerald-300">
                      Famílias Ajudadas
                    </span>
                    <div className="w-8 h-8 rounded-xl bg-emerald-400/20 flex items-center justify-center">
                      <Users className="w-5 h-5 text-emerald-300 group-hover:scale-110 transition-transform" />
                    </div>
                  </div>
                  <div className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                    {familiasAjudadas} <span className="text-xl sm:text-2xl font-bold">famílias</span>
                  </div>
                  <div className="text-xs sm:text-sm text-emerald-200/90 mt-2 font-medium flex items-center gap-1.5">
                    <span className="inline-block w-1.5 h-1.5 rounded-full bg-emerald-400" />
                    <span>Atendidas com alimentação e itens essenciais todo mês</span>
                  </div>
                </div>
              </div>

              {/* Indicador de Ranking */}
              <div className="p-4 bg-white/10 hover:bg-white/15 rounded-2xl border border-white/15 flex items-center justify-between transition-all duration-300 transform hover:-translate-y-0.5">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-amber-400/20 flex items-center justify-center">
                    <Award className="w-5 h-5 text-amber-300 shrink-0" />
                  </div>
                  <div>
                    <div className="text-xs sm:text-sm font-bold text-white">Pontuação no Ranking Solidário</div>
                    <div className="text-xs text-emerald-200">
                      Sua pontuação estimada para o ranking mensal
                    </div>
                  </div>
                </div>
                <div className="text-xl font-black text-amber-300">
                  +{pontosRanking} pts
                </div>
              </div>
            </div>

            {/* Botão de Ação */}
            <div className="pt-6">
              <Link
                to="/login"
                className="group w-full flex items-center justify-center gap-2 py-4 px-6 bg-white hover:bg-emerald-50 text-emerald-800 text-center font-bold text-sm rounded-xl transition-all shadow-lg hover:shadow-xl"
              >
                <span>Cadastrar Minha Empresa e Acumular Cashback</span>
                <ArrowRight className="w-4 h-4 text-emerald-700 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
