import React, { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';

export interface User {
  id: string | number;
  nome: string;
  email: string;
  tipo: 'comercio' | 'ong' | 'admin' | string;
  telefone?: string;
  avatar_url?: string;
  razao_social?: string;
  cnpj?: string;
  categoria?: string;
  area_atuacao?: string;
  isNewAccount?: boolean; // Define se a conta é nova (painel zerado) ou veterana/demo (painel preenchido)
  doacoes_count?: number;
  total_kg?: number;
  cashback_saldo?: number;
  assinatura?: {
    id?: number;
    plano_id: number;
    plano_nome: string;
    cashback_percentual?: number;
    max_doacoes_mes?: number | null;
    status: string;
  } | null;
}

export interface RegisterData {
  nome: string;
  email: string;
  senha: string;
  tipo: 'comercio' | 'ong' | string;
  telefone?: string;
  razao_social?: string;
  cnpj?: string;
  categoria?: string;
  area_atuacao?: string;
  plano_id?: number;
}

export interface StoredAccount {
  user: User;
  senha: string;
}

export interface AuthContextType {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  error: string | null;
  login: (email: string, senha: string) => Promise<{ success: boolean; error?: string }>;
  register: (data: RegisterData) => Promise<{ success: boolean; error?: string }>;
  logout: () => void;
  clearError: () => void;
  toggleViewMode?: () => void; // Permite alternar entre visão zerada e visão com dados prévios
  addDonationToUser?: (item: { descricao: string; pesoKg: number; valor: number; categoria: string }) => void;
}

const API_BASE_URL = 'http://localhost:3001';
const TOKEN_KEY = 'corrente_solidaria_token';
const USER_KEY = 'corrente_solidaria_user';
const USERS_DB_KEY = 'corrente_solidaria_users_db';

// Contas padrão pré-configuradas (comércio, ONG e variações de e-mail)
const DEFAULT_ACCOUNTS: Record<string, StoredAccount> = {
  'comercio@demo.com': {
    senha: 'demo123',
    user: {
      id: 1,
      nome: 'Supermercado Esperança',
      email: 'comercio@demo.com',
      tipo: 'comercio',
      telefone: '(11) 98765-4321',
      razao_social: 'Supermercado Esperança Ltda',
      cnpj: '12.345.678/0001-90',
      categoria: 'supermercado',
      avatar_url: 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=150',
      isNewAccount: false, // Conta veterana: exibe painel consolidado com dados de exemplo
    },
  },
  'comercio.demo@correntesolidaria.org.br': {
    senha: 'demo123',
    user: {
      id: 1,
      nome: 'Supermercado Central Hortifruti',
      email: 'comercio.demo@correntesolidaria.org.br',
      tipo: 'comercio',
      telefone: '(11) 98765-4321',
      razao_social: 'Central Hortifruti e Alimentos Ltda',
      cnpj: '12.345.678/0001-90',
      categoria: 'supermercado',
      avatar_url: 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=150',
      isNewAccount: false,
    },
  },
  'ong@demo.com': {
    senha: 'demo123',
    user: {
      id: 2,
      nome: 'Instituto Prato Cheio',
      email: 'ong@demo.com',
      tipo: 'ong',
      telefone: '(11) 91234-5678',
      razao_social: 'Instituto Prato Cheio de Assistência Social',
      cnpj: '98.765.432/0001-10',
      area_atuacao: 'alimentacao',
      avatar_url: 'https://images.unsplash.com/photo-1593113598332-cd288d649433?w=150',
      isNewAccount: false,
    },
  },
  'ong.demo@correntesolidaria.org.br': {
    senha: 'demo123',
    user: {
      id: 2,
      nome: 'Instituto Prato Cheio e Esperança',
      email: 'ong.demo@correntesolidaria.org.br',
      tipo: 'ong',
      telefone: '(11) 91234-5678',
      razao_social: 'Associação Prato Cheio Solidário',
      cnpj: '98.765.432/0001-10',
      area_atuacao: 'alimentacao',
      avatar_url: 'https://images.unsplash.com/photo-1593113598332-cd288d649433?w=150',
      isNewAccount: false,
    },
  },
  'admin@correntesolidaria.com': {
    senha: 'demo123',
    user: {
      id: 5,
      nome: 'Administrador CS',
      email: 'admin@correntesolidaria.com',
      tipo: 'admin',
      telefone: '(11) 90000-0000',
      isNewAccount: false,
    },
  },
};

// Carrega todas as contas registradas (padrões + cadastradas pelos usuários)
function loadAccountsDatabase(): Record<string, StoredAccount> {
  try {
    const saved = localStorage.getItem(USERS_DB_KEY);
    if (!saved) {
      localStorage.setItem(USERS_DB_KEY, JSON.stringify(DEFAULT_ACCOUNTS));
      return { ...DEFAULT_ACCOUNTS };
    }
    const parsed = JSON.parse(saved);
    return { ...DEFAULT_ACCOUNTS, ...parsed };
  } catch {
    return { ...DEFAULT_ACCOUNTS };
  }
}

// Salva uma conta no banco de dados local
function saveAccountToDatabase(account: StoredAccount): void {
  try {
    const current = loadAccountsDatabase();
    const emailKey = account.user.email.trim().toLowerCase();
    current[emailKey] = account;
    localStorage.setItem(USERS_DB_KEY, JSON.stringify(current));
  } catch (e) {
    console.error('Falha ao persistir usuário no banco local:', e);
  }
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    try {
      const stored = localStorage.getItem(USER_KEY);
      return stored ? JSON.parse(stored) : null;
    } catch {
      return null;
    }
  });

  const [token, setToken] = useState<string | null>(() => {
    try {
      return localStorage.getItem(TOKEN_KEY);
    } catch {
      return null;
    }
  });

  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const clearError = useCallback(() => {
    setError(null);
  }, []);

  // Logout com limpeza completa de sessão
  const logout = useCallback(() => {
    try {
      localStorage.removeItem(TOKEN_KEY);
      localStorage.removeItem(USER_KEY);
    } catch (e) {
      console.error('Erro ao remover dados de autenticação:', e);
    }
    setToken(null);
    setUser(null);
    setError(null);
  }, []);

  // Auto-check do token ao inicializar a aplicação
  useEffect(() => {
    let isMounted = true;

    async function checkAuth() {
      const storedToken = localStorage.getItem(TOKEN_KEY);
      const storedUser = localStorage.getItem(USER_KEY);

      if (!storedToken || !storedUser) {
        if (isMounted) {
          setIsLoading(false);
        }
        return;
      }

      // Se já temos o usuário armazenado localmente, garantimos sua presença no estado
      try {
        const parsedUser: User = JSON.parse(storedUser);
        if (isMounted) {
          setUser(parsedUser);
        }
      } catch {
        // Formato inválido no storage
      }

      // Se for token local/demo, encerra carregamento
      if (storedToken.startsWith('local-token-') || storedToken.startsWith('demo-token-')) {
        if (isMounted) {
          setIsLoading(false);
        }
        return;
      }

      // Tenta validar contra a API backend se disponível
      try {
        const response = await fetch(`${API_BASE_URL}/api/auth/me`, {
          method: 'GET',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${storedToken}`,
          },
        });

        if (response.ok) {
          const data = await response.json();
          const remoteUser = data.usuario || data.user || data;
          if (remoteUser && isMounted) {
            setUser((prev) => {
              const merged: User = {
                ...prev,
                ...remoteUser,
                isNewAccount: prev?.isNewAccount ?? false,
              };
              localStorage.setItem(USER_KEY, JSON.stringify(merged));
              return merged;
            });
          }
        } else if (response.status === 401 || response.status === 403) {
          // Token expirado no backend
          if (isMounted) {
            logout();
          }
        }
      } catch {
        // Backend offline: mantém a sessão local sem travar o usuário
      } finally {
        if (isMounted) {
          setIsLoading(false);
        }
      }
    }

    checkAuth();

    return () => {
      isMounted = false;
    };
  }, [logout]);

  // Função de Login Universal (valida contra Backend e/ou Banco de Contas Local)
  const login = async (email: string, senha: string): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);
    setError(null);

    const normalizedEmail = email.trim().toLowerCase();
    const cleanPassword = senha.trim();

    if (!normalizedEmail || !cleanPassword) {
      const msg = 'Por favor, informe seu e-mail e sua senha.';
      setError(msg);
      setIsLoading(false);
      return { success: false, error: msg };
    }

    // 1. Tentar autenticação no Backend Express (porta 3001)
    let backendSuccess = false;
    try {
      const response = await fetch(`${API_BASE_URL}/api/auth/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email: normalizedEmail, senha: cleanPassword }),
      });

      if (response.ok) {
        const data = await response.json();
        const jwtToken: string = data.token || `auth-token-${Date.now()}`;
        const rawUser = data.usuario || data.user || {};

        // Busca informações locais da conta para preservar a flag isNewAccount
        const allAccounts = loadAccountsDatabase();
        const localRecord = allAccounts[normalizedEmail];

        const loggedUser: User = {
          id: rawUser.id || localRecord?.user.id || Date.now(),
          nome: rawUser.nome || localRecord?.user.nome || normalizedEmail.split('@')[0],
          email: rawUser.email || normalizedEmail,
          tipo: rawUser.tipo || localRecord?.user.tipo || 'comercio',
          telefone: rawUser.telefone || localRecord?.user.telefone,
          avatar_url: rawUser.avatar_url || localRecord?.user.avatar_url,
          razao_social: rawUser.comercio?.razao_social || rawUser.ong?.razao_social || localRecord?.user.razao_social,
          cnpj: rawUser.comercio?.cnpj || rawUser.ong?.cnpj || localRecord?.user.cnpj,
          categoria: rawUser.comercio?.categoria || localRecord?.user.categoria,
          area_atuacao: rawUser.ong?.area_atuacao || localRecord?.user.area_atuacao,
          isNewAccount: localRecord ? localRecord.user.isNewAccount : false,
          assinatura: rawUser.assinatura || null,
        };

        localStorage.setItem(TOKEN_KEY, jwtToken);
        localStorage.setItem(USER_KEY, JSON.stringify(loggedUser));

        setToken(jwtToken);
        setUser(loggedUser);
        setIsLoading(false);
        backendSuccess = true;
        return { success: true };
      }
    } catch {
      // Backend offline: seguimos para validação no banco de contas local
      backendSuccess = false;
    }

    if (backendSuccess) {
      return { success: true };
    }

    // 2. Validação no Banco de Contas Local (suporta contas padrão e todas as recém-criadas)
    const allAccounts = loadAccountsDatabase();
    const accountRecord = allAccounts[normalizedEmail];

    if (accountRecord) {
      if (accountRecord.senha === cleanPassword) {
        const localToken = `local-token-${Date.now()}`;
        const authenticatedUser: User = {
          ...accountRecord.user,
        };

        localStorage.setItem(TOKEN_KEY, localToken);
        localStorage.setItem(USER_KEY, JSON.stringify(authenticatedUser));

        setToken(localToken);
        setUser(authenticatedUser);
        setIsLoading(false);
        return { success: true };
      } else {
        const passError = 'Senha incorreta para este e-mail. Por favor, tente novamente.';
        setError(passError);
        setIsLoading(false);
        return { success: false, error: passError };
      }
    }

    // Conta não encontrada nem no backend nem localmente
    const notFoundError = 'E-mail não cadastrado. Verifique a digitação ou crie uma nova conta na aba Cadastro.';
    setError(notFoundError);
    setIsLoading(false);
    return { success: false, error: notFoundError };
  };

  // Função de Registro (cria conta nova marcada como isNewAccount = true para abrir painel zerado)
  const register = async (data: RegisterData): Promise<{ success: boolean; error?: string }> => {
    setIsLoading(true);
    setError(null);

    const normalizedEmail = data.email.trim().toLowerCase();
    const cleanPassword = data.senha.trim();

    // Criação do objeto de usuário novo (zerado por padrão)
    const newUser: User = {
      id: `usr-${Date.now()}`,
      nome: data.nome.trim(),
      email: normalizedEmail,
      tipo: data.tipo,
      telefone: data.telefone?.trim(),
      razao_social: data.razao_social?.trim(),
      cnpj: data.cnpj?.trim(),
      categoria: data.categoria,
      area_atuacao: data.area_atuacao,
      isNewAccount: true, // IMPORTANTE: contas recém-criadas abrem o painel zerado!
      doacoes_count: 0,
      total_kg: 0,
      cashback_saldo: 0,
    };

    // Salva imediatamente no banco local para permitir login futuro com a senha escolhida
    saveAccountToDatabase({
      user: newUser,
      senha: cleanPassword,
    });

    // Tenta também sincronizar com o backend em paralelo se disponível
    try {
      fetch(`${API_BASE_URL}/api/auth/registro`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...data,
          email: normalizedEmail,
          senha: cleanPassword,
        }),
      }).catch(() => {
        // Falha silenciosa do backend, pois a persistência local já foi garantida
      });
    } catch {
      // Ignora erro de rede do backend
    }

    // Não ativa a sessão automática: o usuário será redirecionado para a tela de login
    setIsLoading(false);

    return { success: true };
  };

  // Permite alternar o modo de visão (painel zerado vs painel demonstrativo consolidado)
  const toggleViewMode = () => {
    if (!user) return;
    const updatedUser: User = {
      ...user,
      isNewAccount: !user.isNewAccount,
    };
    setUser(updatedUser);
    localStorage.setItem(USER_KEY, JSON.stringify(updatedUser));

    // Atualiza também no banco de contas
    const all = loadAccountsDatabase();
    const emailKey = user.email.trim().toLowerCase();
    if (all[emailKey]) {
      all[emailKey].user = updatedUser;
      localStorage.setItem(USERS_DB_KEY, JSON.stringify(all));
    }
  };

  // Permite cadastrar uma doação em tempo real para a conta ativa
  const addDonationToUser = (item: { descricao: string; pesoKg: number; valor: number; categoria: string }) => {
    if (!user) return;
    const currentKg = user.total_kg || 0;
    const currentCount = user.doacoes_count || 0;
    const currentCashback = user.cashback_saldo || 0;

    const cashbackEarned = Number((item.valor * 0.05).toFixed(2));

    const updatedUser: User = {
      ...user,
      total_kg: currentKg + item.pesoKg,
      doacoes_count: currentCount + 1,
      cashback_saldo: currentCashback + cashbackEarned,
      isNewAccount: false, // Sai do estado zerado pois já realizou uma doação!
    };

    setUser(updatedUser);
    localStorage.setItem(USER_KEY, JSON.stringify(updatedUser));

    // Atualiza também no banco de contas
    const all = loadAccountsDatabase();
    const emailKey = user.email.trim().toLowerCase();
    if (all[emailKey]) {
      all[emailKey].user = updatedUser;
      localStorage.setItem(USERS_DB_KEY, JSON.stringify(all));
    }
  };

  const value: AuthContextType = {
    user,
    token,
    isAuthenticated: Boolean(token && user),
    isLoading,
    error,
    login,
    register,
    logout,
    clearError,
    toggleViewMode,
    addDonationToUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth deve ser utilizado dentro de um <AuthProvider>');
  }
  return context;
};
