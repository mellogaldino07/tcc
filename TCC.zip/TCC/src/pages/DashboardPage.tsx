import React, { useState, useEffect } from 'react';
import {
  Recycle,
  LogOut,
  ArrowLeft,
  TrendingUp,
  Award,
  Target,
  Package,
  Truck,
  CheckCircle2,
  Calendar,
  PlusCircle,
  Download,
  Leaf,
  X,
  FileCheck,
  Inbox,
  Heart,
  Search,
  MapPin,
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';

interface CustomDonationItem {
  id: string;
  codigo: string;
  categoria: string;
  descricao: string;
  pesoKg: number;
  valor: number;
  destino: string;
  status: 'entregue' | 'em_transporte' | 'aceita' | 'pendente' | 'recusada';
  data: string;
  origem?: string;
  coletaData?: string;
  coletaHora?: string;
}

interface OngOption {
  id: string | number;
  nome: string;
  area?: string;
  cidade?: string;
}

export default function DashboardPage() {
  const { user, logout, addDonationToUser } = useAuth();
  const navigate = useNavigate();

  const [notification, setNotification] = useState<string | null>(null);
  const [todayIso] = useState(() => new Date().toISOString().slice(0, 10));
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('todos');
  const [scheduleDrafts, setScheduleDrafts] = useState<Record<string, { data: string; hora: string }>>({});
  const [ongSearch, setOngSearch] = useState('');
  const [ongs, setOngs] = useState<OngOption[]>([]);
  const categorias = ['Alimentos Perecíveis', 'Grãos e Não Perecíveis', 'Roupas e Agasalhos', 'Kits de Higiene e Cuidados', 'Outros'];
  const [availableDonations, setAvailableDonations] = useState<CustomDonationItem[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('corrente_solidaria_donation_feed') || '[]');
    } catch {
      return [];
    }
  });

  // Campos do modal de nova doação
  const [modalDescricao, setModalDescricao] = useState('');
  const [modalCategoria, setModalCategoria] = useState('Alimentos');
  const [modalPeso, setModalPeso] = useState('25');
  const [modalValor, setModalValor] = useState('150');
  const [modalOng, setModalOng] = useState('');

  useEffect(() => {
    let active = true;
    const localOngs: OngOption[] = [];
    try {
      const accounts = JSON.parse(localStorage.getItem('corrente_solidaria_users_db') || '{}') as Record<string, { user?: { id?: string | number; tipo?: string; nome?: string; razao_social?: string; area_atuacao?: string } }>;
      Object.values(accounts).forEach(({ user: account }) => {
        if (account?.tipo === 'ong') localOngs.push({ id: account.id || account.razao_social || account.nome || localOngs.length, nome: account.razao_social?.trim() || account.nome?.trim() || 'ONG cadastrada', area: account.area_atuacao });
      });
    } catch {
      // A busca remota ainda pode preencher a lista se o cadastro local estiver inválido.
    }
    const mergeOngs = (remote: OngOption[] = []) => {
      const merged = new Map<string, OngOption>();
      [...localOngs, ...remote].forEach((ong) => merged.set(ong.nome.trim().toLocaleLowerCase('pt-BR'), ong));
      if (active) {
        const result = [...merged.values()].sort((a, b) => a.nome.localeCompare(b.nome, 'pt-BR'));
        setOngs(result);
      }
    };
    mergeOngs();
    fetch('http://localhost:3001/api/ongs')
      .then((response) => response.ok ? response.json() : Promise.reject(new Error('API indisponível')))
      .then((data) => mergeOngs((data.ongs || []).map((ong: { id: number; razao_social: string; area_atuacao?: string; cidade?: string }) => ({ id: ong.id, nome: ong.razao_social, area: ong.area_atuacao, cidade: ong.cidade }))))
      .catch(() => undefined);
    return () => { active = false; };
  }, []);

  const visibleOngs = ongSearch.trim().length > 0
    ? ongs.filter((ong) => `${ong.nome} ${ong.area || ''} ${ong.cidade || ''}`.toLocaleLowerCase('pt-BR').includes(ongSearch.toLocaleLowerCase('pt-BR'))).slice(0, 8)
    : [];

  // Chave de persistência das doações da empresa conectada
  const userStorageKey = `corrente_solidaria_donations_${user?.email || 'default'}`;

  // Doações reais da empresa (inicia vazia para conta nova e persiste conforme movimentações)
  const [userDonations, setUserDonations] = useState<CustomDonationItem[]>(() => {
    try {
      const saved = JSON.parse(localStorage.getItem(`corrente_solidaria_donations_${user?.email || 'default'}`) || '[]') as CustomDonationItem[];
      const feed = JSON.parse(localStorage.getItem('corrente_solidaria_donation_feed') || '[]') as CustomDonationItem[];
      return saved.map((item) => {
        const shared = feed.find((entry) => entry.id === item.id);
        return shared ? { ...item, status: shared.status, destino: shared.destino, coletaData: shared.coletaData || item.coletaData, coletaHora: shared.coletaHora || item.coletaHora } : item;
      });
    } catch {
      return [];
    }
  });

  // Salva no localStorage sempre que houver uma nova doação
  useEffect(() => {
    try {
      localStorage.setItem(userStorageKey, JSON.stringify(userDonations));
    } catch {
      // Ignora erro de cota de armazenamento local
    }
  }, [userDonations, userStorageKey]);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const showToast = (msg: string) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3500);
  };

  // Submissão do cadastro de nova doação
  const handleSaveDonation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!modalDescricao.trim()) return;
    if (!modalOng) {
      showToast('Pesquise e selecione uma ONG antes de salvar o lote.');
      return;
    }

    const pesoNum = Number(modalPeso) || 10;
    const valorNum = Number(modalValor) || 50;

    const newItem: CustomDonationItem = {
      id: `don-${Date.now()}`,
      codigo: `CS-2026-${String(Math.floor(Math.random() * 900) + 100)}`,
      categoria: modalCategoria,
      descricao: modalDescricao.trim(),
      pesoKg: pesoNum,
      valor: valorNum,
      destino: modalOng,
      origem: displayCompanyName,
      status: 'pendente',
      data: new Date().toLocaleDateString('pt-BR'),
    };

    const updated = [newItem, ...userDonations];
    setUserDonations(updated);
    const sharedFeed: CustomDonationItem[] = JSON.parse(localStorage.getItem('corrente_solidaria_donation_feed') || '[]');
    const nextFeed = [newItem, ...sharedFeed.filter((item) => item.id !== newItem.id)];
    localStorage.setItem('corrente_solidaria_donation_feed', JSON.stringify(nextFeed));
    setAvailableDonations(nextFeed);

    if (addDonationToUser) {
      addDonationToUser({
        descricao: newItem.descricao,
        pesoKg: newItem.pesoKg,
        valor: newItem.valor,
        categoria: newItem.categoria,
      });
    }

    setIsModalOpen(false);
    setModalDescricao('');
    setOngSearch('');
    setModalOng('');
    showToast(`Doação cadastrada com sucesso! Lote ${newItem.codigo} gerado.`);
  };

  // Nome principal para exibição: sempre a Razão Social cadastrada
  const displayCompanyName = user?.razao_social?.trim() || user?.nome?.trim() || 'Minha Conta';
  const companyInitial = displayCompanyName.charAt(0).toUpperCase();

  // Métricas calculadas dinamicamente: zeradas para conta nova, atualizadas conforme movimentações
  const hasDonations = userDonations.length > 0;
  const totalKg = userDonations.reduce((acc, d) => acc + d.pesoKg, 0);
  const totalCashback = userDonations.reduce((acc, d) => acc + (d.valor * 0.05), 0);
  const totalPoints = Math.round(userDonations.reduce((acc, d) => acc + (d.valor / 2), 0));
  const metaKg = 500;
  const metaPercent = hasDonations ? Math.min(100, Math.round((totalKg / metaKg) * 100)) : 0;

  // Impacto ambiental derivado das doações reais da empresa
  const co2EvitadoKg = Math.round(totalKg * 2.3);
  const aguaPreservadaL = Math.round(totalKg * 420);
  const familiasAlimentadas = Math.floor(totalKg / 20) || (hasDonations ? 1 : 0);
  const isOng = user?.tipo === 'ong';
  const filteredDonations = userDonations.filter((item) => {
    const matchesSearch = `${item.codigo} ${item.descricao} ${item.categoria} ${item.destino}`.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'todos' || item.status === statusFilter;
    return matchesSearch && matchesStatus;
  });
  const scheduledDonations = userDonations
    .filter((item) => Boolean(item.coletaData && item.coletaHora))
    .sort((a, b) => `${a.coletaData} ${a.coletaHora}`.localeCompare(`${b.coletaData} ${b.coletaHora}`));

  const updateDonation = (id: string, changes: Partial<CustomDonationItem>) => {
    setUserDonations((current) => current.map((item) => item.id === id ? { ...item, ...changes } : item));
    const feed: CustomDonationItem[] = JSON.parse(localStorage.getItem('corrente_solidaria_donation_feed') || '[]');
    const nextFeed = feed.map((item) => item.id === id ? { ...item, ...changes } : item);
    localStorage.setItem('corrente_solidaria_donation_feed', JSON.stringify(nextFeed));
    setAvailableDonations(nextFeed);
  };

  const handleSchedulePickup = (item: CustomDonationItem) => {
    const draft = scheduleDrafts[item.id] || { data: item.coletaData || '', hora: item.coletaHora || '' };
    if (!draft.data || !draft.hora) {
      showToast('Informe a data e o horário para agendar a coleta.');
      return;
    }
    updateDonation(item.id, { coletaData: draft.data, coletaHora: draft.hora });
    showToast(`Coleta do lote ${item.codigo} agendada.`);
  };

  const exportImpactReport = () => {
    const rows: (string | number)[][] = [
      ['Relatório de impacto socioambiental', displayCompanyName],
      ['Gerado em', new Date().toLocaleDateString('pt-BR')],
      ['Total doado (kg)', totalKg],
      ['Cashback estimado (R$)', totalCashback.toFixed(2)],
      ['CO2e evitado (kg)', co2EvitadoKg],
      ['Água preservada (L)', aguaPreservadaL],
      ['Famílias atendidas (estimativa)', familiasAlimentadas],
      [],
      ['Código', 'Descrição', 'Categoria', 'Peso (kg)', 'Valor estimado (R$)', 'ONG', 'Status', 'Data da coleta', 'Horário'],
      ...userDonations.map((item) => [item.codigo, item.descricao, item.categoria, item.pesoKg, item.valor, item.destino, item.status, item.coletaData || '', item.coletaHora || '']),
    ];
    const csv = `\uFEFF${rows.map((row) => row.map((value) => `"${String(value ?? '').replace(/"/g, '""')}"`).join(';')).join('\r\n')}`;
    const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `relatorio-impacto-${new Date().toISOString().slice(0, 10)}.csv`;
    anchor.click();
    URL.revokeObjectURL(url);
    showToast('Relatório de impacto exportado em CSV.');
  };

  const handleInterest = (donation: CustomDonationItem) => {
    const nextFeed = availableDonations.map((item) => item.id === donation.id ? { ...item, destino: displayCompanyName, status: 'aceita' as const } : item);
    localStorage.setItem('corrente_solidaria_donation_feed', JSON.stringify(nextFeed));
    setAvailableDonations(nextFeed);
    showToast(`Lote ${donation.codigo} aceito. O comércio já pode acompanhar o status.`);
  };

  const handleRejectDonation = (donation: CustomDonationItem) => {
    updateDonation(donation.id, { status: 'recusada' });
    showToast(`Lote ${donation.codigo} recusado.`);
  };

  if (isOng) {
    const claimedDonations = availableDonations.filter((item) => item.destino === displayCompanyName && (item.status === 'aceita' || item.status === 'em_transporte'));
    const openDonations = availableDonations.filter((item) => item.status === 'pendente' && item.destino.trim().toLocaleLowerCase('pt-BR') === displayCompanyName.trim().toLocaleLowerCase('pt-BR'));
    const kgReceived = claimedDonations.reduce((total, item) => total + item.pesoKg, 0);
    return (
      <div className="min-h-screen bg-slate-50 font-sans">
        {notification && <div role="status" className="fixed top-5 right-5 z-50 bg-emerald-800 text-white px-5 py-3 rounded-xl shadow-lg flex items-center gap-3"><CheckCircle2 className="w-5 h-5" />{notification}</div>}
        <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
            <Link to="/" className="flex items-center gap-2"><Recycle className="h-7 w-7 text-violet-700" /><span className="text-xl font-bold text-slate-900">CorrenteSolidária</span><span className="ml-2 rounded-full bg-violet-100 px-2.5 py-1 text-xs font-bold text-violet-800">PAINEL ONG</span></Link>
            <div className="flex items-center gap-3"><div className="hidden sm:block text-right"><p className="text-sm font-bold text-slate-900">{displayCompanyName}</p><p className="text-xs text-slate-500">Organização receptora</p></div><button onClick={handleLogout} className="inline-flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-rose-50"><LogOut className="w-4 h-4" />Sair</button></div>
          </div>
        </header>
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-7">
          <section className="rounded-3xl bg-gradient-to-r from-violet-800 via-purple-700 to-fuchsia-800 p-7 sm:p-9 text-white shadow-md">
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-5"><div><span className="inline-flex items-center gap-2 rounded-full bg-white/15 px-3 py-1 text-xs font-semibold text-violet-100"><Heart className="w-4 h-4" />Painel de recebimentos e impacto</span><h1 className="mt-3 text-3xl font-extrabold">Olá, {displayCompanyName}!</h1><p className="mt-2 max-w-2xl text-sm text-violet-100">Encontre doações disponíveis, manifeste interesse nos lotes e acompanhe suas retiradas e atendimentos.</p></div><div className="rounded-2xl border border-white/20 bg-white/10 p-4 min-w-48"><p className="text-xs text-violet-100">Área de atuação</p><p className="mt-1 font-bold">{user?.area_atuacao || 'Não informada'}</p></div></div>
          </section>
          <section className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="rounded-2xl border border-slate-200 bg-white p-5"><p className="text-xs font-semibold uppercase tracking-wider text-slate-500">Novos lotes para sua ONG</p><p className="mt-2 text-3xl font-black text-violet-800">{openDonations.length}</p><p className="mt-1 text-xs text-slate-500">Aguardando sua decisão</p></div>
            <div className="rounded-2xl border border-slate-200 bg-white p-5"><p className="text-xs font-semibold uppercase tracking-wider text-slate-500">Retiradas em andamento</p><p className="mt-2 text-3xl font-black text-amber-600">{claimedDonations.length}</p><p className="mt-1 text-xs text-slate-500">Lotes com interesse registrado</p></div>
            <div className="rounded-2xl border border-slate-200 bg-white p-5"><p className="text-xs font-semibold uppercase tracking-wider text-slate-500">Volume reservado</p><p className="mt-2 text-3xl font-black text-emerald-700">{kgReceived.toLocaleString('pt-BR')} kg</p><p className="mt-1 text-xs text-slate-500">Total dos lotes em acompanhamento</p></div>
          </section>
          <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2 overflow-hidden rounded-2xl border border-slate-200 bg-white">
              <div className="flex items-center justify-between border-b border-slate-100 p-5"><div><h2 className="text-lg font-bold text-slate-900">Lotes destinados à sua ONG</h2><p className="text-xs text-slate-500">Confira os detalhes e aceite ou recuse cada doação.</p></div><button onClick={() => { setAvailableDonations(JSON.parse(localStorage.getItem('corrente_solidaria_donation_feed') || '[]')); }} className="text-xs font-bold text-violet-700 hover:text-violet-900">Atualizar</button></div>
              {openDonations.length === 0 ? <div className="px-6 py-14 text-center"><div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-violet-50 text-violet-700"><Inbox className="h-7 w-7" /></div><h3 className="font-bold text-slate-900">Ainda não há lotes destinados à sua ONG</h3><p className="mt-1 text-sm text-slate-500">Quando um comércio escolher sua organização como destino, o lote aparecerá aqui.</p></div> : <div className="divide-y divide-slate-100">{openDonations.map((item) => <article key={item.id} className="flex flex-col gap-4 p-5 sm:flex-row sm:items-center sm:justify-between"><div><div className="flex flex-wrap items-center gap-2"><span className="font-mono text-xs font-bold text-violet-800">{item.codigo}</span><span className="rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-semibold text-emerald-800">{item.categoria}</span></div><h3 className="mt-2 font-bold text-slate-900">{item.descricao}</h3><p className="mt-1 flex items-center gap-1 text-xs text-slate-500"><MapPin className="h-3.5 w-3.5" />Doador: {item.origem || 'Comércio parceiro'} · Publicado em {item.data}</p><p className="mt-2 text-sm font-semibold text-slate-700">{item.pesoKg} kg <span className="font-normal text-slate-400">· Valor estimado R$ {item.valor.toLocaleString('pt-BR')}</span></p><p className="mt-1 text-xs text-slate-500">Destino selecionado pelo comércio: {item.destino}</p></div><div className="flex shrink-0 gap-2"><button onClick={() => handleRejectDonation(item)} className="rounded-xl border border-rose-200 px-3 py-2.5 text-sm font-bold text-rose-700 hover:bg-rose-50">Recusar</button><button onClick={() => handleInterest(item)} className="rounded-xl bg-violet-700 px-4 py-2.5 text-sm font-bold text-white hover:bg-violet-800"><CheckCircle2 className="mr-2 inline h-4 w-4" />Aceitar doação</button></div></article>)}</div>}
            </div>
            <aside className="rounded-2xl border border-slate-200 bg-white p-5"><h2 className="font-bold text-slate-900">Recebimentos em andamento</h2><p className="mt-1 text-xs text-slate-500">Acompanhe aceite, coleta e confirmação de entrega.</p>{claimedDonations.length === 0 ? <div className="py-10 text-center text-sm text-slate-500"><Truck className="mx-auto mb-2 h-8 w-8 text-slate-300" />Nenhum recebimento em andamento.</div> : <div className="mt-4 space-y-3">{claimedDonations.map((item) => <div key={item.id} className="rounded-xl border border-amber-200 bg-amber-50 p-3"><div className="flex items-center justify-between"><span className="font-mono text-xs font-bold">{item.codigo}</span><span className="text-xs font-semibold text-amber-800">{item.status === 'em_transporte' ? 'Em transporte' : 'Aceita'}</span></div><p className="mt-1 text-sm font-semibold text-slate-800">{item.descricao}</p><p className="mt-1 text-xs text-slate-600">{item.pesoKg} kg · {item.categoria}</p>{item.coletaData && <p className="mt-2 rounded-lg bg-white px-2.5 py-2 text-xs font-semibold text-emerald-800">Coleta: {item.coletaData.split('-').reverse().join('/')} às {item.coletaHora}</p>}{item.status === 'em_transporte' && <button onClick={() => updateDonation(item.id, { status: 'entregue' })} className="mt-2 w-full rounded-lg bg-emerald-700 px-3 py-2 text-xs font-bold text-white hover:bg-emerald-800">Confirmar recebimento</button>}</div>)}</div>}<div className="mt-5 rounded-xl bg-violet-50 p-4 text-xs leading-relaxed text-violet-900"><strong>Próximo passo:</strong> após aceitar, alinhe a retirada com o comércio. Quando o lote chegar, confirme o recebimento para concluir o ciclo.</div></aside>
          </section>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col font-sans">
      {/* Toast de Notificação */}
      {notification && (
        <div className="fixed top-5 right-5 z-50 bg-emerald-800 text-white px-5 py-3 rounded-xl shadow-lg border border-emerald-600 flex items-center gap-3 animate-fade-in text-sm">
          <CheckCircle2 className="w-5 h-5 text-emerald-300" />
          <span>{notification}</span>
        </div>
      )}

      {/* Top Navbar do Dashboard */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo e Link de retorno */}
            <div className="flex items-center space-x-6">
              <Link to="/" className="flex items-center space-x-2 focus-visible:outline-emerald-600">
                <Recycle className="h-7 w-7 text-emerald-600" />
                <span className="text-xl font-bold text-slate-900 tracking-tight">CorrenteSolidária</span>
              </Link>
              <span className="hidden md:inline-block h-5 w-px bg-slate-200" />
              <Link
                to="/"
                className="hidden md:inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-emerald-700 transition-colors"
              >
                <ArrowLeft className="w-4 h-4" />
                Voltar ao site público
              </Link>
            </div>

            {/* Informações da Conta (Razão Social) e Logout */}
            <div className="flex items-center space-x-3 sm:space-x-4">
              <div className="flex items-center space-x-3">
                <div className="w-9 h-9 rounded-full bg-emerald-100 text-emerald-800 flex items-center justify-center font-bold text-sm border border-emerald-200 uppercase shadow-xs">
                  {companyInitial}
                </div>
                <div className="hidden sm:block text-left">
                  <div className="text-sm font-bold text-slate-900 leading-tight">
                    {displayCompanyName}
                  </div>
                  {user?.cnpj && (
                    <div className="text-[11px] font-mono text-slate-500 leading-none mt-1">
                      CNPJ: {user.cnpj}
                    </div>
                  )}
                </div>
              </div>

              {/* Botão Logout */}
              <button
                type="button"
                onClick={handleLogout}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-rose-50 hover:text-rose-700 hover:border-rose-200 transition-colors"
                title="Sair da conta"
              >
                <LogOut className="w-4 h-4" />
                <span className="hidden sm:inline">Desconectar</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Conteúdo Principal */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        {/* Banner de Boas-vindas */}
        <div className="bg-gradient-to-r from-emerald-800 via-emerald-700 to-teal-800 rounded-3xl p-6 sm:p-8 text-white shadow-md relative overflow-hidden">
          <div className="absolute right-0 top-0 bottom-0 opacity-10 pointer-events-none flex items-center pr-10">
            <Recycle className="w-64 h-64 text-white" />
          </div>

          <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/10 text-emerald-100 text-xs font-semibold backdrop-blur-sm mb-3">
                <FileCheck className="w-3.5 h-3.5 text-emerald-300" />
                Painel do Comércio · Doações e Sustentabilidade
              </div>
              <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
                Olá, {displayCompanyName}!
              </h1>
              <p className="mt-1 text-sm sm:text-base text-emerald-100 max-w-xl">
                CNPJ: {user?.cnpj || 'Não informado'} · Segmento: {user?.categoria || 'Não informado'}. Acompanhe seus lotes, coletas e retorno em cashback socioambiental.
              </p>
            </div>

            <div className="flex flex-wrap gap-3 shrink-0">
              <button
                onClick={() => setIsModalOpen(true)}
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-white text-emerald-800 hover:bg-emerald-50 font-bold text-sm transition-all shadow-sm"
              >
                <PlusCircle className="w-4 h-4 text-emerald-700" />
                Cadastrar Nova Doação
              </button>
              <button
                onClick={() =>
                  showToast(
                    hasDonations
                      ? 'Certificado ESG 2026 exportado em PDF.'
                      : 'O Certificado ESG será emitido após a primeira doação concluída.'
                  )
                }
                className="inline-flex items-center gap-2 px-4 py-2.5 rounded-xl bg-emerald-900/40 hover:bg-emerald-900/60 border border-white/20 text-white font-semibold text-sm transition-colors"
              >
                <Download className="w-4 h-4" />
                Certificado ESG
              </button>
            </div>
          </div>
        </div>


        {/* Cadastro inline: permanece no dashboard, sem navegar para outra tela ou abrir modal. */}
      {isModalOpen && (
        <section className="rounded-3xl border border-emerald-200 bg-white p-5 shadow-sm sm:p-7">
          <div className="mx-auto max-w-3xl">
            <div className="flex items-center justify-between pb-4 border-b border-slate-100 mb-6">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700">
                  <PlusCircle className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-slate-900">Cadastrar Nova Doação</h3>
                  <p className="text-xs text-slate-500">Disponibilize excedentes de alimentos ou vestuário</p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-slate-600 p-1.5 rounded-lg hover:bg-slate-100"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveDonation} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-slate-700 mb-1">
                  Descrição dos Itens / Lote
                </label>
                <input
                  type="text"
                  required
                  placeholder="Ex: 40 kg de hortaliças frescas e frutas"
                  value={modalDescricao}
                  onChange={(e) => setModalDescricao(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Categoria
                  </label>
                  <select
                    value={modalCategoria}
                    onChange={(e) => setModalCategoria(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600 bg-white"
                  >
                    {categorias.map((category) => <option key={category} value={category === 'Alimentos Perecíveis' ? 'Alimentos' : category === 'Grãos e Não Perecíveis' ? 'Grãos' : category === 'Roupas e Agasalhos' ? 'Roupas' : category === 'Kits de Higiene e Cuidados' ? 'Higiene' : category}>{category}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Volume / Peso (kg)
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={modalPeso}
                    onChange={(e) => setModalPeso(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    Valor Estimado (R$)
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={modalValor}
                    onChange={(e) => setModalValor(e.target.value)}
                    className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold text-slate-700 mb-1">
                    ONG Parceira Receptora
                  </label>
                  <input
                    type="search"
                    value={ongSearch}
                    onChange={(e) => { setOngSearch(e.target.value); setModalOng(''); }}
                    placeholder="Digite o nome da ONG para pesquisar"
                    aria-label="Pesquisar ONGs cadastradas"
                    className="mb-2 w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600"
                  />
                  {visibleOngs.length > 0 && (
                    <ul role="listbox" aria-label="Resultados da pesquisa de ONGs" className="mb-2 max-h-44 overflow-y-auto rounded-xl border border-slate-200 bg-white shadow-lg">
                      {visibleOngs.map((ong) => (
                        <li key={ong.id}>
                          <button type="button" role="option" aria-selected={modalOng === ong.nome} onClick={() => { setModalOng(ong.nome); setOngSearch(ong.nome); }} className="w-full px-3.5 py-2.5 text-left text-sm text-slate-700 hover:bg-emerald-50 focus:bg-emerald-50 focus:outline-none">
                            <span className="block font-semibold">{ong.nome}</span>
                            {(ong.area || ong.cidade) && <span className="mt-0.5 block text-xs text-slate-500">{[ong.area, ong.cidade].filter(Boolean).join(' · ')}</span>}
                          </button>
                        </li>
                      ))}
                    </ul>
                  )}
                  {ongSearch.trim() && visibleOngs.length === 0 && <p className="mb-2 text-xs text-slate-500">Nenhuma ONG encontrada com esse nome.</p>}
                  {modalOng && <p className="text-xs font-medium text-emerald-700">ONG selecionada: {modalOng}</p>}
                </div>
              </div>

              <div className="p-3 bg-emerald-50 rounded-xl border border-emerald-100 text-xs text-emerald-800">
                💡 <span className="font-semibold">Cashback Estimado:</span> R${' '}
                {((Number(modalValor) || 0) * 0.05).toFixed(2)} (5% creditado na conta da empresa após a retirada com o plano Profissional).
              </div>

              <div className="flex gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="flex-1 py-2.5 px-4 rounded-xl border border-slate-300 text-slate-700 font-semibold text-sm hover:bg-slate-50 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex-1 py-2.5 px-4 rounded-xl bg-emerald-700 text-white font-bold text-sm hover:bg-emerald-800 transition-colors shadow-sm"
                >
                  Salvar e Disponibilizar
                </button>
              </div>
            </form>
          </div>
        </section>
      )}

        {/* 4 Cards de Estatísticas (Iniciam zerados e atualizam conforme as movimentações reais) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Card 1: Total Doado */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-emerald-300 transition-all">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Total Doado
              </span>
              <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-700">
                <Package className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-3">
              <div className="text-2xl font-black text-slate-900">
                {totalKg.toLocaleString('pt-BR')} kg
              </div>
              <p className="text-xs text-slate-500 mt-1 flex items-center gap-1">
                {hasDonations ? (
                  <>
                    <span className="text-emerald-700 font-bold">Ativo</span> · Movimentações registradas
                  </>
                ) : (
                  <span className="text-slate-400">Nenhum lote registrado este mês</span>
                )}
              </p>
            </div>
          </div>

          {/* Card 2: Cashback Acumulado */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-emerald-300 transition-all">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Cashback Acumulado
              </span>
              <div className="p-2.5 rounded-xl bg-amber-50 text-amber-700">
                <TrendingUp className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-3">
              <div className="text-2xl font-black text-slate-900">
                R$ {totalCashback.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </div>
              <p className="text-xs text-slate-500 mt-1">
                {hasDonations ? 'Créditos validados em conta' : 'Créditos liberados a cada doação'}
              </p>
            </div>
          </div>

          {/* Card 3: Posição no Ranking */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-emerald-300 transition-all">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Posição no Ranking
              </span>
              <div className="p-2.5 rounded-xl bg-indigo-50 text-indigo-700">
                <Award className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-3">
              <div className="text-2xl font-black text-slate-900">
                {hasDonations ? (totalPoints > 300 ? 'Top 10' : 'Top 50') : '--'}
              </div>
              <p className="text-xs text-slate-500 mt-1">
                {hasDonations
                  ? `+${totalPoints} pts acumulados`
                  : 'Cadastre sua 1ª doação para pontuar'}
              </p>
            </div>
          </div>

          {/* Card 4: Meta Atual */}
          <div className="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs hover:border-emerald-300 transition-all">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
                Meta do Mês
              </span>
              <div className="p-2.5 rounded-xl bg-emerald-50 text-emerald-700">
                <Target className="w-5 h-5" />
              </div>
            </div>
            <div className="mt-3">
              <div className="flex items-baseline justify-between">
                <span className="text-2xl font-black text-slate-900">
                  {metaPercent}%
                </span>
                <span className="text-xs text-slate-500">
                  {totalKg.toLocaleString('pt-BR')} / {metaKg} kg
                </span>
              </div>
              <div className="w-full bg-slate-100 rounded-full h-2 mt-2 overflow-hidden">
                <div
                  className="bg-emerald-600 h-2 rounded-full transition-all duration-500"
                  style={{ width: `${metaPercent}%` }}
                />
              </div>
            </div>
          </div>
        </div>

        {/* SEÇÃO PRINCIPAL: Histórico de Lotes & Painel Lateral */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Tabela de Doações Reais da Empresa */}
          <div className="lg:col-span-2 bg-white rounded-2xl border border-slate-200/80 shadow-xs overflow-hidden flex flex-col justify-between">
            <div>
              <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-slate-900 text-lg">Histórico de Lotes Doados</h3>
                  <p className="text-xs text-slate-500">Rastreamento digital de todos os lotes cadastrados</p>
                </div>
                {hasDonations && (
                  <button
                    onClick={() => setIsModalOpen(true)}
                    className="inline-flex items-center gap-1 text-xs font-bold text-emerald-700 hover:text-emerald-800"
                  >
                    <PlusCircle className="w-3.5 h-3.5" />
                    Novo Lote
                  </button>
                )}
              </div>

              {hasDonations && (
                <div className="flex flex-col gap-3 border-b border-slate-100 bg-white p-4 sm:flex-row">
                  <label className="relative flex-1">
                    <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
                    <input aria-label="Buscar lote" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} placeholder="Buscar por código, descrição ou categoria" className="w-full rounded-xl border border-slate-200 py-2 pl-9 pr-3 text-sm focus:border-emerald-600 focus:outline-none focus:ring-2 focus:ring-emerald-600/20" />
                  </label>
                  <select aria-label="Filtrar por status" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)} className="rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm text-slate-700 focus:border-emerald-600 focus:outline-none">
                    <option value="todos">Todos os status</option>
                    <option value="pendente">Aguardando coleta</option>
                    <option value="aceita">ONG interessada</option>
                    <option value="em_transporte">Em transporte</option>
                    <option value="entregue">Entregue</option>
                  </select>
                </div>
              )}

              {!hasDonations ? (
                /* Estado Zerado Inicial: Limpo e Convidativo */
                <div className="py-16 px-6 flex flex-col items-center justify-center text-center">
                  <div className="w-16 h-16 rounded-3xl bg-emerald-50 border border-emerald-100 flex items-center justify-center text-emerald-600 mb-4 shadow-xs">
                    <Inbox className="w-8 h-8 text-emerald-600" />
                  </div>
                  <h4 className="text-lg font-bold text-slate-900">
                    Nenhuma doação cadastrada ainda
                  </h4>
                  <p className="text-sm text-slate-500 max-w-md mt-1 mb-6 leading-relaxed">
                    Sua conta de empresa está ativa e pronta para operar! Cadastre seu primeiro lote de excedentes de alimentos ou vestuário para iniciar o impacto socioambiental e liberar créditos em cashback.
                  </p>
                  <button
                    onClick={() => setIsModalOpen(true)}
                    className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-bold text-sm text-white bg-emerald-700 hover:bg-emerald-800 transition-colors shadow-sm"
                  >
                    <PlusCircle className="w-4 h-4" />
                    Cadastrar Primeira Doação
                  </button>
                </div>
              ) : (
                /* Tabela com as movimentações reais cadastradas */
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-sm">
                    <thead className="bg-slate-50 text-slate-500 text-xs uppercase font-semibold">
                      <tr>
                        <th className="px-5 py-3">Código</th>
                        <th className="px-5 py-3">Descrição / Lote</th>
                        <th className="px-5 py-3">Peso</th>
                        <th className="px-5 py-3">Destino (ONG)</th>
                        <th className="px-5 py-3">Status</th>
                        <th className="px-5 py-3">Acompanhamento</th>
                        <th className="px-5 py-3">Agendar coleta</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredDonations.map((item) => (
                        <tr key={item.id} className="hover:bg-slate-50/50 transition-colors">
                          <td className="px-5 py-3.5 font-mono text-xs font-semibold text-slate-900">
                            {item.codigo}
                          </td>
                          <td className="px-5 py-3.5 text-slate-700 font-medium">
                            {item.descricao}
                          </td>
                          <td className="px-5 py-3.5 font-bold text-slate-900">
                            {item.pesoKg} kg
                          </td>
                          <td className="px-5 py-3.5 text-slate-600">
                            {item.destino}
                          </td>
                          <td className="px-5 py-3.5">
                            <span className={`inline-flex items-center gap-1 rounded-full border px-2.5 py-1 text-xs font-semibold ${item.status === 'entregue' ? 'border-emerald-200 bg-emerald-50 text-emerald-800' : item.status === 'em_transporte' ? 'border-sky-200 bg-sky-50 text-sky-800' : item.status === 'aceita' ? 'border-violet-200 bg-violet-50 text-violet-800' : 'border-amber-200 bg-amber-50 text-amber-800'}`}>
                              {item.status === 'entregue' ? <CheckCircle2 className="h-3.5 w-3.5" /> : <Truck className="h-3.5 w-3.5" />}
                              {item.status === 'entregue' ? 'Entregue' : item.status === 'em_transporte' ? 'Em transporte' : item.status === 'aceita' ? 'ONG interessada' : 'Aguardando ONG'}
                            </span>
                          </td>
                          <td className="min-w-56 px-5 py-3.5">
                            <div className="flex items-center gap-1 text-[10px] font-semibold">
                              {(['pendente', 'aceita', 'em_transporte', 'entregue'] as const).map((step, index) => {
                                const currentIndex = ['pendente', 'aceita', 'em_transporte', 'entregue'].indexOf(item.status);
                                return <React.Fragment key={step}><span title={['Publicado', 'ONG interessada', 'Em transporte', 'Entregue'][index]} className={`h-2.5 w-2.5 shrink-0 rounded-full ${index <= currentIndex ? 'bg-emerald-600' : 'bg-slate-200'}`} /><span className={index <= currentIndex ? 'text-emerald-700' : 'text-slate-300'}>{['Publicado', 'Interesse', 'Coleta', 'Entregue'][index]}</span>{index < 3 && <span className={`h-px w-3 ${index < currentIndex ? 'bg-emerald-500' : 'bg-slate-200'}`} />}</React.Fragment>;
                              })}
                            </div>
                            {item.status === 'aceita' && <button onClick={() => updateDonation(item.id, { status: 'em_transporte' })} className="mt-2 rounded-lg bg-sky-700 px-2.5 py-1.5 text-[11px] font-bold text-white hover:bg-sky-800">Confirmar retirada</button>}
                            {item.status === 'em_transporte' && <button onClick={() => updateDonation(item.id, { status: 'entregue' })} className="mt-2 rounded-lg bg-emerald-700 px-2.5 py-1.5 text-[11px] font-bold text-white hover:bg-emerald-800">Confirmar entrega</button>}
                          </td>
                          <td className="min-w-56 px-5 py-3.5">
                            <div className="flex gap-1.5">
                              <input aria-label={`Data da coleta do lote ${item.codigo}`} type="date" min={todayIso} value={scheduleDrafts[item.id]?.data ?? item.coletaData ?? ''} onChange={(e) => setScheduleDrafts((current) => ({ ...current, [item.id]: { data: e.target.value, hora: current[item.id]?.hora ?? item.coletaHora ?? '' } }))} className="w-32 rounded-lg border border-slate-200 px-2 py-1.5 text-xs" />
                              <input aria-label={`Horário da coleta do lote ${item.codigo}`} type="time" value={scheduleDrafts[item.id]?.hora ?? item.coletaHora ?? ''} onChange={(e) => setScheduleDrafts((current) => ({ ...current, [item.id]: { data: current[item.id]?.data ?? item.coletaData ?? '', hora: e.target.value } }))} className="w-24 rounded-lg border border-slate-200 px-2 py-1.5 text-xs" />
                            </div>
                            <button onClick={() => handleSchedulePickup(item)} className="mt-1.5 rounded-lg border border-emerald-200 px-2.5 py-1.5 text-[11px] font-bold text-emerald-800 hover:bg-emerald-50">{item.coletaData ? 'Atualizar agenda' : 'Agendar coleta'}</button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                  {filteredDonations.length === 0 && <p className="px-5 py-8 text-center text-sm text-slate-500">Nenhum lote corresponde à busca ou ao filtro selecionado.</p>}
                </div>
              )}
            </div>
          </div>

          {/* Painel Lateral: Impacto Ecológico & Logística */}
          <div className="space-y-6">
            <div className="bg-white rounded-2xl border border-slate-200/80 p-5 shadow-xs">
              <div className="flex items-center gap-2 mb-3">
                <div className="p-2 rounded-lg bg-emerald-50 text-emerald-700">
                  <Leaf className="w-5 h-5" />
                </div>
                <h3 className="font-bold text-slate-900">Impacto Ambiental Gerado</h3>
              </div>
              <div className="space-y-3">
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-slate-600">Emissões de CO2 evitadas:</span>
                  <span className={`text-sm font-bold ${hasDonations ? 'text-emerald-700' : 'text-slate-400'}`}>
                    {co2EvitadoKg.toLocaleString('pt-BR')} kg CO2e
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-slate-600">Água preservada:</span>
                  <span className={`text-sm font-bold ${hasDonations ? 'text-emerald-700' : 'text-slate-400'}`}>
                    {aguaPreservadaL.toLocaleString('pt-BR')} L
                  </span>
                </div>
                <div className="p-3 rounded-xl bg-slate-50 border border-slate-100 flex items-center justify-between">
                  <span className="text-xs text-slate-600">Famílias atendidas:</span>
                  <span className={`text-sm font-bold ${hasDonations ? 'text-emerald-700' : 'text-slate-400'}`}>
                    {familiasAlimentadas} {familiasAlimentadas === 1 ? 'família' : 'famílias'}
                  </span>
                </div>
              </div>
              <p className="text-[11px] text-slate-400 mt-3 leading-relaxed">
                {hasDonations
                  ? 'Cálculos consolidados e auditados com base nas doações realizadas pela sua empresa.'
                  : 'Os cálculos de impacto ESG serão atualizados automaticamente a cada doação realizada.'}
              </p>
              <button onClick={exportImpactReport} className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-emerald-700 px-4 py-2.5 text-xs font-bold text-white hover:bg-emerald-800">
                <Download className="h-4 w-4" /> Baixar relatório de impacto (CSV)
              </button>
            </div>

            <div className="rounded-2xl border border-emerald-200 bg-emerald-50 p-5">
              <h4 className="mb-1 flex items-center gap-1.5 font-bold text-emerald-900"><Calendar className="h-4 w-4 text-emerald-700" />Agenda de coletas</h4>
              <p className="mb-3 text-xs text-emerald-700">Retiradas com data e horário definidos.</p>
              {scheduledDonations.length === 0 ? <div className="rounded-xl border border-emerald-100 bg-white p-4 text-center text-xs text-slate-500">Nenhuma coleta agendada. Defina data e horário na linha de cada lote.</div> : <div className="max-h-64 space-y-2 overflow-y-auto">{scheduledDonations.map((item) => <div key={item.id} className="rounded-xl border border-emerald-100 bg-white p-3"><div className="flex items-center justify-between gap-2"><span className="font-mono text-[11px] font-bold text-slate-800">{item.codigo}</span><span className="text-xs font-bold text-emerald-800">{item.coletaData?.split('-').reverse().join('/')} · {item.coletaHora}</span></div><p className="mt-1 truncate text-xs text-slate-600">{item.destino}</p></div>)}</div>}
            </div>
          </div>
        </div>
      </main>

    </div>
  );
}
