import React, { useState, useEffect, useRef } from 'react';
import {
  LogIn,
  UserPlus,
  Mail,
  Lock,
  Building2,
  Heart,
  ArrowLeft,
  Eye,
  EyeOff,
  Loader2,
  CheckCircle2,
  Recycle,
  AlertCircle,
  Phone,
  FileText,
  User,
  ShieldCheck,
  Sparkles,
  Zap,
  Check,
  X,
  CreditCard,
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { isValidCNPJ, formatCNPJ, isValidPhone, formatPhone, isValidEmail } from '@/lib/utils';

interface Plano {
  id: number;
  nome: string;
  preco_anual: number;
  descricao: string;
  max_doacoes_mes: number | null;
  cashback_percentual: number;
  destaque_ranking: number;
  suporte_prioritario: number;
}

interface AssinaturaAtiva {
  id?: number;
  plano_id: number;
  plano_nome: string;
  cashback_percentual?: number;
  status: string;
}

const PLANOS_PADRAO: Plano[] = [
  {
    id: 1,
    nome: 'Básico',
    preco_anual: 99.0,
    descricao: 'Ideal para pequenos comércios que querem iniciar suas doações solidárias.',
    max_doacoes_mes: 10,
    cashback_percentual: 2.0,
    destaque_ranking: 0,
    suporte_prioritario: 0,
  },
  {
    id: 2,
    nome: 'Profissional',
    preco_anual: 249.0,
    descricao: 'Perfeito para comércios com fluxo regular de doações e vendas sociais.',
    max_doacoes_mes: 50,
    cashback_percentual: 5.0,
    destaque_ranking: 1,
    suporte_prioritario: 0,
  },
  {
    id: 3,
    nome: 'Premium',
    preco_anual: 499.0,
    descricao: 'Para grandes empresas e redes com doações ilimitadas e máximo de benefícios.',
    max_doacoes_mes: null,
    cashback_percentual: 8.0,
    destaque_ranking: 1,
    suporte_prioritario: 1,
  },
];

export default function LoginPage() {
  const navigate = useNavigate();
  const { login, register, token, error: authError, clearError } = useAuth();

  const [activeTab, setActiveTab] = useState<'login' | 'register'>('login');
  const [isLoading, setIsLoading] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);

  // Estados de visibilidade de senha
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  // Campos de Login
  const [loginEmail, setLoginEmail] = useState('');
  const [loginPassword, setLoginPassword] = useState('');

  // Campos de Cadastro
  const [regTipo, setRegTipo] = useState<'comercio' | 'ong'>('comercio');
  const [regNome, setRegNome] = useState('');
  const [regEmail, setRegEmail] = useState('');
  const [regSenha, setRegSenha] = useState('');
  const [regConfirmSenha, setRegConfirmSenha] = useState('');
  const [regRazaoSocial, setRegRazaoSocial] = useState('');
  const [regCnpj, setRegCnpj] = useState('');
  const [regTelefone, setRegTelefone] = useState('');
  const [regCategoria, setRegCategoria] = useState('Supermercado');
  const [regAreaAtuacao, setRegAreaAtuacao] = useState('Alimentação e Combate à Fome');
  const [regPlanoId, setRegPlanoId] = useState<number>(2); // Profissional por padrão

  // Estados do Modal de Seleção de Plano de Anuidade (Pós-login)
  const [showPlanModal, setShowPlanModal] = useState(false);
  const [planos, setPlanos] = useState<Plano[]>(PLANOS_PADRAO);
  const [loadingPlanos, setLoadingPlanos] = useState(false);
  const [planoSelecionadoId, setPlanoSelecionadoId] = useState<number | null>(2);
  const [assinandoPlano, setAssinandoPlano] = useState(false);
  const [planoErro, setPlanoErro] = useState<string | null>(null);
  const [planoSucesso, setPlanoSucesso] = useState<string | null>(null);
  const [assinaturaAtual, setAssinaturaAtual] = useState<AssinaturaAtiva | null>(null);

  const modalRef = useRef<HTMLDivElement>(null);

  const switchTab = (tab: 'login' | 'register') => {
    setActiveTab(tab);
    setFormError(null);
    setSuccessMessage(null);
    clearError();
  };

  // Carregar lista de planos disponíveis e assinatura ativa ao abrir o modal
  const carregarPlanos = async (authToken?: string | null) => {
    setLoadingPlanos(true);
    setPlanoErro(null);

    try {
      // 1. Buscar lista de planos
      const resPlanos = await fetch(`http://localhost:3001/api/planos`);
      if (resPlanos.ok) {
        const dataPlanos = await resPlanos.json();
        const listaPlanos: Plano[] = dataPlanos.planos || [];
        setPlanos(listaPlanos);

        // Pré-selecionar o plano Profissional por padrão se não houver assinatura
        const planoProfissional = listaPlanos.find((p) => p.nome.toLowerCase() === 'profissional');
        if (planoProfissional) {
          setPlanoSelecionadoId(planoProfissional.id);
        } else if (listaPlanos.length > 0) {
          setPlanoSelecionadoId(listaPlanos[0].id);
        }
      } else {
        throw new Error('Falha ao carregar planos');
      }

      // 2. Se tiver token, buscar assinatura ativa
      const currentToken = authToken || token || localStorage.getItem('corrente_solidaria_token');
      if (currentToken && !currentToken.startsWith('local-token-')) {
        const resAssinatura = await fetch(`http://localhost:3001/api/planos/minha`, {
          headers: {
            Authorization: `Bearer ${currentToken}`,
          },
        });
        if (resAssinatura.ok) {
          const dataAssinatura = await resAssinatura.json();
          if (dataAssinatura.assinatura) {
            setAssinaturaAtual(dataAssinatura.assinatura);
            setPlanoSelecionadoId(dataAssinatura.assinatura.plano_id);
          }
        }
      }
    } catch {
      setPlanoErro('O servidor backend de planos está temporariamente inacessível. Você pode continuar para o painel.');
    } finally {
      setLoadingPlanos(false);
    }
  };

  // Submissão do Login
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setSuccessMessage(null);
    clearError();

    const cleanEmail = loginEmail.trim();
    const cleanPass = loginPassword.trim();

    if (!cleanEmail || !cleanPass) {
      setFormError('Por favor, informe seu e-mail e sua senha.');
      return;
    }

    if (!isValidEmail(cleanEmail)) {
      setFormError('E-mail inválido. Informe um e-mail no formato exemplo@dominio.com');
      return;
    }

    setIsLoading(true);
    const result = await login(cleanEmail, cleanPass);
    setIsLoading(false);

    if (result.success) {
      // Ler o usuário autenticado do localStorage para checar o tipo
      let loggedUserTipo = 'comercio';
      let currentToken: string | null = null;
      try {
        const storedUser = localStorage.getItem('corrente_solidaria_user');
        currentToken = localStorage.getItem('corrente_solidaria_token');
        if (storedUser) {
          const parsed = JSON.parse(storedUser);
          loggedUserTipo = parsed.tipo || 'comercio';
        }
      } catch {
        // Fallback
      }

      // Se for comércio: abre o modal de planos
      if (loggedUserTipo === 'comercio') {
        setShowPlanModal(true);
        carregarPlanos(currentToken);
      } else {
        // ONGs vão direto ao dashboard sem modal de plano
        navigate('/dashboard');
      }
    } else if (result.error) {
      setFormError(result.error);
    }
  };

  // Assinar ou fazer upgrade do plano selecionado
  const handleAssinarPlano = async () => {
    if (!planoSelecionadoId) {
      setPlanoErro('Selecione um plano para continuar.');
      return;
    }

    setAssinandoPlano(true);
    setPlanoErro(null);

    const currentToken = token || localStorage.getItem('corrente_solidaria_token');

    // Se estiver em modo local/offline
    if (!currentToken || currentToken.startsWith('local-token-')) {
      setPlanoSucesso('Plano selecionado com sucesso!');
      setTimeout(() => {
        navigate('/dashboard');
      }, 900);
      return;
    }

    try {
      const response = await fetch(`http://localhost:3001/api/planos/assinar`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${currentToken}`,
        },
        body: JSON.stringify({ plano_id: planoSelecionadoId }),
      });

      const data = await response.json();

      if (response.ok && data.sucesso) {
        setPlanoSucesso(data.mensagem || 'Plano assinado com sucesso!');
        setTimeout(() => {
          navigate('/dashboard');
        }, 1100);
      } else {
        setPlanoErro(data.mensagem || 'Não foi possível assinar o plano.');
      }
    } catch {
      setPlanoErro('Falha de conexão com o servidor de planos.');
    } finally {
      setAssinandoPlano(false);
    }
  };

  // Pular escolha de plano e ir ao dashboard
  const handleDecidirDepois = () => {
    setShowPlanModal(false);
    navigate('/dashboard');
  };

  // Acessibilidade: fechar modal com tecla ESC
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && showPlanModal) {
        handleDecidirDepois();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [showPlanModal]);

  // Foco inicial no modal quando aberto
  useEffect(() => {
    if (showPlanModal && modalRef.current) {
      modalRef.current.focus();
    }
  }, [showPlanModal]);

  // Submissão do Cadastro com Validação Rigorosa de CNPJ e Telefone
  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError(null);
    setSuccessMessage(null);
    clearError();

    // 1. Validação do Nome do Responsável
    if (!regNome.trim()) {
      setFormError('Informe o nome do responsável pelo cadastro.');
      return;
    }

    // 2. Validação da Razão Social
    if (!regRazaoSocial.trim()) {
      setFormError(
        regTipo === 'comercio'
          ? 'Informe a Razão Social da empresa.'
          : 'Informe a Razão Social ou Nome da Organização Social.'
      );
      return;
    }

    // 3. Validação Oficial do CNPJ (14 dígitos e dígitos verificadores)
    if (!regCnpj.trim()) {
      setFormError('Informe o CNPJ da organização.');
      return;
    }
    if (!isValidCNPJ(regCnpj)) {
      setFormError('CNPJ inválido. Digite um CNPJ válido com 14 dígitos.');
      return;
    }

    // 4. Validação Oficial do Telefone (DDD + 8 ou 9 dígitos)
    if (!regTelefone.trim()) {
      setFormError('Informe o telefone ou WhatsApp de contato.');
      return;
    }
    if (!isValidPhone(regTelefone)) {
      setFormError('Telefone inválido. Informe o DDD e o número completo (ex: (11) 98765-4321).');
      return;
    }

    // 5. Validação de E-mail
    if (!regEmail.trim()) {
      setFormError('Informe um e-mail institucional válido.');
      return;
    }
    if (!isValidEmail(regEmail)) {
      setFormError('E-mail inválido. Informe um e-mail no formato exemplo@dominio.com');
      return;
    }

    // 6. Validação de Senha
    if (regSenha.length < 6) {
      setFormError('A senha deve conter no mínimo 6 caracteres.');
      return;
    }
    if (regSenha !== regConfirmSenha) {
      setFormError('A confirmação da senha não confere.');
      return;
    }

    setIsLoading(true);
    const result = await register({
      nome: regNome.trim(),
      email: regEmail.trim(),
      senha: regSenha,
      tipo: regTipo,
      telefone: regTelefone.trim(),
      razao_social: regRazaoSocial.trim(),
      cnpj: regCnpj.trim(),
      categoria: regTipo === 'comercio' ? regCategoria : undefined,
      area_atuacao: regTipo === 'ong' ? regAreaAtuacao : undefined,
      plano_id: regTipo === 'comercio' ? regPlanoId : undefined,
    });
    setIsLoading(false);

    if (result.success) {
      setLoginEmail(regEmail.trim());
      setLoginPassword('');
      setRegNome('');
      setRegSenha('');
      setRegConfirmSenha('');
      setRegRazaoSocial('');
      setRegCnpj('');
      setRegTelefone('');
      setActiveTab('login');
      setSuccessMessage('Conta criada com sucesso! Digite sua senha para entrar no painel.');
    } else if (result.error) {
      setFormError(result.error);
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col justify-center">
      <div className="w-full flex-1 flex flex-col lg:flex-row">
        {/* Painel Esquerdo: Decorativo e Institucional */}
        <div className="lg:w-1/2 bg-gradient-to-br from-emerald-800 via-emerald-700 to-teal-900 text-white p-8 sm:p-12 lg:p-16 flex flex-col justify-between relative overflow-hidden">
          {/* Efeitos de iluminação de fundo */}
          <div className="absolute top-0 right-0 -mr-24 -mt-24 w-96 h-96 bg-white/10 rounded-full blur-3xl pointer-events-none" />
          <div className="absolute bottom-0 left-0 -ml-24 -mb-24 w-96 h-96 bg-emerald-400/10 rounded-full blur-3xl pointer-events-none" />

          {/* Topo do painel */}
          <div className="relative z-10">
            <Link
              to="/"
              className="inline-flex items-center gap-2 text-emerald-100 hover:text-white transition-colors text-sm font-medium py-1.5 px-3.5 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-sm w-fit mb-8"
            >
              <ArrowLeft className="w-4 h-4" />
              Voltar à página inicial
            </Link>

            <div className="flex items-center space-x-3 mb-6">
              <div className="p-3 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20 shadow-inner">
                <Recycle className="h-9 w-9 text-emerald-300" />
              </div>
              <span className="text-2xl font-bold tracking-tight text-white">CorrenteSolidária</span>
            </div>

            <h1 className="text-3xl sm:text-4xl font-extrabold leading-tight text-white max-w-md">
              Conectando o comércio com quem mais precisa.
            </h1>
            <p className="mt-4 text-emerald-100 text-base leading-relaxed max-w-lg">
              Reduza o desperdício de excedentes, acumule cashback socioambiental direto e fortaleça o acolhimento de organizações sociais em todo o país.
            </p>
          </div>

          {/* Destaques de benefícios */}
          <div className="relative z-10 my-8 space-y-4 max-w-md">
            <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm p-3.5 rounded-2xl border border-white/10">
              <CheckCircle2 className="w-5 h-5 text-emerald-300 shrink-0" />
              <span className="text-sm font-medium text-emerald-50">
                Retorno financeiro em cashback em cada lote entregue
              </span>
            </div>
            <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm p-3.5 rounded-2xl border border-white/10">
              <ShieldCheck className="w-5 h-5 text-emerald-300 shrink-0" />
              <span className="text-sm font-medium text-emerald-50">
                Destinação 100% auditada com rastreabilidade digital
              </span>
            </div>
            <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm p-3.5 rounded-2xl border border-white/10">
              <Building2 className="w-5 h-5 text-emerald-300 shrink-0" />
              <span className="text-sm font-medium text-emerald-50">
                Painel exclusivo para doadores e entidades sociais
              </span>
            </div>
          </div>

          <div className="relative z-10 text-xs text-emerald-200/80 pt-6 border-t border-emerald-600/40">
            Corrente Solidária · Plataforma de Impacto Socioambiental
          </div>
        </div>

        {/* Painel Direito: Formulários de Login e Cadastro */}
        <div className="lg:w-1/2 p-6 sm:p-12 lg:p-16 flex items-center justify-center bg-white">
          <div className="max-w-md w-full space-y-6">
            <div>
              <span className="text-xs font-bold uppercase tracking-wider text-emerald-700">
                Acesso à Plataforma
              </span>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight mt-1">
                {activeTab === 'login' ? 'Entrar na sua Conta' : 'Criar Nova Conta'}
              </h2>
              <p className="mt-2 text-sm text-slate-600">
                {activeTab === 'login'
                  ? 'Informe seu e-mail e senha para acessar o painel de gestão.'
                  : 'Cadastre sua empresa parceira ou organização social receptora.'}
              </p>
            </div>

            {/* Alternador de Abas (Entrar / Cadastrar) */}
            <div className="flex p-1 bg-slate-100 rounded-xl">
              <button
                type="button"
                onClick={() => switchTab('login')}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg transition-all ${
                  activeTab === 'login'
                    ? 'bg-white text-slate-900 shadow-sm font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <LogIn className="w-4 h-4 text-emerald-700" />
                Entrar
              </button>
              <button
                type="button"
                onClick={() => switchTab('register')}
                className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-lg transition-all ${
                  activeTab === 'register'
                    ? 'bg-white text-slate-900 shadow-sm font-bold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <UserPlus className="w-4 h-4 text-emerald-700" />
                Criar Conta
              </button>
            </div>

            {/* Alerta de Sucesso (após criação de conta) */}
            {successMessage && (
              <div className="p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-800 text-sm flex items-start gap-3 animate-fade-in">
                <CheckCircle2 className="w-5 h-5 shrink-0 text-emerald-600 mt-0.5" />
                <div className="leading-snug font-medium">{successMessage}</div>
              </div>
            )}

            {/* Alerta de Erro Visual */}
            {(formError || authError) && (
              <div className="p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm flex items-start gap-3 animate-fade-in">
                <AlertCircle className="w-5 h-5 shrink-0 text-rose-600 mt-0.5" />
                <div className="leading-snug">{formError || authError}</div>
              </div>
            )}

            {/* FORMULÁRIO DE LOGIN */}
            {activeTab === 'login' && (
              <form onSubmit={handleLoginSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1.5" htmlFor="login-email">
                    E-mail institucional
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                      <Mail className="h-5 w-5" />
                    </div>
                    <input
                      id="login-email"
                      type="email"
                      required
                      autoComplete="email"
                      placeholder="seuemail@empresa.com.br"
                      value={loginEmail}
                      onChange={(e) => {
                        setLoginEmail(e.target.value);
                        setFormError(null);
                        clearError();
                      }}
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600 text-slate-900 text-sm bg-white"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1.5" htmlFor="login-password">
                    Senha de acesso
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                      <Lock className="h-5 w-5" />
                    </div>
                    <input
                      id="login-password"
                      type={showPassword ? 'text' : 'password'}
                      required
                      autoComplete="current-password"
                      placeholder="••••••••"
                      value={loginPassword}
                      onChange={(e) => {
                        setLoginPassword(e.target.value);
                        setFormError(null);
                        clearError();
                      }}
                      className="w-full pl-10 pr-11 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600 text-slate-900 text-sm bg-white"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute inset-y-0 right-0 pr-3.5 flex items-center text-slate-400 hover:text-slate-600 focus:outline-none"
                    >
                      {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-bold text-white bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 transition-colors shadow-sm disabled:opacity-70 disabled:cursor-not-allowed mt-2 text-sm"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Validando acesso...
                    </>
                  ) : (
                    <>
                      <LogIn className="w-5 h-5" />
                      Entrar no Painel
                    </>
                  )}
                </button>

                {/* Dica discreta de contas pré-existentes */}
                <div className="pt-2 text-center text-xs text-slate-500">
                  Contas de teste: <span className="font-semibold text-slate-700">comercio@demo.com</span> ou{' '}
                  <span className="font-semibold text-slate-700">ong@demo.com</span> (senha: <code className="bg-slate-100 px-1 py-0.5 rounded text-emerald-800">demo123</code>)
                </div>
              </form>
            )}

            {/* FORMULÁRIO DE CADASTRO COM OPÇÕES DE COMÉRCIO E ONG */}
            {activeTab === 'register' && (
              <form onSubmit={handleRegisterSubmit} className="space-y-4">
                {/* Tipo de Perfil (Comércio ou ONG) */}
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1.5">
                    Tipo de Cadastro
                  </label>
                  <div className="grid grid-cols-2 gap-3">
                    <button
                      type="button"
                      onClick={() => setRegTipo('comercio')}
                      className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-sm font-semibold transition-all ${
                        regTipo === 'comercio'
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-800 ring-2 ring-emerald-600/20 shadow-xs'
                          : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      <Building2 className="w-4 h-4 text-emerald-600" />
                      Comércio Doador
                    </button>
                    <button
                      type="button"
                      onClick={() => setRegTipo('ong')}
                      className={`flex items-center justify-center gap-2 p-3 rounded-xl border text-sm font-semibold transition-all ${
                        regTipo === 'ong'
                          ? 'border-emerald-600 bg-emerald-50 text-emerald-800 ring-2 ring-emerald-600/20 shadow-xs'
                          : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                      }`}
                    >
                      <Heart className="w-4 h-4 text-emerald-600" />
                      ONG Receptora
                    </button>
                  </div>
                </div>

                {/* Nome do Responsável */}
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1.5" htmlFor="reg-nome">
                    Nome do Responsável
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                      <User className="h-4 w-4" />
                    </div>
                    <input
                      id="reg-nome"
                      type="text"
                      required
                      placeholder="Ex: Carlos Silva"
                      value={regNome}
                      onChange={(e) => {
                        setRegNome(e.target.value);
                        setFormError(null);
                      }}
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600 text-slate-900 text-sm bg-white"
                    />
                  </div>
                </div>

                {/* Razão Social e CNPJ */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5" htmlFor="reg-razao">
                      {regTipo === 'comercio' ? 'Razão Social' : 'Razão Social / Nome da ONG'}
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        {regTipo === 'comercio' ? <Building2 className="h-4 w-4" /> : <Heart className="h-4 w-4" />}
                      </div>
                      <input
                        id="reg-razao"
                        type="text"
                        required
                        placeholder={regTipo === 'comercio' ? 'Empresa Ltda' : 'Associação / Instituto'}
                        value={regRazaoSocial}
                        onChange={(e) => {
                          setRegRazaoSocial(e.target.value);
                          setFormError(null);
                        }}
                        className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600 text-slate-900 text-sm bg-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5" htmlFor="reg-cnpj">
                      CNPJ
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <FileText className="h-4 w-4" />
                      </div>
                      <input
                        id="reg-cnpj"
                        type="text"
                        required
                        maxLength={18}
                        placeholder="00.000.000/0000-00"
                        value={regCnpj}
                        onChange={(e) => {
                          setRegCnpj(formatCNPJ(e.target.value));
                          setFormError(null);
                        }}
                        className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600 text-slate-900 text-sm bg-white font-mono"
                      />
                    </div>
                  </div>
                </div>

                {/* Segmento Comercial (se Comércio) ou Área de Atuação (se ONG) e Telefone */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {regTipo === 'comercio' ? (
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-1.5" htmlFor="reg-cat">
                        Segmento Comercial
                      </label>
                      <select
                        id="reg-cat"
                        value={regCategoria}
                        onChange={(e) => setRegCategoria(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600 text-slate-900 text-sm bg-white"
                      >
                        <option value="Supermercado">Supermercado / Hipermercado</option>
                        <option value="Hortifruti">Hortifrúti / Sacolão</option>
                        <option value="Padaria">Padaria / Confeitaria</option>
                        <option value="Restaurante">Restaurante / Gastronomia</option>
                        <option value="Distribuidora">Distribuidora de Alimentos</option>
                        <option value="Loja de Roupas">Loja de Roupas e Vestuário</option>
                        <option value="Farmácia e Cosméticos">Farmácia e Cosméticos</option>
                        <option value="Outros">Outro Segmento Comercial</option>
                      </select>
                    </div>
                  ) : (
                    <div>
                      <label className="block text-sm font-semibold text-slate-700 mb-1.5" htmlFor="reg-area">
                        Área de Atuação Social
                      </label>
                      <select
                        id="reg-area"
                        value={regAreaAtuacao}
                        onChange={(e) => setRegAreaAtuacao(e.target.value)}
                        className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600 text-slate-900 text-sm bg-white"
                      >
                        <option value="Alimentação e Combate à Fome">Alimentação e Combate à Fome</option>
                        <option value="Vestuário e Acolhimento">Vestuário e Acolhimento</option>
                        <option value="Apoio a Famílias Vulneráveis">Apoio a Famílias Vulneráveis</option>
                        <option value="Proteção à Infância">Proteção à Infância</option>
                        <option value="Apoio a Pessoas Idosas">Apoio a Pessoas Idosas</option>
                        <option value="Outros">Outra Causa Social</option>
                      </select>
                    </div>
                  )}

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5" htmlFor="reg-telefone">
                      Telefone / WhatsApp
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <Phone className="h-4 w-4" />
                      </div>
                      <input
                        id="reg-telefone"
                        type="tel"
                        required
                        maxLength={15}
                        placeholder="(11) 98765-4321"
                        value={regTelefone}
                        onChange={(e) => {
                          setRegTelefone(formatPhone(e.target.value));
                          setFormError(null);
                        }}
                        className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600 text-slate-900 text-sm bg-white font-mono"
                      />
                    </div>
                  </div>
                </div>

                {/* E-mail Institucional */}
                <div>
                  <label className="block text-sm font-semibold text-slate-700 mb-1.5" htmlFor="reg-email">
                    E-mail Institucional
                  </label>
                  <div className="relative">
                    <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                      <Mail className="h-5 w-5" />
                    </div>
                    <input
                      id="reg-email"
                      type="email"
                      required
                      placeholder="contato@organizacao.com.br"
                      value={regEmail}
                      onChange={(e) => {
                        setRegEmail(e.target.value);
                        setFormError(null);
                      }}
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600 text-slate-900 text-sm bg-white"
                    />
                  </div>
                </div>

                {/* Senha e Confirmação */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5" htmlFor="reg-senha">
                      Senha (mínimo 6)
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <Lock className="h-4 w-4" />
                      </div>
                      <input
                        id="reg-senha"
                        type={showPassword ? 'text' : 'password'}
                        required
                        placeholder="••••••••"
                        value={regSenha}
                        onChange={(e) => {
                          setRegSenha(e.target.value);
                          setFormError(null);
                        }}
                        className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600 text-slate-900 text-sm bg-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-slate-700 mb-1.5" htmlFor="reg-confirm">
                      Confirmar Senha
                    </label>
                    <div className="relative">
                      <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
                        <Lock className="h-4 w-4" />
                      </div>
                      <input
                        id="reg-confirm"
                        type={showConfirmPassword ? 'text' : 'password'}
                        required
                        placeholder="••••••••"
                        value={regConfirmSenha}
                        onChange={(e) => {
                          setRegConfirmSenha(e.target.value);
                          setFormError(null);
                        }}
                        className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600/30 focus:border-emerald-600 text-slate-900 text-sm bg-white"
                      />
                    </div>
                  </div>
                </div>

                {/* Escolha do Plano de Anuidade Inicial para Comércio */}
                {regTipo === 'comercio' && (
                  <div className="pt-2">
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-sm font-semibold text-slate-700">
                        Plano de Anuidade Inicial
                      </label>
                      <span className="text-xs text-emerald-700 font-bold">
                        {regPlanoId === 1 && 'Básico (2% cashback)'}
                        {regPlanoId === 2 && 'Profissional (5% cashback · Mais Popular)'}
                        {regPlanoId === 3 && 'Premium (8% cashback)'}
                      </span>
                    </div>

                    <div className="grid grid-cols-3 gap-2.5">
                      {planos.map((p) => {
                        const isSelected = regPlanoId === p.id;
                        const isPopular = p.nome.toLowerCase() === 'profissional';

                        return (
                          <button
                            key={p.id}
                            type="button"
                            onClick={() => setRegPlanoId(p.id)}
                            className={`relative p-3 rounded-2xl border text-left transition-all ${
                              isSelected
                                ? 'border-emerald-600 bg-emerald-50 text-emerald-900 ring-2 ring-emerald-600/20 shadow-xs'
                                : 'border-slate-200 bg-white text-slate-600 hover:border-slate-300'
                            }`}
                          >
                            {isPopular && (
                              <span className="absolute -top-2 left-1/2 -translate-x-1/2 px-1.5 py-0.2 rounded-full bg-emerald-600 text-white text-[9px] font-black uppercase tracking-wider">
                                Popular
                              </span>
                            )}
                            <div className="font-bold text-xs text-slate-900">{p.nome}</div>
                            <div className="text-[11px] font-semibold text-emerald-700 mt-0.5">
                              {p.cashback_percentual}% cashback
                            </div>
                            <div className="text-[10px] text-slate-500 mt-1 font-mono">
                              R$ {p.preco_anual.toFixed(0)}/ano
                            </div>
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={isLoading}
                  className="w-full flex items-center justify-center gap-2 py-3 px-4 rounded-xl font-bold text-white bg-emerald-700 hover:bg-emerald-800 active:bg-emerald-900 transition-colors shadow-sm disabled:opacity-70 disabled:cursor-not-allowed mt-2 text-sm"
                >
                  {isLoading ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Criando conta e preparando painel...
                    </>
                  ) : (
                    <>
                      <UserPlus className="w-5 h-5" />
                      {regTipo === 'comercio' ? 'Finalizar Cadastro da Empresa' : 'Finalizar Cadastro da ONG'}
                    </>
                  )}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* MODAL / ETAPA DE ESCOLHA DO PLANO DE ANUIDADE */}
      {showPlanModal && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="modal-planos-titulo"
          className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-sm p-4 animate-fade-in overflow-y-auto"
        >
          <div
            ref={modalRef}
            tabIndex={-1}
            className="bg-white rounded-3xl max-w-4xl w-full p-6 sm:p-8 md:p-10 shadow-2xl border border-slate-200 relative my-8 focus:outline-none"
          >
            {/* Botão Fechar / Decidir depois */}
            <button
              type="button"
              onClick={handleDecidirDepois}
              aria-label="Fechar e decidir depois"
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-slate-600 hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Cabeçalho do Modal */}
            <div className="text-center max-w-2xl mx-auto mb-8">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold uppercase tracking-wider mb-2">
                <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
                {assinaturaAtual ? 'Sua Assinatura de Anuidade' : 'Escolha seu Plano de Anuidade'}
              </span>
              <h2 id="modal-planos-titulo" className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
                {assinaturaAtual
                  ? `Você está no plano ${assinaturaAtual.plano_nome}`
                  : 'Potencialize o impacto do seu comércio'}
              </h2>
              <p className="mt-2 text-sm text-slate-600">
                {assinaturaAtual
                  ? 'Você pode manter seu plano atual ou fazer um upgrade para desbloquear mais cashback e benefícios.'
                  : 'Selecione a assinatura anual para garantir maior percentual de cashback socioambiental e visibilidade no ranking.'}
              </p>
            </div>

            {/* Alertas */}
            {planoSucesso && (
              <div className="mb-6 p-4 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-sm flex items-center gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
                <span className="font-semibold">{planoSucesso} Redirecionando para o painel...</span>
              </div>
            )}

            {planoErro && (
              <div className="mb-6 p-4 rounded-xl bg-rose-50 border border-rose-200 text-rose-800 text-sm flex items-center gap-3">
                <AlertCircle className="w-5 h-5 text-rose-600 shrink-0" />
                <span>{planoErro}</span>
              </div>
            )}

            {/* Conteúdo dos Planos */}
            {loadingPlanos ? (
              <div className="py-16 flex flex-col items-center justify-center text-emerald-700 space-y-3">
                <Loader2 className="w-8 h-8 animate-spin text-emerald-600" />
                <p className="text-sm font-semibold text-slate-600">Carregando planos disponíveis...</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-8">
                {planos.map((plano) => {
                  const isPopular = plano.nome.toLowerCase() === 'profissional';
                  const isSelected = planoSelecionadoId === plano.id;
                  const isCurrent = assinaturaAtual?.plano_id === plano.id;

                  return (
                    <div
                      key={plano.id}
                      onClick={() => setPlanoSelecionadoId(plano.id)}
                      className={`relative flex flex-col justify-between p-6 rounded-2xl border-2 transition-all cursor-pointer ${
                        isSelected
                          ? 'border-emerald-600 bg-emerald-50/50 shadow-lg ring-2 ring-emerald-600/20'
                          : isPopular
                          ? 'border-emerald-300 bg-white shadow-sm hover:border-emerald-500'
                          : 'border-slate-200 bg-white hover:border-slate-300'
                      }`}
                    >
                      {/* Badge Destaque "Mais popular" */}
                      {isPopular && (
                        <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-emerald-600 text-white text-[11px] font-black uppercase tracking-wider shadow-sm flex items-center gap-1">
                          <Zap className="w-3 h-3 fill-white" /> Mais popular
                        </div>
                      )}

                      {/* Badge "Plano Atual" */}
                      {isCurrent && (
                        <div className="absolute -top-3 right-4 px-2.5 py-0.5 rounded-full bg-indigo-600 text-white text-[10px] font-extrabold uppercase tracking-wider shadow-xs">
                          Plano atual
                        </div>
                      )}

                      <div>
                        {/* Nome do Plano */}
                        <div className="flex items-center justify-between mt-1 mb-2">
                          <h3 className="text-xl font-bold text-slate-900">{plano.nome}</h3>
                          <div
                            className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors ${
                              isSelected
                                ? 'border-emerald-600 bg-emerald-600 text-white'
                                : 'border-slate-300 bg-white'
                            }`}
                          >
                            {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                          </div>
                        </div>

                        <p className="text-xs text-slate-500 min-h-[36px] mb-4">
                          {plano.descricao}
                        </p>

                        {/* Preço Anual */}
                        <div className="pb-4 mb-4 border-b border-slate-100">
                          <span className="text-3xl font-black text-slate-900">
                            R$ {plano.preco_anual.toFixed(2).replace('.', ',')}
                          </span>
                          <span className="text-xs text-slate-500 font-medium"> / ano</span>
                        </div>

                        {/* Lista de Benefícios */}
                        <ul className="space-y-2.5 text-xs text-slate-700">
                          <li className="flex items-center gap-2">
                            <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                            <span>
                              <strong>{plano.cashback_percentual}%</strong> de cashback garantido
                            </span>
                          </li>
                          <li className="flex items-center gap-2">
                            <Check className="w-4 h-4 text-emerald-600 shrink-0" />
                            <span>
                              {plano.max_doacoes_mes === null
                                ? 'Doações ilimitadas por mês'
                                : `Até ${plano.max_doacoes_mes} doações/mês`}
                            </span>
                          </li>
                          <li className="flex items-center gap-2">
                            <Check
                              className={`w-4 h-4 shrink-0 ${
                                plano.destaque_ranking ? 'text-emerald-600' : 'text-slate-300'
                              }`}
                            />
                            <span className={plano.destaque_ranking ? 'font-medium' : 'text-slate-400'}>
                              {plano.destaque_ranking ? 'Destaque no ranking solidário' : 'Sem destaque no ranking'}
                            </span>
                          </li>
                          <li className="flex items-center gap-2">
                            <Check
                              className={`w-4 h-4 shrink-0 ${
                                plano.suporte_prioritario ? 'text-emerald-600' : 'text-slate-300'
                              }`}
                            />
                            <span className={plano.suporte_prioritario ? 'font-medium' : 'text-slate-400'}>
                              {plano.suporte_prioritario ? 'Suporte prioritário 24/7' : 'Suporte padrão'}
                            </span>
                          </li>
                        </ul>
                      </div>

                      {/* Botão de seleção visual */}
                      <button
                        type="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          setPlanoSelecionadoId(plano.id);
                        }}
                        className={`w-full mt-6 py-2 px-3 rounded-xl text-xs font-bold transition-all ${
                          isSelected
                            ? 'bg-emerald-600 text-white shadow-sm'
                            : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                        }`}
                      >
                        {isCurrent ? (isSelected ? 'Confirmar Plano Atual' : 'Manter este Plano') : 'Selecionar'}
                      </button>
                    </div>
                  );
                })}
              </div>
            )}

            {/* Ações do Rodapé */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-4 border-t border-slate-100">
              <button
                type="button"
                onClick={handleDecidirDepois}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl border border-slate-300 text-slate-700 hover:bg-slate-50 font-semibold text-sm transition-colors text-center"
              >
                Decidir depois
              </button>

              <button
                type="button"
                disabled={assinandoPlano || !planoSelecionadoId}
                onClick={handleAssinarPlano}
                className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 active:bg-emerald-800 text-white font-bold text-sm transition-all shadow-md disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {assinandoPlano ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Processando assinatura...
                  </>
                ) : (
                  <>
                    <CreditCard className="w-4 h-4" />
                    {assinaturaAtual && assinaturaAtual.plano_id === planoSelecionadoId
                      ? 'Continuar para o Dashboard'
                      : 'Confirmar Assinatura e Entrar'}
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
