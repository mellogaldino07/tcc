// Configure VITE_API_BASE_URL no ambiente do frontend para apontar para o backend acessível por todos os dispositivos.
export const API_BASE_URL = (import.meta.env.VITE_API_BASE_URL || 'http://localhost:3001').replace(/\/$/, '');
