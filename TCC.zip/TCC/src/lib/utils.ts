import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Validação de e-mail no padrão: usuario@dominio.extensao
 * Exemplos válidos: exemplo@gmail.com, contato@empresa.com.br, user@outlook.com
 * Regras:
 *   - Deve ter texto antes do @
 *   - Deve ter um domínio após o @ (letras, números, hífens e pontos)
 *   - Deve terminar com uma extensão de pelo menos 2 caracteres (ex: .com, .br, .org)
 */
export function isValidEmail(email: string): boolean {
  const trimmed = email.trim();
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return emailRegex.test(trimmed);
}

/**
 * Validação oficial do dígito verificador de CNPJ brasileiro (14 dígitos numéricos)
 */
export function isValidCNPJ(cnpj: string): boolean {
  const clean = cnpj.replace(/\D/g, '');
  if (clean.length !== 14) return false;
  // Rejeita sequências de dígitos repetidos conhecidas (ex: 11111111111111, 00000000000000)
  if (/^(\d)\1+$/.test(clean)) return false;

  // Primeiro dígito verificador
  let size = 12;
  let numbers = clean.substring(0, size);
  let sum = 0;
  let pos = size - 7;
  for (let i = size; i >= 1; i--) {
    sum += Number(numbers.charAt(size - i)) * pos--;
    if (pos < 2) pos = 9;
  }
  let result = sum % 11 < 2 ? 0 : 11 - (sum % 11);
  if (result !== Number(clean.charAt(size))) return false;

  // Segundo dígito verificador
  size = 13;
  numbers = clean.substring(0, size);
  sum = 0;
  pos = size - 7;
  for (let i = size; i >= 1; i--) {
    sum += Number(numbers.charAt(size - i)) * pos--;
    if (pos < 2) pos = 9;
  }
  result = sum % 11 < 2 ? 0 : 11 - (sum % 11);
  if (result !== Number(clean.charAt(size))) return false;

  return true;
}

/**
 * Aplica máscara visual de CNPJ: 00.000.000/0000-00
 */
export function formatCNPJ(value: string): string {
  const clean = value.replace(/\D/g, '').slice(0, 14);
  return clean
    .replace(/^(\d{2})(\d)/, '$1.$2')
    .replace(/^(\d{2})\.(\d{3})(\d)/, '$1.$2.$3')
    .replace(/\.(\d{3})(\d)/, '.$1/$2')
    .replace(/(\d{4})(\d)/, '$1-$2');
}

/**
 * Validação de telefone brasileiro:
 * - Fixo: 10 dígitos (DDD 11-99 + 8 dígitos) -> (11) 3456-7890
 * - Celular: 11 dígitos (DDD 11-99 + 9º dígito 9 + 8 dígitos) -> (11) 98765-4321
 */
export function isValidPhone(phone: string): boolean {
  const clean = phone.replace(/\D/g, '');
  if (clean.length !== 10 && clean.length !== 11) return false;
  if (/^(\d)\1+$/.test(clean)) return false;

  const ddd = Number(clean.substring(0, 2));
  if (ddd < 11 || ddd > 99) return false;

  if (clean.length === 11 && clean.charAt(2) !== '9') return false;

  return true;
}

/**
 * Aplica máscara visual de telefone: (00) 0000-0000 ou (00) 00000-0000
 */
export function formatPhone(value: string): string {
  const clean = value.replace(/\D/g, '').slice(0, 11);
  if (clean.length > 10) {
    return clean
      .replace(/^(\d{2})(\d)/, '($1) $2')
      .replace(/(\d{5})(\d)/, '$1-$2');
  } else if (clean.length > 6) {
    return clean
      .replace(/^(\d{2})(\d)/, '($1) $2')
      .replace(/(\d{4})(\d)/, '$1-$2');
  } else if (clean.length > 2) {
    return clean.replace(/^(\d{2})(\d)/, '($1) $2');
  }
  return clean;
}
