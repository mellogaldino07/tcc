import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  useMemo,
  type ReactNode,
  type AnchorHTMLAttributes,
} from 'react';

export interface LocationState {
  pathname: string;
  search: string;
  hash: string;
  state: unknown;
}

export interface NavigateOptions {
  replace?: boolean;
  state?: unknown;
}

export type NavigateFunction = (to: string | number, options?: NavigateOptions) => void;

interface RouterContextType {
  location: LocationState;
  navigate: NavigateFunction;
}

const RouterContext = createContext<RouterContextType | null>(null);

function getCurrentLocation(): LocationState {
  if (typeof window === 'undefined') {
    return { pathname: '/', search: '', hash: '', state: null };
  }
  return {
    pathname: window.location.pathname || '/',
    search: window.location.search || '',
    hash: window.location.hash || '',
    state: window.history.state,
  };
}

export interface BrowserRouterProps {
  children: ReactNode;
}

export const BrowserRouter: React.FC<BrowserRouterProps> = ({ children }) => {
  const [location, setLocation] = useState<LocationState>(getCurrentLocation);

  useEffect(() => {
    const handlePopState = () => {
      setLocation(getCurrentLocation());
    };

    window.addEventListener('popstate', handlePopState);
    return () => {
      window.removeEventListener('popstate', handlePopState);
    };
  }, []);

  const navigate: NavigateFunction = useCallback((to, options) => {
    if (typeof to === 'number') {
      window.history.go(to);
      return;
    }

    const { replace = false, state = null } = options || {};

    if (replace) {
      window.history.replaceState(state, '', to);
    } else {
      window.history.pushState(state, '', to);
    }

    setLocation(getCurrentLocation());
    window.scrollTo(0, 0);
  }, []);

  const contextValue = useMemo(() => ({ location, navigate }), [location, navigate]);

  return <RouterContext.Provider value={contextValue}>{children}</RouterContext.Provider>;
};

export const useRouter = (): RouterContextType => {
  const context = useContext(RouterContext);
  if (!context) {
    throw new Error('useRouter deve ser utilizado dentro de um <BrowserRouter>');
  }
  return context;
};

export const useLocation = (): LocationState => {
  return useRouter().location;
};

export const useNavigate = (): NavigateFunction => {
  return useRouter().navigate;
};

export const useParams = <T extends Record<string, string | undefined>>(): T => {
  return {} as T;
};

export interface RouteProps {
  path?: string;
  index?: boolean;
  element?: ReactNode;
  children?: ReactNode;
}

export const Route: React.FC<RouteProps> = () => {
  return null;
};

function matchPath(routePath: string | undefined, currentPath: string): boolean {
  if (!routePath) return false;
  if (routePath === '*') return true;

  // Normalização de barras no final
  const cleanRoute = routePath.replace(/\/+$/, '') || '/';
  const cleanCurrent = currentPath.replace(/\/+$/, '') || '/';

  if (cleanRoute === cleanCurrent) return true;

  // Suporte a caminhos com parâmetros simples ex: /item/:id
  const routeParts = cleanRoute.split('/');
  const currentParts = cleanCurrent.split('/');

  if (routeParts.length !== currentParts.length) return false;

  return routeParts.every((part, i) => part.startsWith(':') || part === currentParts[i]);
}

export interface RoutesProps {
  children: ReactNode;
}

export const Routes: React.FC<RoutesProps> = ({ children }) => {
  const { location } = useRouter();

  const routes = React.Children.toArray(children).filter(
    (child): child is React.ReactElement<RouteProps> =>
      React.isValidElement(child) && (child.type === Route || (child.type as { name?: string }).name === 'Route')
  );

  for (const route of routes) {
    const { path, index, element } = route.props;
    if (index && location.pathname === '/') {
      return <>{element}</>;
    }
    if (matchPath(path, location.pathname)) {
      return <>{element}</>;
    }
  }

  return null;
};

export interface LinkProps extends AnchorHTMLAttributes<HTMLAnchorElement> {
  to: string;
  replace?: boolean;
  state?: unknown;
}

export const Link = React.forwardRef<HTMLAnchorElement, LinkProps>(
  ({ to, replace = false, state, onClick, children, ...rest }, ref) => {
    const { navigate } = useRouter();

    const handleClick = (e: React.MouseEvent<HTMLAnchorElement>) => {
      if (onClick) {
        onClick(e);
      }

      if (
        !e.defaultPrevented &&
        e.button === 0 &&
        !e.metaKey &&
        !e.altKey &&
        !e.ctrlKey &&
        !e.shiftKey &&
        !rest.target
      ) {
        e.preventDefault();
        navigate(to, { replace, state });
      }
    };

    return (
      <a ref={ref} href={to} onClick={handleClick} {...rest}>
        {children}
      </a>
    );
  }
);
Link.displayName = 'Link';

export interface NavigateProps {
  to: string;
  replace?: boolean;
  state?: unknown;
}

export const Navigate: React.FC<NavigateProps> = ({ to, replace = true, state }) => {
  const { navigate } = useRouter();

  useEffect(() => {
    navigate(to, { replace, state });
  }, [navigate, to, replace, state]);

  return null;
};
