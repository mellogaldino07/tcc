-- ============================================================
-- CORRENTE SOLIDÁRIA — Banco de Dados MySQL
-- Sistema que conecta comércios com ONGs para doações/vendas
-- de roupas e alimentos, com planos, cashback, metas e ranking.
-- ============================================================
-- Instruções:
--   1. Abra o MySQL Workbench, phpMyAdmin ou terminal mysql
--   2. Copie e cole este arquivo inteiro
--   3. Execute (Ctrl+Shift+Enter no Workbench, ou botão "Executar")
-- ============================================================

-- Criar o banco de dados
CREATE DATABASE IF NOT EXISTS corrente_solidaria
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE corrente_solidaria;

-- ============================================================
-- 1. TABELA: usuarios
-- Cadastro geral de todos os usuários da plataforma
-- Tipos: 'comercio', 'ong', 'admin'
-- ============================================================
CREATE TABLE IF NOT EXISTS usuarios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  senha_hash VARCHAR(255) NOT NULL,
  tipo ENUM('comercio', 'ong', 'admin') NOT NULL,
  telefone VARCHAR(20) DEFAULT NULL,
  avatar_url VARCHAR(500) DEFAULT NULL,
  ativo TINYINT(1) DEFAULT 1,
  criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  INDEX idx_usuarios_email (email),
  INDEX idx_usuarios_tipo (tipo),
  INDEX idx_usuarios_ativo (ativo)
) ENGINE=InnoDB;

-- ============================================================
-- 2. TABELA: comercios
-- Dados específicos de empresas/comércios doadores
-- ============================================================
CREATE TABLE IF NOT EXISTS comercios (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL UNIQUE,
  razao_social VARCHAR(255) NOT NULL,
  cnpj VARCHAR(20) NOT NULL UNIQUE,
  endereco VARCHAR(500) DEFAULT NULL,
  cidade VARCHAR(100) DEFAULT NULL,
  estado CHAR(2) DEFAULT NULL,
  cep VARCHAR(10) DEFAULT NULL,
  categoria ENUM('supermercado', 'restaurante', 'loja_roupas', 'padaria', 'hortifruti', 'distribuidora', 'outros') DEFAULT 'outros',
  descricao TEXT DEFAULT NULL,
  criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,

  INDEX idx_comercios_cnpj (cnpj),
  INDEX idx_comercios_cidade (cidade),
  INDEX idx_comercios_categoria (categoria),
  CONSTRAINT fk_comercios_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 3. TABELA: ongs
-- Dados específicos de ONGs e instituições receptoras
-- ============================================================
CREATE TABLE IF NOT EXISTS ongs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL UNIQUE,
  razao_social VARCHAR(255) NOT NULL,
  cnpj VARCHAR(20) NOT NULL UNIQUE,
  endereco VARCHAR(500) DEFAULT NULL,
  cidade VARCHAR(100) DEFAULT NULL,
  estado CHAR(2) DEFAULT NULL,
  cep VARCHAR(10) DEFAULT NULL,
  area_atuacao ENUM('alimentacao', 'vestuario', 'educacao', 'saude', 'acolhimento', 'outros') DEFAULT 'outros',
  descricao TEXT DEFAULT NULL,
  site_url VARCHAR(500) DEFAULT NULL,
  criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,

  INDEX idx_ongs_cnpj (cnpj),
  INDEX idx_ongs_cidade (cidade),
  INDEX idx_ongs_area (area_atuacao),
  CONSTRAINT fk_ongs_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 4. TABELA: planos
-- Planos de anuidade disponíveis para comércios
-- ============================================================
CREATE TABLE IF NOT EXISTS planos (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nome VARCHAR(100) NOT NULL,
  preco_anual DECIMAL(10,2) NOT NULL,
  descricao TEXT DEFAULT NULL,
  max_doacoes_mes INT DEFAULT NULL COMMENT 'NULL = ilimitado',
  cashback_percentual DECIMAL(5,2) DEFAULT 0.00,
  destaque_ranking TINYINT(1) DEFAULT 0,
  suporte_prioritario TINYINT(1) DEFAULT 0,
  ativo TINYINT(1) DEFAULT 1,
  criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ============================================================
-- 5. TABELA: assinaturas
-- Histórico de assinaturas de planos pelos usuários
-- ============================================================
CREATE TABLE IF NOT EXISTS assinaturas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  plano_id INT NOT NULL,
  data_inicio DATE NOT NULL,
  data_fim DATE NOT NULL,
  status ENUM('ativa', 'cancelada', 'expirada', 'pendente') DEFAULT 'ativa',
  valor_pago DECIMAL(10,2) DEFAULT NULL,
  criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,

  INDEX idx_assinaturas_usuario (usuario_id),
  INDEX idx_assinaturas_status (status),
  INDEX idx_assinaturas_periodo (data_inicio, data_fim),
  CONSTRAINT fk_assinaturas_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_assinaturas_plano FOREIGN KEY (plano_id) REFERENCES planos(id) ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 6. TABELA: doacoes
-- Registro de doações e vendas sociais entre comércios e ONGs
-- ============================================================
CREATE TABLE IF NOT EXISTS doacoes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  comercio_id INT NOT NULL,
  ong_id INT DEFAULT NULL COMMENT 'NULL = disponível para qualquer ONG',
  tipo ENUM('doacao', 'venda') NOT NULL,
  categoria_item ENUM('alimento', 'roupa', 'higiene', 'outros') NOT NULL,
  descricao VARCHAR(500) NOT NULL,
  quantidade INT DEFAULT 1,
  unidade ENUM('kg', 'litro', 'unidade', 'caixa') DEFAULT 'unidade',
  valor_estimado DECIMAL(10,2) DEFAULT 0.00,
  status ENUM('pendente', 'aceita', 'em_transito', 'entregue', 'recusada', 'cancelada') DEFAULT 'pendente',
  data_validade DATE DEFAULT NULL COMMENT 'Validade para alimentos perecíveis',
  observacoes TEXT DEFAULT NULL,
  criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
  atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  INDEX idx_doacoes_comercio (comercio_id),
  INDEX idx_doacoes_ong (ong_id),
  INDEX idx_doacoes_status (status),
  INDEX idx_doacoes_tipo (tipo),
  INDEX idx_doacoes_categoria (categoria_item),
  INDEX idx_doacoes_criado (criado_em),
  CONSTRAINT fk_doacoes_comercio FOREIGN KEY (comercio_id) REFERENCES comercios(id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_doacoes_ong FOREIGN KEY (ong_id) REFERENCES ongs(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 7. TABELA: metas
-- Metas solidárias com recompensas (cashback + badges)
-- ============================================================
CREATE TABLE IF NOT EXISTS metas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  titulo VARCHAR(255) NOT NULL,
  descricao TEXT DEFAULT NULL,
  tipo_meta ENUM('doacoes_count', 'doacoes_valor', 'kg_doados', 'ongs_atendidas') NOT NULL,
  valor_alvo DECIMAL(10,2) NOT NULL COMMENT 'Quantidade necessária para atingir a meta',
  recompensa_descricao TEXT DEFAULT NULL,
  recompensa_cashback DECIMAL(10,2) DEFAULT 0.00,
  recompensa_badge VARCHAR(100) DEFAULT NULL COMMENT 'Nome do selo/badge conquistado',
  ativo TINYINT(1) DEFAULT 1,
  criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,

  INDEX idx_metas_tipo (tipo_meta),
  INDEX idx_metas_ativo (ativo)
) ENGINE=InnoDB;

-- ============================================================
-- 8. TABELA: progresso_metas
-- Progresso individual de cada usuário em cada meta
-- ============================================================
CREATE TABLE IF NOT EXISTS progresso_metas (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  meta_id INT NOT NULL,
  valor_atual DECIMAL(10,2) DEFAULT 0.00,
  concluida TINYINT(1) DEFAULT 0,
  data_conclusao DATETIME DEFAULT NULL,
  criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uk_progresso_usuario_meta (usuario_id, meta_id),
  INDEX idx_progresso_concluida (concluida),
  CONSTRAINT fk_progresso_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_progresso_meta FOREIGN KEY (meta_id) REFERENCES metas(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 9. TABELA: cashback
-- Saldo e histórico de cashback dos usuários
-- ============================================================
CREATE TABLE IF NOT EXISTS cashback (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  doacao_id INT DEFAULT NULL,
  meta_id INT DEFAULT NULL,
  valor DECIMAL(10,2) NOT NULL,
  tipo ENUM('doacao', 'meta', 'plano', 'bonus') NOT NULL,
  descricao VARCHAR(500) DEFAULT NULL,
  status ENUM('pendente', 'creditado', 'resgatado', 'expirado') DEFAULT 'pendente',
  criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,

  INDEX idx_cashback_usuario (usuario_id),
  INDEX idx_cashback_status (status),
  INDEX idx_cashback_tipo (tipo),
  CONSTRAINT fk_cashback_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT fk_cashback_doacao FOREIGN KEY (doacao_id) REFERENCES doacoes(id) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT fk_cashback_meta FOREIGN KEY (meta_id) REFERENCES metas(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 10. TABELA: ranking
-- Rankings mensal e anual de doadores
-- ============================================================
CREATE TABLE IF NOT EXISTS ranking (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  periodo VARCHAR(7) NOT NULL COMMENT 'Formato: "2026-10" (mensal) ou "2026" (anual)',
  tipo_periodo ENUM('mensal', 'anual') NOT NULL,
  pontos INT DEFAULT 0,
  total_doacoes INT DEFAULT 0,
  total_valor DECIMAL(10,2) DEFAULT 0.00,
  posicao INT DEFAULT NULL,
  criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,

  UNIQUE KEY uk_ranking_usuario_periodo (usuario_id, periodo, tipo_periodo),
  INDEX idx_ranking_periodo (periodo, tipo_periodo),
  INDEX idx_ranking_posicao (posicao),
  INDEX idx_ranking_pontos (pontos DESC),
  CONSTRAINT fk_ranking_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ============================================================
-- 11. TABELA: notificacoes
-- Notificações do sistema para os usuários
-- ============================================================
CREATE TABLE IF NOT EXISTS notificacoes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  usuario_id INT NOT NULL,
  titulo VARCHAR(255) NOT NULL,
  mensagem TEXT NOT NULL,
  tipo ENUM('info', 'sucesso', 'aviso', 'erro') DEFAULT 'info',
  lida TINYINT(1) DEFAULT 0,
  criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,

  INDEX idx_notificacoes_usuario (usuario_id),
  INDEX idx_notificacoes_lida (lida),
  INDEX idx_notificacoes_criado (criado_em DESC),
  CONSTRAINT fk_notificacoes_usuario FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;


-- ============================================================
-- ============================================================
--                    DADOS INICIAIS (SEED)
-- ============================================================
-- ============================================================

-- ------------------------------------------------------------
-- PLANOS DE ANUIDADE
-- ------------------------------------------------------------
INSERT INTO planos (nome, preco_anual, descricao, max_doacoes_mes, cashback_percentual, destaque_ranking, suporte_prioritario) VALUES
  ('Básico',        99.00,  'Ideal para pequenos comércios que querem iniciar suas doações solidárias.',                        10,   2.00, 0, 0),
  ('Profissional', 249.00,  'Perfeito para comércios com fluxo regular de doações e vendas sociais.',                           50,   5.00, 1, 0),
  ('Premium',      499.00,  'Para grandes empresas e redes com doações ilimitadas e máximo de benefícios.',                    NULL,  8.00, 1, 1);

-- ------------------------------------------------------------
-- METAS SOLIDÁRIAS
-- ------------------------------------------------------------
INSERT INTO metas (titulo, descricao, tipo_meta, valor_alvo, recompensa_descricao, recompensa_cashback, recompensa_badge) VALUES
  ('Primeiro Passo Solidário',
   'Realize sua primeira doação cadastrada na plataforma.',
   'doacoes_count', 1,
   'Selo de boas-vindas e R$ 15,00 de cashback inicial',
   15.00, 'Primeiro Passo'),

  ('Guardião dos Alimentos',
   'Doe um total acumulado de 50 kg de alimentos para ONGs parceiras.',
   'kg_doados', 50,
   'Bônus especial de R$ 75,00 de cashback e selo Guardião',
   75.00, 'Guardião dos Alimentos'),

  ('Rede do Bem',
   'Atenda 5 ONGs distintas cadastradas na comunidade.',
   'ongs_atendidas', 5,
   'Selo exclusivo de impacto social e R$ 110,00 em cashback',
   110.00, 'Impacto Social'),

  ('Grande Benfeitor',
   'Alcance R$ 2.000,00 em valor estimado de donativos entregues.',
   'doacoes_valor', 2000,
   'Cashback de R$ 150,00 e destaque na vitrine principal',
   150.00, 'Grande Benfeitor'),

  ('Campeão da Solidariedade',
   'Complete 30 doações ao longo do ano.',
   'doacoes_count', 30,
   'Troféu digital no ranking e R$ 225,00 em cashback',
   225.00, 'Campeão da Solidariedade');

-- ------------------------------------------------------------
-- USUÁRIOS DE DEMONSTRAÇÃO
-- Senha para todos: demo123
-- Hash bcrypt de "demo123" (custo 10)
-- ------------------------------------------------------------
SET @senha_hash = '$2a$10$g9T2jVqUFMoMD7hez1GOR.8u.JU4YisV9jo8ijkd53v1GQe8EQTFq';

-- Usuário 1: Comércio (Supermercado)
INSERT INTO usuarios (nome, email, senha_hash, tipo, telefone, avatar_url) VALUES
  ('Supermercado Esperança', 'comercio@demo.com', @senha_hash, 'comercio', '(11) 98765-4321', NULL);
SET @comercio_user_id = LAST_INSERT_ID();

INSERT INTO comercios (usuario_id, razao_social, cnpj, endereco, cidade, estado, cep, categoria, descricao) VALUES
  (@comercio_user_id, 'Supermercado Esperança Ltda', '12.345.678/0001-90', 'Av. Paulista, 1000', 'São Paulo', 'SP', '01310-100', 'supermercado', 'Supermercado comprometido com o combate ao desperdício e apoio comunitário.');
SET @comercio_id = LAST_INSERT_ID();

-- Usuário 2: ONG
INSERT INTO usuarios (nome, email, senha_hash, tipo, telefone, avatar_url) VALUES
  ('Instituto Prato Cheio', 'ong@demo.com', @senha_hash, 'ong', '(11) 91234-5678', NULL);
SET @ong_user_id = LAST_INSERT_ID();

INSERT INTO ongs (usuario_id, razao_social, cnpj, endereco, cidade, estado, cep, area_atuacao, descricao, site_url) VALUES
  (@ong_user_id, 'Instituto Prato Cheio de Assistência Social', '98.765.432/0001-10', 'Rua Solidária, 500', 'São Paulo', 'SP', '01400-200', 'alimentacao', 'ONG dedicada a erradicar a fome fornecendo alimentos frescos e refeições para famílias necessitadas.', 'https://pratocheio.org.br');
SET @ong_id = LAST_INSERT_ID();

-- Usuário 3: Comércio (Padaria)
INSERT INTO usuarios (nome, email, senha_hash, tipo, telefone) VALUES
  ('Padaria Pão Dourado', 'paodourado@demo.com', @senha_hash, 'comercio', '(11) 99887-1122');
SET @comercio2_user_id = LAST_INSERT_ID();

INSERT INTO comercios (usuario_id, razao_social, cnpj, endereco, cidade, estado, cep, categoria, descricao) VALUES
  (@comercio2_user_id, 'Panificadora Pão Dourado ME', '23.456.789/0001-11', 'Rua Augusta, 450', 'São Paulo', 'SP', '01305-000', 'padaria', 'Panificadora tradicional que doa pães e bolos ao final de cada expediente.');

-- Usuário 4: Comércio (Loja de Roupas)
INSERT INTO usuarios (nome, email, senha_hash, tipo, telefone) VALUES
  ('Boutique Moda Sustentável', 'modasustentavel@demo.com', @senha_hash, 'comercio', '(11) 97711-2233');
SET @comercio3_user_id = LAST_INSERT_ID();

INSERT INTO comercios (usuario_id, razao_social, cnpj, endereco, cidade, estado, cep, categoria, descricao) VALUES
  (@comercio3_user_id, 'Boutique Moda Sustentável Eireli', '34.567.890/0001-22', 'Alameda Santos, 820', 'São Paulo', 'SP', '01418-000', 'loja_roupas', 'Moda consciente doando peças de coleções anteriores e agasalhos de inverno.');

-- Usuário 5: Admin
INSERT INTO usuarios (nome, email, senha_hash, tipo, telefone) VALUES
  ('Administrador CS', 'admin@correntesolidaria.com', @senha_hash, 'admin', '(11) 90000-0000');

-- ------------------------------------------------------------
-- ASSINATURAS DE PLANOS
-- ------------------------------------------------------------
INSERT INTO assinaturas (usuario_id, plano_id, data_inicio, data_fim, status, valor_pago) VALUES
  (@comercio_user_id,  2, '2026-01-01', '2027-01-01', 'ativa', 249.00),
  (@comercio2_user_id, 1, '2026-02-01', '2027-02-01', 'ativa',  99.00),
  (@comercio3_user_id, 3, '2026-01-15', '2027-01-15', 'ativa', 499.00);

-- ------------------------------------------------------------
-- DOAÇÕES DE EXEMPLO
-- ------------------------------------------------------------
INSERT INTO doacoes (comercio_id, ong_id, tipo, categoria_item, descricao, quantidade, unidade, valor_estimado, status, data_validade, observacoes) VALUES
  (@comercio_id, @ong_id, 'doacao', 'alimento',
   'Caixas de hortifrúti frescos (tomates, laranjas, batatas)',
   40, 'kg', 280.00, 'entregue', '2026-10-25',
   'Retirada realizada com sucesso pela equipe da ONG'),

  (@comercio_id, @ong_id, 'doacao', 'alimento',
   'Pacotes de arroz tipo 1 e feijão carioca',
   25, 'unidade', 150.00, 'aceita', '2027-03-10',
   'Aguardando agendamento de transporte voluntário'),

  (@comercio_id, NULL, 'venda', 'roupa',
   'Lote de agasalhos e camisetas infantis a preço simbólico',
   50, 'unidade', 500.00, 'pendente', NULL,
   'Disponível para ONGs de acolhimento e proteção à criança'),

  (@comercio_id, @ong_id, 'doacao', 'higiene',
   'Kits de higiene pessoal (sabonetes, pastas e escovas de dente)',
   30, 'caixa', 360.00, 'em_transito', NULL,
   'Voluntário em rota para entrega na sede da ONG'),

  (@comercio_id, @ong_id, 'doacao', 'alimento',
   'Leite integral e achocolatado em pó',
   20, 'unidade', 120.00, 'entregue', '2027-01-15',
   'Entregue para o programa de café da manhã solidário');

-- ------------------------------------------------------------
-- PROGRESSO NAS METAS (Comércio Demo)
-- ------------------------------------------------------------
INSERT INTO progresso_metas (usuario_id, meta_id, valor_atual, concluida, data_conclusao) VALUES
  (@comercio_user_id, 1,   1,      1, '2026-10-01'),   -- Primeiro Passo: concluída
  (@comercio_user_id, 2,  40.00,   0, NULL),            -- Guardião: 40/50 kg
  (@comercio_user_id, 3,   1,      0, NULL),            -- Rede do Bem: 1/5 ONGs
  (@comercio_user_id, 4, 910.00,   0, NULL),            -- Grande Benfeitor: R$910/R$2000
  (@comercio_user_id, 5,   5,      0, NULL);            -- Campeão: 5/30 doações

-- ------------------------------------------------------------
-- CASHBACK
-- ------------------------------------------------------------
INSERT INTO cashback (usuario_id, doacao_id, meta_id, valor, tipo, descricao, status) VALUES
  (@comercio_user_id, 1, NULL,  8.40, 'doacao', 'Cashback 3% sobre doação de hortifrúti (R$280)', 'creditado'),
  (@comercio_user_id, NULL, 1, 10.00, 'meta',   'Recompensa: meta "Primeiro Passo Solidário" concluída', 'creditado'),
  (@comercio_user_id, 2, NULL,  4.50, 'doacao', 'Cashback 3% sobre doação de arroz e feijão (R$150)', 'pendente'),
  (@comercio_user_id, 5, NULL,  3.60, 'doacao', 'Cashback 3% sobre doação de leite (R$120)', 'creditado'),
  (@comercio_user_id, NULL, NULL, 5.00, 'bonus', 'Bônus de boas-vindas à plataforma', 'creditado');

-- ------------------------------------------------------------
-- RANKING MENSAL (Outubro 2026)
-- ------------------------------------------------------------
INSERT INTO ranking (usuario_id, periodo, tipo_periodo, pontos, total_doacoes, total_valor, posicao) VALUES
  (@comercio_user_id,  '2026-10', 'mensal', 520, 5, 910.00, 1),
  (@comercio3_user_id, '2026-10', 'mensal', 310, 3, 620.00, 2),
  (@comercio2_user_id, '2026-10', 'mensal', 190, 2, 350.00, 3);

-- ------------------------------------------------------------
-- RANKING ANUAL (2026)
-- ------------------------------------------------------------
INSERT INTO ranking (usuario_id, periodo, tipo_periodo, pontos, total_doacoes, total_valor, posicao) VALUES
  (@comercio3_user_id, '2026', 'anual', 1580, 15, 4200.00, 1),
  (@comercio_user_id,  '2026', 'anual', 1250, 12, 3450.00, 2),
  (@comercio2_user_id, '2026', 'anual',  890,  9, 1850.00, 3);

-- ------------------------------------------------------------
-- NOTIFICAÇÕES
-- ------------------------------------------------------------
INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo, lida) VALUES
  (@comercio_user_id, 'Bem-vindo à Corrente Solidária!',
   'Sua conta foi criada com sucesso. Juntos podemos transformar o desperdício em solidariedade.', 'sucesso', 1),

  (@comercio_user_id, 'Doação Aceita!',
   'O Instituto Prato Cheio aceitou sua doação de hortifrúti frescos. Obrigado pela solidariedade!', 'sucesso', 1),

  (@comercio_user_id, 'Meta Concluída: Primeiro Passo Solidário',
   'Parabéns! Você completou sua primeira doação e ganhou R$ 10,00 de cashback + selo "Primeiro Passo".', 'sucesso', 1),

  (@comercio_user_id, 'Cashback Creditado',
   'R$ 8,40 de cashback foram creditados pela doação de hortifrúti entregue ao Instituto Prato Cheio.', 'info', 0),

  (@comercio_user_id, 'Você está em 1º no ranking mensal!',
   'Continue doando para manter a liderança no ranking de outubro. Faltam 10 kg para a meta "Guardião dos Alimentos".', 'info', 0),

  (@ong_user_id, 'Bem-vindo à Corrente Solidária!',
   'Sua organização foi cadastrada com sucesso. Agora você pode receber doações de comércios parceiros.', 'sucesso', 1),

  (@ong_user_id, 'Nova Doação Disponível',
   'O Supermercado Esperança cadastrou uma doação de arroz e feijão aguardando agendamento de retirada.', 'info', 0),

  (@ong_user_id, 'Doação em Trânsito',
   'Kits de higiene pessoal do Supermercado Esperança estão a caminho da sua sede.', 'info', 0);


-- ============================================================
-- VIEWS ÚTEIS (consultas prontas)
-- ============================================================

-- View: Resumo do ranking com nome do comércio
CREATE OR REPLACE VIEW vw_ranking_completo AS
SELECT
  r.id,
  r.periodo,
  r.tipo_periodo,
  r.posicao,
  r.pontos,
  r.total_doacoes,
  r.total_valor,
  u.nome AS nome_usuario,
  u.tipo AS tipo_usuario,
  c.razao_social,
  c.categoria
FROM ranking r
  JOIN usuarios u ON r.usuario_id = u.id
  LEFT JOIN comercios c ON u.id = c.usuario_id
ORDER BY r.tipo_periodo, r.periodo DESC, r.posicao ASC;

-- View: Doações com nomes de comércio e ONG
CREATE OR REPLACE VIEW vw_doacoes_detalhadas AS
SELECT
  d.id,
  d.tipo,
  d.categoria_item,
  d.descricao,
  d.quantidade,
  d.unidade,
  d.valor_estimado,
  d.status,
  d.data_validade,
  d.criado_em,
  c.razao_social AS comercio_nome,
  o.razao_social AS ong_nome
FROM doacoes d
  JOIN comercios c ON d.comercio_id = c.id
  LEFT JOIN ongs o ON d.ong_id = o.id
ORDER BY d.criado_em DESC;

-- View: Saldo total de cashback por usuário
CREATE OR REPLACE VIEW vw_saldo_cashback AS
SELECT
  u.id AS usuario_id,
  u.nome,
  COALESCE(SUM(CASE WHEN cb.status = 'creditado' THEN cb.valor ELSE 0 END), 0) AS total_creditado,
  COALESCE(SUM(CASE WHEN cb.status = 'resgatado' THEN cb.valor ELSE 0 END), 0) AS total_resgatado,
  COALESCE(SUM(CASE WHEN cb.status = 'creditado' THEN cb.valor ELSE 0 END), 0)
    - COALESCE(SUM(CASE WHEN cb.status = 'resgatado' THEN cb.valor ELSE 0 END), 0) AS saldo_disponivel,
  COALESCE(SUM(CASE WHEN cb.status = 'pendente' THEN cb.valor ELSE 0 END), 0) AS total_pendente
FROM usuarios u
  LEFT JOIN cashback cb ON u.id = cb.usuario_id
GROUP BY u.id, u.nome;


-- ============================================================
-- FIM DO SCRIPT
-- ============================================================
-- Credenciais de teste:
--   Comércio: comercio@demo.com     | Senha: demo123
--   ONG:      ong@demo.com          | Senha: demo123
--   Admin:    admin@correntesolidaria.com | Senha: demo123
--
-- IMPORTANTE: As senhas acima precisam ser hasheadas com bcrypt
-- na aplicação real. O hash placeholder usado aqui é apenas
-- para estrutura — gere hashes reais via sua API Node.js.
-- ============================================================
