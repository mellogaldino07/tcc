/**
 * Rotas de Metas Solidárias e Recompensas
 * Endpoints:
 * - GET /api/metas: Lista todas as metas ativas e o progresso do usuário logado
 */

const express = require('express');
const router = express.Router();
const { db } = require('../database');
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

/**
 * GET /api/metas
 * Retorna as metas disponíveis e o percentual de conclusão para o usuário atual
 */
router.get('/', (req, res) => {
  try {
    const usuarioId = req.user.id;

    const metas = db.prepare(`
      SELECT
        m.*,
        COALESCE(pm.valor_atual, 0) as valor_atual,
        COALESCE(pm.concluida, 0) as concluida,
        pm.data_conclusao,
        ROUND(MIN(100.0, (COALESCE(pm.valor_atual, 0) * 100.0 / m.valor_alvo)), 1) as percentual_concluido
      FROM metas m
      LEFT JOIN progresso_metas pm ON (pm.meta_id = m.id AND pm.usuario_id = ?)
      WHERE m.ativo = 1
      ORDER BY pm.concluida ASC, percentual_concluido DESC, m.id ASC
    `).all(usuarioId);

    const totalConcluidas = metas.filter(m => m.concluida === 1).length;

    return res.status(200).json({
      sucesso: true,
      total_metas: metas.length,
      metas_concluidas: totalConcluidas,
      metas
    });
  } catch (error) {
    console.error('Erro ao listar metas:', error);
    return res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao buscar metas do usuário.',
      erro: error.message
    });
  }
});

module.exports = router;
