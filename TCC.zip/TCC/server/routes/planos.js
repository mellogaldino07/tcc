/**
 * Rotas de Planos e Assinaturas
 * Endpoints:
 * - GET  /api/planos: Lista todos os planos de anuidade disponíveis
 * - POST /api/planos/assinar: Realiza contratação ou upgrade de plano
 */

const express = require('express');
const router = express.Router();
const { db } = require('../database');
const authMiddleware = require('../middleware/auth');

/**
 * GET /api/planos
 * Retorna os planos cadastrados na plataforma com seus benefícios e preços
 */
router.get('/', (req, res) => {
  try {
    const planos = db.prepare('SELECT * FROM planos ORDER BY preco_anual ASC').all();

    return res.status(200).json({
      sucesso: true,
      planos
    });
  } catch (error) {
    console.error('Erro ao listar planos:', error);
    return res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao listar planos de anuidade.',
      erro: error.message
    });
  }
});

/**
 * GET /api/planos/minha
 * Retorna a assinatura ativa do usuário autenticado (se existir)
 */
router.get('/minha', authMiddleware, (req, res) => {
  try {
    const usuarioId = req.user.id;

    const assinatura = db.prepare(`
      SELECT a.*, p.nome AS plano_nome, p.preco_anual, p.cashback_percentual,
             p.max_doacoes_mes, p.destaque_ranking, p.suporte_prioritario, p.descricao AS plano_descricao
      FROM assinaturas a
      JOIN planos p ON a.plano_id = p.id
      WHERE a.usuario_id = ? AND a.status = 'ativa'
      ORDER BY a.id DESC
      LIMIT 1
    `).get(usuarioId);

    return res.status(200).json({
      sucesso: true,
      assinatura: assinatura || null
    });
  } catch (error) {
    console.error('Erro ao buscar assinatura ativa:', error);
    return res.status(500).json({
      sucesso: false,
      mensagem: 'Erro interno ao consultar assinatura do usuário.',
      erro: error.message
    });
  }
});

/**
 * POST /api/planos/assinar
 * Realiza a adesão ou upgrade do plano para o comércio autenticado
 */
router.post('/assinar', authMiddleware, (req, res) => {
  try {
    const usuario = req.user;
    const { plano_id } = req.body;

    if (usuario.tipo !== 'comercio') {
      return res.status(403).json({
        sucesso: false,
        mensagem: 'Apenas usuários do tipo comércio podem contratar planos de anuidade.'
      });
    }

    if (!plano_id) {
      return res.status(400).json({
        sucesso: false,
        mensagem: 'O parâmetro plano_id é obrigatório.'
      });
    }

    const plano = db.prepare('SELECT * FROM planos WHERE id = ?').get(plano_id);
    if (!plano) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Plano não encontrado.'
      });
    }

    const hoje = new Date();
    const dataInicio = hoje.toISOString().split('T')[0];
    const dataFim = new Date(hoje.setFullYear(hoje.getFullYear() + 1)).toISOString().split('T')[0];

    const transacaoAssinatura = db.transaction(() => {
      // Expirar assinaturas ativas anteriores
      db.prepare(`
        UPDATE assinaturas
        SET status = 'expirada'
        WHERE usuario_id = ? AND status = 'ativa'
      `).run(usuario.id);

      // Inserir nova assinatura
      db.prepare(`
        INSERT INTO assinaturas (usuario_id, plano_id, data_inicio, data_fim, status, valor_pago)
        VALUES (?, ?, ?, ?, 'ativa', ?)
      `).run(usuario.id, plano.id, dataInicio, dataFim, plano.preco_anual);

      // Notificação
      db.prepare(`
        INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo)
        VALUES (?, ?, ?, 'sucesso')
      `).run(
        usuario.id,
        'Assinatura Atualizada!',
        `Seu plano foi atualizado para ${plano.nome} com sucesso! Aproveite todos os benefícios.`
      );
    });

    transacaoAssinatura();

    return res.status(200).json({
      sucesso: true,
      mensagem: `Plano ${plano.nome} assinado com sucesso!`,
      plano
    });

  } catch (error) {
    console.error('Erro ao assinar plano:', error);
    return res.status(500).json({
      sucesso: false,
      mensagem: 'Erro interno ao processar assinatura.',
      erro: error.message
    });
  }
});

module.exports = router;
