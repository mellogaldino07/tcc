const express = require('express');
const router = express.Router();
const { db } = require('../database');

// Lista todas as organizações cadastradas, sem expor e-mail ou credenciais.
router.get('/', (req, res) => {
  try {
    const ongs = db.prepare(`
      SELECT o.id, o.razao_social, o.cidade, o.estado, o.area_atuacao, o.descricao,
             u.nome AS nome_contato
      FROM ongs o
      JOIN usuarios u ON u.id = o.usuario_id
      WHERE u.ativo = 1 AND u.tipo = 'ong'
      ORDER BY o.razao_social COLLATE NOCASE ASC
    `).all();

    return res.status(200).json({ sucesso: true, ongs });
  } catch (error) {
    console.error('Erro ao listar ONGs:', error);
    return res.status(500).json({ sucesso: false, mensagem: 'Erro ao listar ONGs.', erro: error.message });
  }
});

module.exports = router;
