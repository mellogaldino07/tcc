/**
 * Rotas de Notificações do Usuário
 * Endpoints:
 * - GET   /api/notificacoes: Lista notificações do usuário logado
 * - PATCH /api/notificacoes/:id/lida: Marca uma notificação específica como lida
 * - PATCH /api/notificacoes/ler-todas: Marca todas as notificações como lidas
 */

const express = require('express');
const router = express.Router();
const { db } = require('../database');
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

/**
 * GET /api/notificacoes
 * Retorna as notificações do usuário logado
 */
router.get('/', (req, res) => {
  try {
    const usuarioId = req.user.id;
    const notificacoes = db.prepare(`
      SELECT * FROM notificacoes
      WHERE usuario_id = ?
      ORDER BY id DESC
    `).all(usuarioId);

    const naoLidas = notificacoes.filter(n => n.lida === 0).length;

    return res.status(200).json({
      sucesso: true,
      nao_lidas: naoLidas,
      total: notificacoes.length,
      notificacoes
    });
  } catch (error) {
    console.error('Erro ao listar notificações:', error);
    return res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao buscar notificações.',
      erro: error.message
    });
  }
});

/**
 * PATCH /api/notificacoes/:id/lida
 * Marca notificação específica como lida
 */
router.patch('/:id/lida', (req, res) => {
  try {
    const usuarioId = req.user.id;
    const notificacaoId = req.params.id;

    const notificacao = db.prepare(`
      SELECT * FROM notificacoes WHERE id = ? AND usuario_id = ?
    `).get(notificacaoId, usuarioId);

    if (!notificacao) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Notificação não encontrada.'
      });
    }

    db.prepare(`
      UPDATE notificacoes SET lida = 1 WHERE id = ?
    `).run(notificacaoId);

    return res.status(200).json({
      sucesso: true,
      mensagem: 'Notificação marcada como lida.'
    });
  } catch (error) {
    console.error('Erro ao atualizar notificação:', error);
    return res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao atualizar notificação.',
      erro: error.message
    });
  }
});

/**
 * PATCH /api/notificacoes/ler-todas
 * Marca todas as notificações do usuário como lidas
 */
router.patch('/ler-todas', (req, res) => {
  try {
    const usuarioId = req.user.id;

    db.prepare(`
      UPDATE notificacoes SET lida = 1 WHERE usuario_id = ?
    `).run(usuarioId);

    return res.status(200).json({
      sucesso: true,
      mensagem: 'Todas as notificações foram marcadas como lidas.'
    });
  } catch (error) {
    console.error('Erro ao marcar todas as notificações:', error);
    return res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao marcar notificações.',
      erro: error.message
    });
  }
});

module.exports = router;
