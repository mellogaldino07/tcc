/**
 * Rotas de Cashback Solidário
 * Endpoints:
 * - GET  /api/cashback: Lista extrato de cashbacks e saldo do usuário logado
 * - POST /api/cashback/resgatar: Solicita resgate de cashback disponível
 */

const express = require('express');
const router = express.Router();
const { db } = require('../database');
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

/**
 * GET /api/cashback
 * Retorna o extrato detalhado e os totais de cashback
 */
router.get('/', (req, res) => {
  try {
    const usuarioId = req.user.id;

    const extrato = db.prepare(`
      SELECT
        c.*,
        d.descricao AS doacao_descricao,
        m.titulo AS meta_titulo
      FROM cashback c
      LEFT JOIN doacoes d ON c.doacao_id = d.id
      LEFT JOIN metas m ON c.meta_id = m.id
      WHERE c.usuario_id = ?
      ORDER BY c.id DESC
    `).all(usuarioId);

    const totais = db.prepare(`
      SELECT
        COALESCE(SUM(CASE WHEN status = 'creditado' THEN valor ELSE 0 END), 0) as saldo_disponivel,
        COALESCE(SUM(CASE WHEN status = 'pendente' THEN valor ELSE 0 END), 0) as saldo_pendente,
        COALESCE(SUM(CASE WHEN status = 'resgatado' THEN valor ELSE 0 END), 0) as total_resgatado,
        COALESCE(SUM(valor), 0) as total_historico
      FROM cashback
      WHERE usuario_id = ?
    `).get(usuarioId);

    return res.status(200).json({
      sucesso: true,
      totais,
      extrato
    });
  } catch (error) {
    console.error('Erro ao consultar cashback:', error);
    return res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao consultar extrato de cashback.',
      erro: error.message
    });
  }
});

/**
 * POST /api/cashback/resgatar
 * Resgata todo ou parte do saldo disponível de cashback
 */
router.post('/resgatar', (req, res) => {
  try {
    const usuarioId = req.user.id;
    const { valor, chave_pix } = req.body;

    const saldoDisponivel = db.prepare(`
      SELECT COALESCE(SUM(valor), 0) as total
      FROM cashback
      WHERE usuario_id = ? AND status = 'creditado'
    `).get(usuarioId).total;

    const valorResgate = Number(valor) || saldoDisponivel;

    if (valorResgate <= 0) {
      return res.status(400).json({
        sucesso: false,
        mensagem: 'O valor para resgate deve ser maior que zero.'
      });
    }

    if (valorResgate > saldoDisponivel) {
      return res.status(400).json({
        sucesso: false,
        mensagem: `Saldo insuficiente. Disponível para resgate: R$ ${saldoDisponivel.toFixed(2)}.`
      });
    }

    const transacaoResgate = db.transaction(() => {
      // Inserir registro de saída/resgate de cashback
      db.prepare(`
        INSERT INTO cashback (usuario_id, valor, tipo, descricao, status)
        VALUES (?, ?, 'bonus', ?, 'resgatado')
      `).run(
        usuarioId,
        -valorResgate,
        `Resgate de cashback via PIX: ${chave_pix || 'Chave cadastrada'}`
      );

      // Notificação
      db.prepare(`
        INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo)
        VALUES (?, ?, ?, 'sucesso')
      `).run(
        usuarioId,
        'Resgate Solicitado!',
        `Solicitação de resgate de R$ ${valorResgate.toFixed(2)} recebida com sucesso.`
      );
    });

    transacaoResgate();

    return res.status(200).json({
      sucesso: true,
      mensagem: `Resgate de R$ ${valorResgate.toFixed(2)} solicitado com sucesso!`,
      valor_resgatado: valorResgate
    });

  } catch (error) {
    console.error('Erro ao resgatar cashback:', error);
    return res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao processar resgate de cashback.',
      erro: error.message
    });
  }
});

module.exports = router;
