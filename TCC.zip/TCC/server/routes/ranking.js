/**
 * Rotas de Ranking Solidário (Mensal e Anual)
 * Endpoints:
 * - GET /api/ranking?periodo=mensal|anual&perfil=comercio|ong&data=YYYY-MM|YYYY&limite=5
 * - GET /api/ranking/stream: Server-Sent Events (SSE) para atualização em tempo real
 */

const express = require('express');
const router = express.Router();
const { db } = require('../database');

// Lista de conexões ativas SSE
const clientesSSE = [];

/**
 * Emite evento SSE para todos os clientes conectados quando o ranking for recalculado
 */
function emitirEventoRanking(perfil, tipo_periodo, periodo) {
  const dados = JSON.stringify({ perfil, tipo_periodo, periodo });
  clientesSSE.forEach((res) => {
    try {
      res.write(`event: ranking-atualizado\ndata: ${dados}\n\n`);
    } catch {
      // Falha ao enviar para cliente específico tratada no close
    }
  });
}

/**
 * GET /api/ranking/stream
 * Conexão Server-Sent Events (SSE) para atualização em tempo real
 */
router.get('/stream', (req, res) => {
  res.writeHead(200, {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    'Connection': 'keep-alive',
    'X-Accel-Buffering': 'no',
    'Access-Control-Allow-Origin': '*'
  });

  // Confirmação inicial da conexão
  res.write(':ok\n\n');
  clientesSSE.push(res);

  // Heartbeat a cada ~25s para manter a conexão ativa
  const intervalId = setInterval(() => {
    try {
      res.write(':heartbeat\n\n');
    } catch {
      clearInterval(intervalId);
    }
  }, 25000);

  // Remover cliente no close
  req.on('close', () => {
    clearInterval(intervalId);
    const index = clientesSSE.indexOf(res);
    if (index !== -1) {
      clientesSSE.splice(index, 1);
    }
  });
});

/**
 * GET /api/ranking
 * Retorna o ranking ordenado por pontuação e valor doado.
 * Suporta filtros por:
 * - perfil: 'comercio' | 'ong' (padrão: comercio)
 * - periodo / tipo: 'mensal' | 'anual' (padrão: mensal)
 * - data: 'YYYY-MM' ou 'YYYY'
 * - limite: número de registros (padrão: 5)
 */
router.get('/', (req, res) => {
  try {
    const { periodo, tipo, data, perfil = 'comercio', limite } = req.query;

    const perfilNormalizado = perfil.toLowerCase() === 'ong' ? 'ong' : 'comercio';
    const tipoPeriodo = (periodo === 'anual' || tipo === 'anual') ? 'anual' : 'mensal';

    const agora = new Date();
    const periodoAtual = tipoPeriodo === 'anual'
      ? (data || agora.toISOString().slice(0, 4))
      : (data || agora.toISOString().slice(0, 7));

    const limiteFinal = Math.max(1, Math.min(100, parseInt(limite, 10) || 5));

    // Determinar JOIN e campos específicos por perfil
    const isOng = perfilNormalizado === 'ong';
    const joinTabela = isOng
      ? 'LEFT JOIN ongs o ON o.usuario_id = u.id'
      : 'LEFT JOIN comercios c ON c.usuario_id = u.id';

    const selectCampos = isOng
      ? `o.id AS ong_id,
         o.razao_social,
         o.area_atuacao AS categoria,
         o.cidade,
         o.estado,
         NULL AS plano_nome,
         0 AS destaque_ranking`
      : `c.id AS comercio_id,
         c.razao_social,
         c.categoria,
         c.cidade,
         c.estado,
         p.nome AS plano_nome,
         COALESCE(p.destaque_ranking, 0) AS destaque_ranking`;

    const extraJoinPlano = isOng
      ? ''
      : `LEFT JOIN assinaturas a ON (a.usuario_id = u.id AND a.status = 'ativa')
         LEFT JOIN planos p ON a.plano_id = p.id`;

    const rankingQuery = `
      SELECT
        r.id AS ranking_id,
        r.posicao,
        r.pontos,
        r.total_doacoes,
        r.total_valor,
        r.periodo,
        r.tipo_periodo,
        u.id AS usuario_id,
        u.nome AS usuario_nome,
        u.avatar_url,
        u.tipo AS usuario_tipo,
        ${selectCampos}
      FROM ranking r
      JOIN usuarios u ON r.usuario_id = u.id
      ${joinTabela}
      ${extraJoinPlano}
      WHERE r.tipo_periodo = ? AND r.periodo = ? AND u.tipo = ?
      ORDER BY r.posicao ASC, r.pontos DESC, r.total_valor DESC
      LIMIT ?
    `;

    const ranking = db.prepare(rankingQuery).all(tipoPeriodo, periodoAtual, perfilNormalizado, limiteFinal);

    // Estatísticas gerais do ranking selecionado
    const statsQuery = `
      SELECT
        COUNT(DISTINCT r.usuario_id) AS total_participantes,
        COALESCE(SUM(r.total_doacoes), 0) AS total_doacoes_periodo,
        COALESCE(SUM(r.total_valor), 0) AS total_valor_periodo,
        COALESCE(MAX(r.pontos), 0) AS recorde_pontos
      FROM ranking r
      JOIN usuarios u ON r.usuario_id = u.id
      WHERE r.tipo_periodo = ? AND r.periodo = ? AND u.tipo = ?
    `;
    const estatisticas = db.prepare(statsQuery).get(tipoPeriodo, periodoAtual, perfilNormalizado);

    return res.status(200).json({
      sucesso: true,
      perfil: perfilNormalizado,
      tipo_periodo: tipoPeriodo,
      periodo: periodoAtual,
      estatisticas,
      total_classificados: ranking.length,
      ranking
    });

  } catch (error) {
    console.error('Erro ao consultar ranking:', error);
    return res.status(500).json({
      sucesso: false,
      mensagem: 'Erro interno ao consultar ranking.',
      erro: error.message
    });
  }
});

module.exports = router;
module.exports.emitirEventoRanking = emitirEventoRanking;
