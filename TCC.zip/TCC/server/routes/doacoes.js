/**
 * Rotas de Gestão de Doações e Vendas Sociais
 * Endpoints:
 * - GET   /api/doacoes: Lista doações filtradas pelo perfil do usuário (ou disponíveis)
 * - GET   /api/doacoes/:id: Detalhes de uma doação específica
 * - POST  /api/doacoes: Cadastro de nova doação/venda por um comércio
 * - PATCH /api/doacoes/:id/status: Atualização de status da doação (aceitar, enviar, entregar, etc.)
 */

const express = require('express');
const router = express.Router();
const { db } = require('../database');
const authMiddleware = require('../middleware/auth');
const { emitirEventoRanking } = require('./ranking');


// ==========================================
// CONSTANTES DE PONTUAÇÃO DO RANKING SOLIDÁRIO
// ==========================================
// Comércio: 10 pontos fixos por doação + 1 ponto a cada R$ 10 de valor estimado + 5 bônus se for alimento
const COMERCIO_PONTOS_FIXOS = 10;
const COMERCIO_VALOR_POR_PONTO = 10; // R$ 10 = 1 ponto
const COMERCIO_BONUS_ALIMENTO = 5;

// ONG: 10 pontos fixos por doação recebida + 1 ponto a cada R$ 10 de valor estimado
const ONG_PONTOS_FIXOS = 10;
const ONG_VALOR_POR_PONTO = 10; // R$ 10 = 1 ponto

// Fallback de cashback sem plano ativo
const CASHBACK_PERCENTUAL_PADRAO = 1.0;

// Todas as rotas de doações exigem usuário autenticado
router.use(authMiddleware);


/**
 * Função utilitária para atualizar ranking após conclusão de doação
 * Suporta perfil 'comercio' e 'ong'
 */
function atualizarRanking(usuarioId, valorEstimado, isAlimento, perfil = 'comercio') {
  const agora = new Date();
  const mesAtual = agora.toISOString().slice(0, 7); // Ex: '2026-11'
  const anoAtual = agora.toISOString().slice(0, 4); // Ex: '2026'

  let pontosGanhos = 0;
  if (perfil === 'ong') {
    pontosGanhos = ONG_PONTOS_FIXOS + Math.floor(valorEstimado / ONG_VALOR_POR_PONTO);
  } else {
    pontosGanhos = COMERCIO_PONTOS_FIXOS + Math.floor(valorEstimado / COMERCIO_VALOR_POR_PONTO) + (isAlimento ? COMERCIO_BONUS_ALIMENTO : 0);
  }

  const upsertRanking = (periodo, tipoPeriodo) => {
    const registro = db.prepare(`
      SELECT * FROM ranking WHERE usuario_id = ? AND periodo = ? AND tipo_periodo = ?
    `).get(usuarioId, periodo, tipoPeriodo);

    if (registro) {
      db.prepare(`
        UPDATE ranking
        SET pontos = pontos + ?,
            total_doacoes = total_doacoes + 1,
            total_valor = total_valor + ?
        WHERE id = ?
      `).run(pontosGanhos, valorEstimado, registro.id);
    } else {
      db.prepare(`
        INSERT INTO ranking (usuario_id, periodo, tipo_periodo, pontos, total_doacoes, total_valor, posicao)
        VALUES (?, ?, ?, ?, 1, ?, 999)
      `).run(usuarioId, periodo, tipoPeriodo, pontosGanhos, valorEstimado);
    }

    // Recalcular posições dos concorrentes do mesmo perfil (comercio ou ong) para o período
    const concorrentes = db.prepare(`
      SELECT r.id
      FROM ranking r
      JOIN usuarios u ON r.usuario_id = u.id
      WHERE r.periodo = ? AND r.tipo_periodo = ? AND u.tipo = ?
      ORDER BY r.pontos DESC, r.total_valor DESC
    `).all(periodo, tipoPeriodo, perfil);

    const updatePosicao = db.prepare('UPDATE ranking SET posicao = ? WHERE id = ?');
    concorrentes.forEach((item, index) => {
      updatePosicao.run(index + 1, item.id);
    });

    // Notificar clientes SSE em tempo real
    try {
      emitirEventoRanking(perfil, tipoPeriodo, periodo);
    } catch (err) {
      console.error('Erro ao emitir SSE de ranking:', err);
    }
  };

  upsertRanking(mesAtual, 'mensal');
  upsertRanking(anoAtual, 'anual');
}

/**
 * Função utilitária para atualizar progresso de metas e creditar cashback de meta
 */
function atualizarMetasComercio(usuarioId, doacao) {
  // Buscar metas ativas
  const metas = db.prepare('SELECT * FROM metas WHERE ativo = 1').all();

  for (const meta of metas) {
    // Obter ou criar registro de progresso
    let progresso = db.prepare(`
      SELECT * FROM progresso_metas WHERE usuario_id = ? AND meta_id = ?
    `).get(usuarioId, meta.id);

    if (!progresso) {
      db.prepare(`
        INSERT INTO progresso_metas (usuario_id, meta_id, valor_atual, concluida)
        VALUES (?, ?, 0, 0)
      `).run(usuarioId, meta.id);
      progresso = { valor_atual: 0, concluida: 0 };
    }

    if (progresso.concluida === 1) {
      continue; // Meta já concluída anteriormente
    }

    let incremento = 0;
    if (meta.tipo_meta === 'doacoes_count') {
      incremento = 1;
    } else if (meta.tipo_meta === 'doacoes_valor') {
      incremento = Number(doacao.valor_estimado) || 0;
    } else if (meta.tipo_meta === 'kg_doados' && doacao.categoria_item === 'alimento' && doacao.unidade === 'kg') {
      incremento = Number(doacao.quantidade) || 0;
    } else if (meta.tipo_meta === 'ongs_atendidas' && doacao.ong_id) {
      // Contar ONGs distintas atendidas
      const ongsAtendidas = db.prepare(`
        SELECT COUNT(DISTINCT ong_id) as total
        FROM doacoes
        WHERE comercio_id = ? AND status = 'entregue' AND ong_id IS NOT NULL
      `).get(doacao.comercio_id).total;

      const novoTotal = ongsAtendidas;
      const concluida = novoTotal >= meta.valor_alvo ? 1 : 0;
      db.prepare(`
        UPDATE progresso_metas
        SET valor_atual = ?, concluida = ?, data_conclusao = CASE WHEN ? = 1 THEN datetime('now') ELSE NULL END
        WHERE usuario_id = ? AND meta_id = ?
      `).run(novoTotal, concluida, concluida, usuarioId, meta.id);

      if (concluida && meta.recompensa_cashback > 0) {
        db.prepare(`
          INSERT INTO cashback (usuario_id, meta_id, valor, tipo, descricao, status)
          VALUES (?, ?, ?, 'meta', ?, 'creditado')
        `).run(usuarioId, meta.id, meta.recompensa_cashback, `Bônus por atingir meta: ${meta.titulo}`);

        db.prepare(`
          INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo)
          VALUES (?, ?, ?, 'sucesso')
        `).run(usuarioId, 'Meta Atingida!', `Parabéns! Você concluiu "${meta.titulo}" e ganhou R$ ${meta.recompensa_cashback.toFixed(2)} em cashback.`);
      }
      continue;
    }

    if (incremento > 0) {
      const novoValor = (Number(progresso.valor_atual) || 0) + incremento;
      const concluida = novoValor >= meta.valor_alvo ? 1 : 0;

      db.prepare(`
        UPDATE progresso_metas
        SET valor_atual = ?, concluida = ?, data_conclusao = CASE WHEN ? = 1 THEN datetime('now') ELSE NULL END
        WHERE usuario_id = ? AND meta_id = ?
      `).run(novoValor, concluida, concluida, usuarioId, meta.id);

      if (concluida && meta.recompensa_cashback > 0) {
        db.prepare(`
          INSERT INTO cashback (usuario_id, meta_id, valor, tipo, descricao, status)
          VALUES (?, ?, ?, 'meta', ?, 'creditado')
        `).run(usuarioId, meta.id, meta.recompensa_cashback, `Bônus por atingir meta: ${meta.titulo}`);

        db.prepare(`
          INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo)
          VALUES (?, ?, ?, 'sucesso')
        `).run(usuarioId, 'Meta Atingida!', `Parabéns! Você concluiu "${meta.titulo}" e ganhou R$ ${meta.recompensa_cashback.toFixed(2)} em cashback.`);
      }
    }
  }
}

/**
 * GET /api/doacoes
 * Lista doações com filtros por perfil (comércio, ONG ou admin) e parâmetros de query.
 */
router.get('/', (req, res) => {
  try {
    const { status, tipo, categoria, disponiveis } = req.query;
    const usuario = req.user;

    let query = `
      SELECT
        d.*,
        c.razao_social AS comercio_nome,
        c.cidade AS comercio_cidade,
        c.estado AS comercio_estado,
        c.categoria AS comercio_categoria,
        u_com.telefone AS comercio_telefone,
        o.razao_social AS ong_nome,
        o.cidade AS ong_cidade,
        o.area_atuacao AS ong_area_atuacao
      FROM doacoes d
      JOIN comercios c ON d.comercio_id = c.id
      JOIN usuarios u_com ON c.usuario_id = u_com.id
      LEFT JOIN ongs o ON d.ong_id = o.id
      WHERE 1=1
    `;
    const params = [];

    // Filtros por perfil
    if (usuario.tipo === 'comercio') {
      if (!req.comercio) {
        return res.status(400).json({ sucesso: false, mensagem: 'Perfil de comércio não localizado.' });
      }
      query += ` AND d.comercio_id = ?`;
      params.push(req.comercio.id);
    } else if (usuario.tipo === 'ong') {
      if (!req.ong) {
        return res.status(400).json({ sucesso: false, mensagem: 'Perfil de ONG não localizado.' });
      }
      // Se solicitou apenas disponíveis (abertas para resgate)
      if (disponiveis === 'true') {
        query += ` AND d.status = 'pendente' AND (d.ong_id IS NULL OR d.ong_id = ?)`;
        params.push(req.ong.id);
      } else {
        // Mostra doações associadas à ONG ou doações disponíveis
        query += ` AND (d.ong_id = ? OR (d.status = 'pendente' AND d.ong_id IS NULL))`;
        params.push(req.ong.id);
      }
    }

    // Filtros opcionais via query string
    if (status) {
      query += ` AND d.status = ?`;
      params.push(status);
    }
    if (tipo) {
      query += ` AND d.tipo = ?`;
      params.push(tipo);
    }
    if (categoria) {
      query += ` AND d.categoria_item = ?`;
      params.push(categoria);
    }

    query += ` ORDER BY d.id DESC`;

    const doacoes = db.prepare(query).all(...params);

    return res.status(200).json({
      sucesso: true,
      total: doacoes.length,
      doacoes
    });
  } catch (error) {
    console.error('Erro ao listar doações:', error);
    return res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao listar doações.',
      erro: error.message
    });
  }
});

/**
 * GET /api/doacoes/:id
 * Retorna os detalhes de uma doação pelo ID
 */
router.get('/:id', (req, res) => {
  try {
    const doacaoId = req.params.id;

    const doacao = db.prepare(`
      SELECT
        d.*,
        c.razao_social AS comercio_nome,
        c.cnpj AS comercio_cnpj,
        c.cidade AS comercio_cidade,
        c.estado AS comercio_estado,
        u_com.email AS comercio_email,
        u_com.telefone AS comercio_telefone,
        o.razao_social AS ong_nome,
        o.cnpj AS ong_cnpj,
        o.cidade AS ong_cidade,
        o.site_url AS ong_site
      FROM doacoes d
      JOIN comercios c ON d.comercio_id = c.id
      JOIN usuarios u_com ON c.usuario_id = u_com.id
      LEFT JOIN ongs o ON d.ong_id = o.id
      WHERE d.id = ?
    `).get(doacaoId);

    if (!doacao) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Doação não encontrada.'
      });
    }

    return res.status(200).json({
      sucesso: true,
      doacao
    });
  } catch (error) {
    console.error('Erro ao buscar doação:', error);
    return res.status(500).json({
      sucesso: false,
      mensagem: 'Erro ao buscar doação.',
      erro: error.message
    });
  }
});

/**
 * POST /api/doacoes
 * Cadastra uma nova doação ou oferta de venda social por parte de um comércio.
 */
router.post('/', (req, res) => {
  try {
    const usuario = req.user;

    if (usuario.tipo !== 'comercio') {
      return res.status(403).json({
        sucesso: false,
        mensagem: 'Apenas usuários do tipo comércio podem cadastrar doações.'
      });
    }

    if (!req.comercio) {
      return res.status(400).json({
        sucesso: false,
        mensagem: 'Dados de comércio não encontrados para este usuário.'
      });
    }

    const {
      tipo, // 'doacao' | 'venda'
      categoria_item, // 'alimento' | 'roupa' | 'higiene' | 'outros'
      descricao,
      quantidade,
      unidade, // 'kg' | 'litro' | 'unidade' | 'caixa'
      valor_estimado,
      data_validade,
      observacoes,
      ong_id
    } = req.body;

    // Validações
    if (!tipo || !categoria_item || !descricao) {
      return res.status(400).json({
        sucesso: false,
        mensagem: 'Campos tipo, categoria_item e descricao são obrigatórios.'
      });
    }

    if (!['doacao', 'venda'].includes(tipo)) {
      return res.status(400).json({
        sucesso: false,
        mensagem: "Tipo inválido. Deve ser 'doacao' ou 'venda'."
      });
    }

    if (!['alimento', 'roupa', 'higiene', 'outros'].includes(categoria_item)) {
      return res.status(400).json({
        sucesso: false,
        mensagem: "Categoria inválida. Deve ser 'alimento', 'roupa', 'higiene' ou 'outros'."
      });
    }

    // Verificar limite do plano da assinatura no mês atual
    const assinatura = req.user.assinatura;
    if (assinatura && assinatura.max_doacoes_mes !== null) {
      const mesAtual = new Date().toISOString().slice(0, 7); // Ex: '2026-10'
      const doacoesMes = db.prepare(`
        SELECT COUNT(*) as total
        FROM doacoes
        WHERE comercio_id = ? AND strftime('%Y-%m', criado_em) = ?
      `).get(req.comercio.id, mesAtual).total;

      if (doacoesMes >= assinatura.max_doacoes_mes) {
        return res.status(403).json({
          sucesso: false,
          mensagem: `Limite mensal de doações atingido para o plano ${assinatura.plano_nome} (${assinatura.max_doacoes_mes} doações/mês). Considere fazer upgrade de plano.`
        });
      }
    }

    const statusInicial = ong_id ? 'aceita' : 'pendente';

    const insertStmt = db.prepare(`
      INSERT INTO doacoes (
        comercio_id, ong_id, tipo, categoria_item, descricao,
        quantidade, unidade, valor_estimado, status, data_validade, observacoes
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const resultado = insertStmt.run(
      req.comercio.id,
      ong_id || null,
      tipo,
      categoria_item,
      descricao,
      quantidade || 1,
      unidade || 'unidade',
      valor_estimado || 0,
      statusInicial,
      data_validade || null,
      observacoes || null
    );

    const novaDoacaoId = resultado.lastInsertRowid;

    // Se uma ONG específica foi selecionada, notificar o usuário da ONG
    if (ong_id) {
      const ongDestino = db.prepare('SELECT usuario_id FROM ongs WHERE id = ?').get(ong_id);
      if (ongDestino) {
        db.prepare(`
          INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo)
          VALUES (?, ?, ?, 'info')
        `).run(
          ongDestino.usuario_id,
          'Nova Doação Direcionada!',
          `${req.comercio.razao_social} destinou uma nova doação para sua instituição: ${descricao}.`,
          'info'
        );
      }
    }

    const novaDoacao = db.prepare('SELECT * FROM doacoes WHERE id = ?').get(novaDoacaoId);

    return res.status(201).json({
      sucesso: true,
      mensagem: 'Doação cadastrada com sucesso!',
      doacao: novaDoacao
    });

  } catch (error) {
    console.error('Erro ao cadastrar doação:', error);
    return res.status(500).json({
      sucesso: false,
      mensagem: 'Erro interno ao cadastrar doação.',
      erro: error.message
    });
  }
});

/**
 * PATCH /api/doacoes/:id/status
 * Atualiza o status da doação (aceitar, despachar, entregar, cancelar, recusar).
 * Dispara cashback, progresso de metas e atualização de ranking quando 'entregue'.
 */
router.patch('/:id/status', (req, res) => {
  try {
    const doacaoId = req.params.id;
    const { status, observacoes } = req.body;
    const usuario = req.user;

    const statusValidos = ['pendente', 'aceita', 'em_transito', 'entregue', 'recusada', 'cancelada'];
    if (!status || !statusValidos.includes(status)) {
      return res.status(400).json({
        sucesso: false,
        mensagem: `Status inválido. Escolha entre: ${statusValidos.join(', ')}.`
      });
    }

    const doacao = db.prepare(`
      SELECT d.*, c.usuario_id as comercio_usuario_id
      FROM doacoes d
      JOIN comercios c ON d.comercio_id = c.id
      WHERE d.id = ?
    `).get(doacaoId);

    if (!doacao) {
      return res.status(404).json({
        sucesso: false,
        mensagem: 'Doação não encontrada.'
      });
    }

    // Regras de autorização por perfil
    if (usuario.tipo === 'comercio') {
      if (doacao.comercio_id !== req.comercio.id) {
        return res.status(403).json({
          sucesso: false,
          mensagem: 'Você só pode alterar status de doações do seu próprio comércio.'
        });
      }
    } else if (usuario.tipo === 'ong') {
      if (!req.ong) {
        return res.status(400).json({ sucesso: false, mensagem: 'Perfil de ONG não associado.' });
      }
      // Se a ONG está aceitando uma doação livre pendente
      if (status === 'aceita' && doacao.status === 'pendente') {
        db.prepare('UPDATE doacoes SET ong_id = ? WHERE id = ?').run(req.ong.id, doacaoId);
        doacao.ong_id = req.ong.id;
      } else if (doacao.ong_id && doacao.ong_id !== req.ong.id) {
        return res.status(403).json({
          sucesso: false,
          mensagem: 'Esta doação está associada a outra ONG.'
        });
      }
    }

    // Executar atualização em transação para garantir integridade com cashback e metas
    const atualizarTransacao = db.transaction(() => {
      db.prepare(`
        UPDATE doacoes
        SET status = ?,
            observacoes = COALESCE(?, observacoes),
            atualizado_em = datetime('now')
        WHERE id = ?
      `).run(status, observacoes || null, doacaoId);

      // Ações desencadeadas quando a doação é dada como entregue
      if (status === 'entregue' && doacao.status !== 'entregue') {
        const valorEstimado = Number(doacao.valor_estimado) || 0;
        const comercioUsuarioId = doacao.comercio_usuario_id;

        // 1. Calcular e creditar cashback para o comércio
        const assinatura = db.prepare(`
          SELECT p.cashback_percentual
          FROM assinaturas a
          JOIN planos p ON a.plano_id = p.id
          WHERE a.usuario_id = ? AND a.status = 'ativa'
          ORDER BY a.id DESC LIMIT 1
        `).get(comercioUsuarioId);

        const cashbackPercentual = assinatura ? assinatura.cashback_percentual : CASHBACK_PERCENTUAL_PADRAO;
        const valorCashback = Number(((valorEstimado * cashbackPercentual) / 100).toFixed(2));

        if (valorCashback > 0) {
          db.prepare(`
            INSERT INTO cashback (usuario_id, doacao_id, valor, tipo, descricao, status)
            VALUES (?, ?, ?, 'doacao', ?, 'creditado')
          `).run(
            comercioUsuarioId,
            doacaoId,
            valorCashback,
            `Cashback de ${cashbackPercentual}% sobre doação entregue #${doacaoId}`
          );

          db.prepare(`
            INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo)
            VALUES (?, ?, ?, 'sucesso')
          `).run(
            comercioUsuarioId,
            'Cashback Creditado!',
            `Você recebeu R$ ${valorCashback.toFixed(2)} de cashback pela doação entregue com sucesso.`
          );
        }

        // 2. Atualizar metas do comércio
        atualizarMetasComercio(comercioUsuarioId, doacao);

        // 3. Atualizar ranking de pontuação (Comércio e ONG vinculada)
        const isAlimento = doacao.categoria_item === 'alimento';
        atualizarRanking(comercioUsuarioId, valorEstimado, isAlimento, 'comercio');

        if (doacao.ong_id) {
          const ongDestino = db.prepare('SELECT usuario_id FROM ongs WHERE id = ?').get(doacao.ong_id);
          if (ongDestino && ongDestino.usuario_id) {
            atualizarRanking(ongDestino.usuario_id, valorEstimado, isAlimento, 'ong');
          }
        }

        // 4. Notificar a outra parte sobre a entrega concluída
        const notificacaoAlvo = usuario.tipo === 'ong' ? comercioUsuarioId : (
          doacao.ong_id ? db.prepare('SELECT usuario_id FROM ongs WHERE id = ?').get(doacao.ong_id)?.usuario_id : null
        );

        if (notificacaoAlvo) {
          db.prepare(`
            INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo)
            VALUES (?, ?, ?, 'sucesso')
          `).run(
            notificacaoAlvo,
            'Doação Concluída!',
            `A doação #${doacaoId} (${doacao.descricao}) foi marcada como entregue!`
          );
        }
      }
    });

    atualizarTransacao();

    const doacaoAtualizada = db.prepare('SELECT * FROM doacoes WHERE id = ?').get(doacaoId);

    return res.status(200).json({
      sucesso: true,
      mensagem: `Status da doação atualizado para '${status}' com sucesso!`,
      doacao: doacaoAtualizada
    });

  } catch (error) {
    console.error('Erro ao atualizar status da doação:', error);
    return res.status(500).json({
      sucesso: false,
      mensagem: 'Erro interno ao atualizar status da doação.',
      erro: error.message
    });
  }
});

module.exports = router;
