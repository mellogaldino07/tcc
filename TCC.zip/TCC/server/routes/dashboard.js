/**
 * Rotas de Dashboard e Indicadores
 * Endpoint:
 * - GET /api/dashboard: Retorna estatísticas consolidadas, cashback, metas e resumo adaptado ao perfil do usuário
 */

const express = require('express');
const router = express.Router();
const { db } = require('../database');
const authMiddleware = require('../middleware/auth');

router.use(authMiddleware);

/**
 * GET /api/dashboard
 * Retorna os indicadores e dados consolidados para o usuário logado (comércio, ONG ou admin).
 */
router.get('/', (req, res) => {
  try {
    const usuario = req.user;
    const agora = new Date();
    const mesAtual = agora.toISOString().slice(0, 7); // '2026-10'
    const anoAtual = agora.toISOString().slice(0, 4); // '2026'

    // Notificações recentes
    const notificacoesRecentes = db.prepare(`
      SELECT * FROM notificacoes
      WHERE usuario_id = ?
      ORDER BY id DESC
      LIMIT 5
    `).all(usuario.id);

    const notificacoesNaoLidas = db.prepare(`
      SELECT COUNT(*) as total FROM notificacoes
      WHERE usuario_id = ? AND lida = 0
    `).get(usuario.id).total;

    // Resposta para perfil COMÉRCIO
    if (usuario.tipo === 'comercio') {
      const comercioId = req.comercio?.id;

      // 1. Estatísticas de Doações
      const statsDoacoes = db.prepare(`
        SELECT
          COUNT(*) as total_geral,
          COALESCE(SUM(CASE WHEN status = 'entregue' THEN 1 ELSE 0 END), 0) as total_entregues,
          COALESCE(SUM(CASE WHEN status = 'em_transito' THEN 1 ELSE 0 END), 0) as total_em_transito,
          COALESCE(SUM(CASE WHEN status = 'pendente' THEN 1 ELSE 0 END), 0) as total_pendentes,
          COALESCE(SUM(CASE WHEN status = 'aceita' THEN 1 ELSE 0 END), 0) as total_aceitas,
          COALESCE(SUM(CASE WHEN status = 'entregue' THEN valor_estimado ELSE 0 END), 0) as valor_total_entregue,
          COALESCE(SUM(valor_estimado), 0) as valor_total_cadastrado,
          COALESCE(SUM(CASE WHEN categoria_item = 'alimento' AND unidade = 'kg' AND status = 'entregue' THEN quantidade ELSE 0 END), 0) as kg_alimentos_doados
        FROM doacoes
        WHERE comercio_id = ?
      `).get(comercioId || 0);

      // Doações feitas no mês atual (para checagem do plano)
      const doacoesMesAtual = db.prepare(`
        SELECT COUNT(*) as total
        FROM doacoes
        WHERE comercio_id = ? AND strftime('%Y-%m', criado_em) = ?
      `).get(comercioId || 0, mesAtual).total;

      // 2. Saldos de Cashback
      const statsCashback = db.prepare(`
        SELECT
          COALESCE(SUM(CASE WHEN status = 'creditado' THEN valor ELSE 0 END), 0) as saldo_disponivel,
          COALESCE(SUM(CASE WHEN status = 'pendente' THEN valor ELSE 0 END), 0) as saldo_pendente,
          COALESCE(SUM(CASE WHEN status = 'resgatado' THEN valor ELSE 0 END), 0) as total_resgatado,
          COALESCE(SUM(valor), 0) as total_acumulado
        FROM cashback
        WHERE usuario_id = ?
      `).get(usuario.id);

      const ultimosCashbacks = db.prepare(`
        SELECT * FROM cashback
        WHERE usuario_id = ?
        ORDER BY id DESC
        LIMIT 5
      `).all(usuario.id);

      // 3. Posição no Ranking (Mensal e Anual)
      const rankingMensal = db.prepare(`
        SELECT posicao, pontos, total_doacoes, total_valor
        FROM ranking
        WHERE usuario_id = ? AND periodo = ? AND tipo_periodo = 'mensal'
      `).get(usuario.id, mesAtual);

      const rankingAnual = db.prepare(`
        SELECT posicao, pontos, total_doacoes, total_valor
        FROM ranking
        WHERE usuario_id = ? AND periodo = ? AND tipo_periodo = 'anual'
      `).get(usuario.id, anoAtual);

      // 4. Progresso nas Metas
      const metasProgresso = db.prepare(`
        SELECT
          m.id AS meta_id,
          m.titulo,
          m.descricao,
          m.tipo_meta,
          m.valor_alvo,
          m.recompensa_descricao,
          m.recompensa_cashback,
          m.recompensa_badge,
          COALESCE(pm.valor_atual, 0) AS valor_atual,
          COALESCE(pm.concluida, 0) AS concluida,
          pm.data_conclusao,
          ROUND(MIN(100.0, (COALESCE(pm.valor_atual, 0) * 100.0 / m.valor_alvo)), 1) AS percentual_concluido
        FROM metas m
        LEFT JOIN progresso_metas pm ON (pm.meta_id = m.id AND pm.usuario_id = ?)
        WHERE m.ativo = 1
        ORDER BY pm.concluida ASC, percentual_concluido DESC
      `).all(usuario.id);

      // 5. Últimas Doações
      const ultimasDoacoes = db.prepare(`
        SELECT
          d.*,
          o.razao_social AS ong_nome
        FROM doacoes d
        LEFT JOIN ongs o ON d.ong_id = o.id
        WHERE d.comercio_id = ?
        ORDER BY d.id DESC
        LIMIT 5
      `).all(comercioId || 0);

      // 6. Dados da Assinatura e Limites
      const assinatura = usuario.assinatura || null;
      const limiteMensal = assinatura ? assinatura.max_doacoes_mes : null;
      const doacoesRestantes = limiteMensal !== null ? Math.max(0, limiteMensal - doacoesMesAtual) : 'ilimitado';

      return res.status(200).json({
        sucesso: true,
        perfil: 'comercio',
        usuario: {
          id: usuario.id,
          nome: usuario.nome,
          email: usuario.email,
          telefone: usuario.telefone,
          avatar_url: usuario.avatar_url,
          comercio: req.comercio
        },
        assinatura: {
          ...assinatura,
          doacoes_mes_atual: doacoesMesAtual,
          doacoes_restantes_mes: doacoesRestantes
        },
        estatisticas: {
          doacoes: statsDoacoes,
          cashback: statsCashback,
          ranking_mensal: rankingMensal || { posicao: '-', pontos: 0 },
          ranking_anual: rankingAnual || { posicao: '-', pontos: 0 }
        },
        metas: metasProgresso,
        ultimas_doacoes: ultimasDoacoes,
        ultimos_cashbacks: ultimosCashbacks,
        notificacoes: {
          nao_lidas: notificacoesNaoLidas,
          itens: notificacoesRecentes
        }
      });
    }

    // Resposta para perfil ONG
    if (usuario.tipo === 'ong') {
      const ongId = req.ong?.id;

      // 1. Estatísticas de Doações para a ONG
      const statsDoacoesOng = db.prepare(`
        SELECT
          COUNT(*) as total_recebidas,
          COALESCE(SUM(CASE WHEN status = 'entregue' THEN 1 ELSE 0 END), 0) as total_entregues,
          COALESCE(SUM(CASE WHEN status = 'em_transito' THEN 1 ELSE 0 END), 0) as total_em_transito,
          COALESCE(SUM(CASE WHEN status = 'aceita' THEN 1 ELSE 0 END), 0) as total_aceitas,
          COALESCE(SUM(CASE WHEN status = 'entregue' THEN valor_estimado ELSE 0 END), 0) as valor_total_recebido,
          COALESCE(SUM(CASE WHEN categoria_item = 'alimento' AND unidade = 'kg' AND status = 'entregue' THEN quantidade ELSE 0 END), 0) as kg_alimentos_recebidos
        FROM doacoes
        WHERE ong_id = ?
      `).get(ongId || 0);

      // Comércios distintos parceiros
      const totalComerciosParceiros = db.prepare(`
        SELECT COUNT(DISTINCT comercio_id) as total
        FROM doacoes
        WHERE ong_id = ? AND status IN ('aceita', 'em_transito', 'entregue')
      `).get(ongId || 0).total;

      // Total de doações pendentes no sistema disponíveis para resgate
      const doacoesDisponiveis = db.prepare(`
        SELECT COUNT(*) as total
        FROM doacoes
        WHERE status = 'pendente' AND (ong_id IS NULL OR ong_id = ?)
      `).get(ongId || 0).total;

      // Últimas doações da ONG
      const ultimasDoacoesOng = db.prepare(`
        SELECT
          d.*,
          c.razao_social AS comercio_nome,
          c.cidade AS comercio_cidade,
          c.estado AS comercio_estado
        FROM doacoes d
        JOIN comercios c ON d.comercio_id = c.id
        WHERE d.ong_id = ?
        ORDER BY d.id DESC
        LIMIT 5
      `).all(ongId || 0);

      // Doações pendentes disponíveis recentes para pegar
      const oportunidadesRecentes = db.prepare(`
        SELECT
          d.*,
          c.razao_social AS comercio_nome,
          c.cidade AS comercio_cidade,
          c.estado AS comercio_estado
        FROM doacoes d
        JOIN comercios c ON d.comercio_id = c.id
        WHERE d.status = 'pendente' AND d.ong_id IS NULL
        ORDER BY d.id DESC
        LIMIT 5
      `).all();

      return res.status(200).json({
        sucesso: true,
        perfil: 'ong',
        usuario: {
          id: usuario.id,
          nome: usuario.nome,
          email: usuario.email,
          telefone: usuario.telefone,
          avatar_url: usuario.avatar_url,
          ong: req.ong
        },
        estatisticas: {
          doacoes: statsDoacoesOng,
          total_comercios_parceiros: totalComerciosParceiros,
          doacoes_disponiveis_para_resgate: doacoesDisponiveis
        },
        ultimas_doacoes: ultimasDoacoesOng,
        oportunidades_disponiveis: oportunidadesRecentes,
        notificacoes: {
          nao_lidas: notificacoesNaoLidas,
          itens: notificacoesRecentes
        }
      });
    }

    // Resposta para perfil ADMIN / Geral
    const statsAdmin = {
      total_usuarios: db.prepare('SELECT COUNT(*) as total FROM usuarios').get().total,
      total_comercios: db.prepare('SELECT COUNT(*) as total FROM comercios').get().total,
      total_ongs: db.prepare('SELECT COUNT(*) as total FROM ongs').get().total,
      total_doacoes: db.prepare('SELECT COUNT(*) as total FROM doacoes').get().total,
      total_valor_doado: db.prepare("SELECT COALESCE(SUM(valor_estimado), 0) as total FROM doacoes WHERE status = 'entregue'").get().total,
      total_cashback_gerado: db.prepare("SELECT COALESCE(SUM(valor), 0) as total FROM cashback WHERE status = 'creditado'").get().total
    };

    return res.status(200).json({
      sucesso: true,
      perfil: 'admin',
      usuario: {
        id: usuario.id,
        nome: usuario.nome,
        email: usuario.email,
        tipo: usuario.tipo
      },
      estatisticas: statsAdmin,
      notificacoes: {
        nao_lidas: notificacoesNaoLidas,
        itens: notificacoesRecentes
      }
    });

  } catch (error) {
    console.error('Erro no dashboard:', error);
    return res.status(500).json({
      sucesso: false,
      mensagem: 'Erro interno ao carregar dados do dashboard.',
      erro: error.message
    });
  }
});

module.exports = router;
