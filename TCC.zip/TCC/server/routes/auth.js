/**
 * Rotas de Autenticação e Gestão de Usuários
 * Endpoints:
 * - POST /api/auth/registro: Cadastro de novos usuários (comércio, ong ou admin)
 * - POST /api/auth/login: Autenticação via e-mail e senha com retorno de token JWT
 * - GET  /api/auth/me: Obter dados do usuário logado via token
 */

const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { db } = require('../database');
const authMiddleware = require('../middleware/auth');

const JWT_SECRET = process.env.JWT_SECRET || 'corrente-solidaria-secret-key-2026';

/**
 * POST /api/auth/registro
 * Cadastra um novo usuário no sistema, associando os dados específicos de comércio ou ONG.
 */
router.post('/registro', (req, res) => {
  try {
    const {
      nome,
      email,
      senha,
      tipo,
      telefone,
      avatar_url,
      // Dados para comércio
      razao_social,
      cnpj,
      endereco,
      cidade,
      estado,
      cep,
      categoria,
      descricao,
      plano_id,
      // Dados para ONG
      area_atuacao,
      site_url
    } = req.body;

    // 1. Validações básicas
    if (!nome || !email || !senha || !tipo) {
      return res.status(400).json({
        sucesso: false,
        mensagem: 'Campos obrigatórios ausentes: nome, email, senha e tipo são necessários.'
      });
    }

    if (!['comercio', 'ong', 'admin'].includes(tipo)) {
      return res.status(400).json({
        sucesso: false,
        mensagem: "Tipo de usuário inválido. Escolha entre: 'comercio', 'ong' ou 'admin'."
      });
    }

    // Verificar se o e-mail já existe
    const usuarioExistente = db.prepare('SELECT id FROM usuarios WHERE email = ?').get(email);
    if (usuarioExistente) {
      return res.status(409).json({
        sucesso: false,
        mensagem: 'Este e-mail já está cadastrado no sistema.'
      });
    }

    // Validações específicas por tipo
    if (tipo === 'comercio' || tipo === 'ong') {
      if (!razao_social || !cnpj) {
        return res.status(400).json({
          sucesso: false,
          mensagem: 'Razão social e CNPJ são obrigatórios para comércios e ONGs.'
        });
      }

      // Verificar CNPJ único
      const cnpjComercio = db.prepare('SELECT id FROM comercios WHERE cnpj = ?').get(cnpj);
      const cnpjOng = db.prepare('SELECT id FROM ongs WHERE cnpj = ?').get(cnpj);

      if (cnpjComercio || cnpjOng) {
        return res.status(409).json({
          sucesso: false,
          mensagem: 'Este CNPJ já está cadastrado no sistema.'
        });
      }
    }

    // 2. Criptografar senha
    const saltRounds = 10;
    const senha_hash = bcrypt.hashSync(senha, saltRounds);

    let novoUsuarioId = null;
    let detalhesEntidade = null;

    // 3. Execução atômica no banco de dados via transação
    const registrarTransacao = db.transaction(() => {
      // Inserir usuário base
      const insertUsuario = db.prepare(`
        INSERT INTO usuarios (nome, email, senha_hash, tipo, telefone, avatar_url)
        VALUES (?, ?, ?, ?, ?, ?)
      `);
      const resultadoUsuario = insertUsuario.run(
        nome,
        email,
        senha_hash,
        tipo,
        telefone || null,
        avatar_url || null
      );
      novoUsuarioId = resultadoUsuario.lastInsertRowid;

      // Inserir detalhes específicos
      if (tipo === 'comercio') {
        const insertComercio = db.prepare(`
          INSERT INTO comercios (usuario_id, razao_social, cnpj, endereco, cidade, estado, cep, categoria, descricao)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        const resComercio = insertComercio.run(
          novoUsuarioId,
          razao_social,
          cnpj,
          endereco || null,
          cidade || null,
          estado || null,
          cep || null,
          categoria || 'outros',
          descricao || null
        );

        // Atribuir plano inicial (padrão Básico plano_id = 1 se não fornecido)
        const planoEscolhidoId = plano_id || 1;
        const plano = db.prepare('SELECT * FROM planos WHERE id = ?').get(planoEscolhidoId);

        const hoje = new Date();
        const dataInicio = hoje.toISOString().split('T')[0];
        const dataFim = new Date(hoje.setFullYear(hoje.getFullYear() + 1)).toISOString().split('T')[0];

        db.prepare(`
          INSERT INTO assinaturas (usuario_id, plano_id, data_inicio, data_fim, status, valor_pago)
          VALUES (?, ?, ?, ?, ?, ?)
        `).run(novoUsuarioId, planoEscolhidoId, dataInicio, dataFim, 'ativa', plano ? plano.preco_anual : 99.00);

        // Inicializar progresso para todas as metas ativas
        const metasAtivas = db.prepare('SELECT id FROM metas WHERE ativo = 1').all();
        const insertProgresso = db.prepare(`
          INSERT INTO progresso_metas (usuario_id, meta_id, valor_atual, concluida)
          VALUES (?, ?, 0, 0)
        `);
        for (const meta of metasAtivas) {
          insertProgresso.run(novoUsuarioId, meta.id);
        }

        detalhesEntidade = {
          comercio_id: resComercio.lastInsertRowid,
          razao_social,
          cnpj,
          categoria: categoria || 'outros'
        };
      } else if (tipo === 'ong') {
        const insertOng = db.prepare(`
          INSERT INTO ongs (usuario_id, razao_social, cnpj, endereco, cidade, estado, cep, area_atuacao, descricao, site_url)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        const resOng = insertOng.run(
          novoUsuarioId,
          razao_social,
          cnpj,
          endereco || null,
          cidade || null,
          estado || null,
          cep || null,
          area_atuacao || 'outros',
          descricao || null,
          site_url || null
        );

        detalhesEntidade = {
          ong_id: resOng.lastInsertRowid,
          razao_social,
          cnpj,
          area_atuacao: area_atuacao || 'outros'
        };
      }

      // Inserir notificação de boas-vindas
      db.prepare(`
        INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo)
        VALUES (?, ?, ?, ?)
      `).run(
        novoUsuarioId,
        'Bem-vindo à Corrente Solidária!',
        'Sua conta foi criada com sucesso. Juntos podemos transformar o desperdício em solidariedade.',
        'sucesso'
      );
    });

    registrarTransacao();

    // 4. Gerar Token JWT
    const token = jwt.sign(
      { id: novoUsuarioId, email, tipo },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    return res.status(201).json({
      sucesso: true,
      mensagem: 'Usuário cadastrado com sucesso!',
      token,
      usuario: {
        id: novoUsuarioId,
        nome,
        email,
        tipo,
        telefone: telefone || null,
        avatar_url: avatar_url || null,
        detalhes: detalhesEntidade
      }
    });

  } catch (error) {
    console.error('Erro no cadastro:', error);
    return res.status(500).json({
      sucesso: false,
      mensagem: 'Erro interno ao processar o cadastro.',
      erro: error.message
    });
  }
});

/**
 * POST /api/auth/login
 * Autentica o usuário validando e-mail e senha, retornando o token JWT.
 */
router.post('/login', (req, res) => {
  try {
    const { email, senha } = req.body;

    if (!email || !senha) {
      return res.status(400).json({
        sucesso: false,
        mensagem: 'E-mail e senha são obrigatórios.'
      });
    }

    // Buscar usuário pelo e-mail
    const usuario = db.prepare(`
      SELECT * FROM usuarios WHERE email = ?
    `).get(email);

    if (!usuario) {
      return res.status(401).json({
        sucesso: false,
        mensagem: 'Credenciais inválidas. Verifique o e-mail ou a senha.'
      });
    }

    if (usuario.ativo !== 1) {
      return res.status(403).json({
        sucesso: false,
        mensagem: 'Sua conta está desativada. Entre em contato com o suporte.'
      });
    }

    // Validar hash da senha
    const senhaCorreta = bcrypt.compareSync(senha, usuario.senha_hash);
    if (!senhaCorreta) {
      return res.status(401).json({
        sucesso: false,
        mensagem: 'Credenciais inválidas. Verifique o e-mail ou a senha.'
      });
    }

    // Carregar informações complementares conforme o perfil
    let dadosComplementares = {};
    if (usuario.tipo === 'comercio') {
      const comercio = db.prepare('SELECT * FROM comercios WHERE usuario_id = ?').get(usuario.id);
      const assinatura = db.prepare(`
        SELECT a.*, p.nome as plano_nome, p.cashback_percentual, p.max_doacoes_mes
        FROM assinaturas a
        JOIN planos p ON a.plano_id = p.id
        WHERE a.usuario_id = ? AND a.status = 'ativa'
        ORDER BY a.id DESC
        LIMIT 1
      `).get(usuario.id);
      dadosComplementares = { comercio, assinatura };
    } else if (usuario.tipo === 'ong') {
      const ong = db.prepare('SELECT * FROM ongs WHERE usuario_id = ?').get(usuario.id);
      dadosComplementares = { ong };
    }

    // Gerar token de autenticação
    const token = jwt.sign(
      { id: usuario.id, email: usuario.email, tipo: usuario.tipo },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    // Remover senha_hash da resposta por segurança
    delete usuario.senha_hash;

    return res.status(200).json({
      sucesso: true,
      mensagem: 'Login realizado com sucesso!',
      token,
      usuario: {
        ...usuario,
        ...dadosComplementares
      }
    });

  } catch (error) {
    console.error('Erro no login:', error);
    return res.status(500).json({
      sucesso: false,
      mensagem: 'Erro interno ao realizar login.',
      erro: error.message
    });
  }
});

/**
 * GET /api/auth/me
 * Retorna os dados completos do usuário autenticado no token.
 */
router.get('/me', authMiddleware, (req, res) => {
  return res.status(200).json({
    sucesso: true,
    usuario: req.user
  });
});

module.exports = router;
module.exports.authMiddleware = authMiddleware;
