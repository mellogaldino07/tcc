/**
 * Conexão e Inicialização do Banco de Dados SQLite
 * Utiliza better-sqlite3 para persistência síncrona e rápida com WAL mode ativo.
 */

const Database = require('better-sqlite3');
const path = require('path');
const bcrypt = require('bcryptjs');

// Caminho absoluto para o arquivo sqlite
const dbPath = path.resolve(__dirname, 'database.sqlite');
const db = new Database(dbPath);

// Configuração de performance e integridade referencial
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

/**
 * Criação de tabelas e índices
 */
function initDatabase() {
  db.exec(`
    -- Usuários da plataforma: 'comercio', 'ong', 'admin'
    CREATE TABLE IF NOT EXISTS usuarios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL,
      email TEXT NOT NULL UNIQUE,
      senha_hash TEXT NOT NULL,
      tipo TEXT NOT NULL CHECK(tipo IN ('comercio', 'ong', 'admin')),
      telefone TEXT,
      avatar_url TEXT,
      ativo INTEGER DEFAULT 1,
      criado_em TEXT DEFAULT (datetime('now')),
      atualizado_em TEXT DEFAULT (datetime('now'))
    );

    -- Informações específicas de empresas e comércios doadores
    CREATE TABLE IF NOT EXISTS comercios (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER NOT NULL UNIQUE REFERENCES usuarios(id) ON DELETE CASCADE,
      razao_social TEXT NOT NULL,
      cnpj TEXT NOT NULL UNIQUE,
      endereco TEXT,
      cidade TEXT,
      estado TEXT,
      cep TEXT,
      categoria TEXT, -- 'supermercado', 'restaurante', 'loja_roupas', 'padaria', 'outros'
      descricao TEXT,
      criado_em TEXT DEFAULT (datetime('now'))
    );

    -- Informações específicas de ONGs e instituições beneficiadas
    CREATE TABLE IF NOT EXISTS ongs (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER NOT NULL UNIQUE REFERENCES usuarios(id) ON DELETE CASCADE,
      razao_social TEXT NOT NULL,
      cnpj TEXT NOT NULL UNIQUE,
      endereco TEXT,
      cidade TEXT,
      estado TEXT,
      cep TEXT,
      area_atuacao TEXT, -- 'alimentacao', 'vestuario', 'educacao', 'saude', 'outros'
      descricao TEXT,
      site_url TEXT,
      criado_em TEXT DEFAULT (datetime('now'))
    );

    -- Planos de anuidade para comércios parceiros
    CREATE TABLE IF NOT EXISTS planos (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      nome TEXT NOT NULL, -- 'Básico', 'Profissional', 'Premium'
      preco_anual REAL NOT NULL,
      descricao TEXT,
      max_doacoes_mes INTEGER, -- limite de doações por mês (null para ilimitado)
      cashback_percentual REAL DEFAULT 0, -- ex: 2.5 = 2.5%
      destaque_ranking INTEGER DEFAULT 0, -- se aparece em destaque no ranking
      suporte_prioritario INTEGER DEFAULT 0,
      criado_em TEXT DEFAULT (datetime('now'))
    );

    -- Histórico de assinaturas de planos
    CREATE TABLE IF NOT EXISTS assinaturas (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
      plano_id INTEGER NOT NULL REFERENCES planos(id),
      data_inicio TEXT NOT NULL,
      data_fim TEXT NOT NULL,
      status TEXT DEFAULT 'ativa' CHECK(status IN ('ativa', 'cancelada', 'expirada', 'pendente')),
      valor_pago REAL,
      criado_em TEXT DEFAULT (datetime('now'))
    );

    -- Doações e vendas sociais cadastradas
    CREATE TABLE IF NOT EXISTS doacoes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      comercio_id INTEGER NOT NULL REFERENCES comercios(id) ON DELETE CASCADE,
      ong_id INTEGER REFERENCES ongs(id) ON DELETE SET NULL,
      tipo TEXT NOT NULL CHECK(tipo IN ('doacao', 'venda')),
      categoria_item TEXT NOT NULL CHECK(categoria_item IN ('alimento', 'roupa', 'higiene', 'outros')),
      descricao TEXT NOT NULL,
      quantidade INTEGER DEFAULT 1,
      unidade TEXT DEFAULT 'unidade', -- 'kg', 'litro', 'unidade', 'caixa'
      valor_estimado REAL DEFAULT 0,
      status TEXT DEFAULT 'pendente' CHECK(status IN ('pendente', 'aceita', 'em_transito', 'entregue', 'recusada', 'cancelada')),
      data_validade TEXT, -- para alimentos
      observacoes TEXT,
      criado_em TEXT DEFAULT (datetime('now')),
      atualizado_em TEXT DEFAULT (datetime('now'))
    );

    -- Metas de solidariedade e incentivo
    CREATE TABLE IF NOT EXISTS metas (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      titulo TEXT NOT NULL,
      descricao TEXT,
      tipo_meta TEXT NOT NULL CHECK(tipo_meta IN ('doacoes_count', 'doacoes_valor', 'kg_doados', 'ongs_atendidas')),
      valor_alvo REAL NOT NULL, -- quantidade para atingir a meta
      recompensa_descricao TEXT,
      recompensa_cashback REAL DEFAULT 0, -- cashback extra ao atingir
      recompensa_badge TEXT, -- nome do selo/badge
      ativo INTEGER DEFAULT 1,
      criado_em TEXT DEFAULT (datetime('now'))
    );

    -- Progresso dos usuários nas metas
    CREATE TABLE IF NOT EXISTS progresso_metas (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
      meta_id INTEGER NOT NULL REFERENCES metas(id) ON DELETE CASCADE,
      valor_atual REAL DEFAULT 0,
      concluida INTEGER DEFAULT 0,
      data_conclusao TEXT,
      criado_em TEXT DEFAULT (datetime('now')),
      UNIQUE(usuario_id, meta_id)
    );

    -- Saldo e histórico de cashback gerado
    CREATE TABLE IF NOT EXISTS cashback (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
      doacao_id INTEGER REFERENCES doacoes(id) ON DELETE SET NULL,
      meta_id INTEGER REFERENCES metas(id) ON DELETE SET NULL,
      valor REAL NOT NULL,
      tipo TEXT NOT NULL CHECK(tipo IN ('doacao', 'meta', 'plano', 'bonus')),
      descricao TEXT,
      status TEXT DEFAULT 'pendente' CHECK(status IN ('pendente', 'creditado', 'resgatado', 'expirado')),
      criado_em TEXT DEFAULT (datetime('now'))
    );

    -- Ranking mensal e anual de doadores
    CREATE TABLE IF NOT EXISTS ranking (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
      periodo TEXT NOT NULL, -- '2026-10' para mensal, '2026' para anual
      tipo_periodo TEXT NOT NULL CHECK(tipo_periodo IN ('mensal', 'anual')),
      pontos INTEGER DEFAULT 0,
      total_doacoes INTEGER DEFAULT 0,
      total_valor REAL DEFAULT 0,
      posicao INTEGER,
      criado_em TEXT DEFAULT (datetime('now')),
      UNIQUE(usuario_id, periodo, tipo_periodo)
    );

    -- Notificações do sistema para os usuários
    CREATE TABLE IF NOT EXISTS notificacoes (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      usuario_id INTEGER NOT NULL REFERENCES usuarios(id) ON DELETE CASCADE,
      titulo TEXT NOT NULL,
      mensagem TEXT NOT NULL,
      tipo TEXT DEFAULT 'info' CHECK(tipo IN ('info', 'sucesso', 'aviso', 'erro')),
      lida INTEGER DEFAULT 0,
      criado_em TEXT DEFAULT (datetime('now'))
    );
  `);

  // Executar seed inicial se o banco estiver vazio
  seedDatabase();

  // Executar migração idempotente de valores atualizados de cashback em planos e metas
  executarMigracaoCashback();

  // Garantir existência de dados de ranking para o mês e ano correntes (comércios e ONGs)
  garantirDadosRanking();
}

/**
 * Garante que o ranking do período atual (mês e ano) possua dados demonstrativos para comércios e ONGs
 */
function garantirDadosRanking() {
  try {
    const agora = new Date();
    const mesAtual = agora.toISOString().slice(0, 7); // Ex: '2026-11'
    const anoAtual = agora.toISOString().slice(0, 4); // Ex: '2026'

    // 1. Garantir ONGs demo adicionais para compor o Top 5
    const ongsDemo = [
      {
        email: 'maosqueacolhem@demo.com',
        nome: 'Instituto Mãos que Acolhem',
        razao: 'Instituto Mãos que Acolhem de Assistência Social',
        cnpj: '11.222.333/0001-44',
        cidade: 'São Paulo',
        estado: 'SP',
        area: 'Acolhimento Social'
      },
      {
        email: 'acaosolidaria@demo.com',
        nome: 'Ação Solidária Regional',
        razao: 'Associação Ação Solidária Regional',
        cnpj: '22.333.444/0001-55',
        cidade: 'Porto Alegre',
        estado: 'RS',
        area: 'Apoio Comunitário'
      },
      {
        email: 'rededobem@demo.com',
        nome: 'Rede do Bem Comunitário',
        razao: 'Rede do Bem Comunitário Brasil',
        cnpj: '33.444.555/0001-66',
        cidade: 'Fortaleza',
        estado: 'CE',
        area: 'Distribuição Direta'
      },
      {
        email: 'apoiofraterno@demo.com',
        nome: 'Casa de Apoio Fraterno',
        razao: 'Casa de Apoio Fraterno Amparo Social',
        cnpj: '44.555.666/0001-77',
        cidade: 'Manaus',
        estado: 'AM',
        area: 'Centro de Apoio'
      }
    ];

    const senhaHash = bcrypt.hashSync('demo123', 10);
    const insertUsuario = db.prepare(`
      INSERT INTO usuarios (nome, email, senha_hash, tipo, telefone)
      VALUES (?, ?, ?, 'ong', '(11) 98888-0000')
    `);
    const insertOng = db.prepare(`
      INSERT INTO ongs (usuario_id, razao_social, cnpj, cidade, estado, area_atuacao)
      VALUES (?, ?, ?, ?, ?, ?)
    `);

    for (const ong of ongsDemo) {
      const existe = db.prepare('SELECT id FROM usuarios WHERE email = ?').get(ong.email);
      if (!existe) {
        const uRes = insertUsuario.run(ong.nome, ong.email, senhaHash);
        insertOng.run(uRes.lastInsertRowid, ong.razao, ong.cnpj, ong.cidade, ong.estado, ong.area);
      }
    }

    // 2. Garantir ranking do mês atual para Comércios
    const comercios = db.prepare(`
      SELECT u.id as usuario_id FROM usuarios u WHERE u.tipo = 'comercio' ORDER BY u.id ASC
    `).all();

    const rankingComercioMes = db.prepare(`
      SELECT COUNT(*) as total FROM ranking r
      JOIN usuarios u ON r.usuario_id = u.id
      WHERE r.periodo = ? AND r.tipo_periodo = 'mensal' AND u.tipo = 'comercio'
    `).get(mesAtual).total;

    if (rankingComercioMes === 0 && comercios.length > 0) {
      const insertRanking = db.prepare(`
        INSERT INTO ranking (usuario_id, periodo, tipo_periodo, pontos, total_doacoes, total_valor, posicao)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `);

      const pontuacoes = [
        { pontos: 450, doacoes: 5, valor: 890.0 },
        { pontos: 320, doacoes: 3, valor: 650.0 },
        { pontos: 210, doacoes: 2, valor: 400.0 }
      ];

      comercios.slice(0, 3).forEach((c, idx) => {
        const p = pontuacoes[idx] || { pontos: 100, doacoes: 1, valor: 150 };
        insertRanking.run(c.usuario_id, mesAtual, 'mensal', p.pontos, p.doacoes, p.valor, idx + 1);
      });
    }

    // 3. Garantir ranking do mês e ano atual para ONGs
    const ongs = db.prepare(`
      SELECT u.id as usuario_id FROM usuarios u WHERE u.tipo = 'ong' ORDER BY u.id ASC
    `).all();

    const rankingOngMes = db.prepare(`
      SELECT COUNT(*) as total FROM ranking r
      JOIN usuarios u ON r.usuario_id = u.id
      WHERE r.periodo = ? AND r.tipo_periodo = 'mensal' AND u.tipo = 'ong'
    `).get(mesAtual).total;

    if (rankingOngMes === 0 && ongs.length > 0) {
      const insertRanking = db.prepare(`
        INSERT INTO ranking (usuario_id, periodo, tipo_periodo, pontos, total_doacoes, total_valor, posicao)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `);

      const pontuacoesOngs = [
        { pontos: 510, doacoes: 6, valor: 1200.0 },
        { pontos: 380, doacoes: 4, valor: 900.0 },
        { pontos: 290, doacoes: 3, valor: 650.0 },
        { pontos: 190, doacoes: 2, valor: 420.0 },
        { pontos: 140, doacoes: 2, valor: 310.0 }
      ];

      ongs.slice(0, 5).forEach((o, idx) => {
        const p = pontuacoesOngs[idx] || { pontos: 80, doacoes: 1, valor: 150 };
        insertRanking.run(o.usuario_id, mesAtual, 'mensal', p.pontos, p.doacoes, p.valor, idx + 1);
      });
    }

    const rankingOngAno = db.prepare(`
      SELECT COUNT(*) as total FROM ranking r
      JOIN usuarios u ON r.usuario_id = u.id
      WHERE r.periodo = ? AND r.tipo_periodo = 'anual' AND u.tipo = 'ong'
    `).get(anoAtual).total;

    if (rankingOngAno === 0 && ongs.length > 0) {
      const insertRanking = db.prepare(`
        INSERT INTO ranking (usuario_id, periodo, tipo_periodo, pontos, total_doacoes, total_valor, posicao)
        VALUES (?, ?, ?, ?, ?, ?, ?)
      `);

      const pontuacoesOngsAno = [
        { pontos: 1820, doacoes: 22, valor: 4800.0 },
        { pontos: 1410, doacoes: 17, valor: 3600.0 },
        { pontos: 1100, doacoes: 13, valor: 2800.0 },
        { pontos: 850, doacoes: 10, valor: 2100.0 },
        { pontos: 620, doacoes: 8, valor: 1500.0 }
      ];

      ongs.slice(0, 5).forEach((o, idx) => {
        const p = pontuacoesOngsAno[idx] || { pontos: 300, doacoes: 4, valor: 800 };
        insertRanking.run(o.usuario_id, anoAtual, 'anual', p.pontos, p.doacoes, p.valor, idx + 1);
      });
    }

  } catch (error) {
    console.error('[Ranking Demo] Erro ao garantir dados de ranking:', error);
  }
}

// ==========================================
// CONSTANTES DE CASHBACK E METAS SOLIDÁRIAS
// ==========================================
const NOVOS_VALORES_PLANOS = {
  'Básico': { cashback_percentual: 2.0 },
  'Profissional': { cashback_percentual: 5.0 },
  'Premium': { cashback_percentual: 8.0 }
};

const NOVAS_RECOMPENSAS_METAS = {
  'Primeiro Passo Solidário': {
    recompensa_cashback: 15.00,
    recompensa_descricao: 'Selo de boas-vindas e R$ 15,00 de cashback inicial'
  },
  'Guardião dos Alimentos': {
    recompensa_cashback: 75.00,
    recompensa_descricao: 'Bônus especial de R$ 75,00 de cashback e selo Guardião'
  },
  'Rede do Bem': {
    recompensa_cashback: 110.00,
    recompensa_descricao: 'Selo exclusivo de impacto social e R$ 110,00 em cashback'
  },
  'Grande Benfeitor': {
    recompensa_cashback: 150.00,
    recompensa_descricao: 'Cashback de R$ 150,00 e destaque na vitrine principal'
  },
  'Campeão da Solidariedade': {
    recompensa_cashback: 225.00,
    recompensa_descricao: 'Troféu digital no ranking e R$ 225,00 em cashback'
  }
};

/**
 * Migração idempotente para atualizar valores de cashback nos planos e metas
 * Roda a cada inicialização sem duplicar dados.
 */
function executarMigracaoCashback() {
  try {
    const updatePlanoStmt = db.prepare(`
      UPDATE planos SET cashback_percentual = ? WHERE nome = ?
    `);
    for (const [nome, dados] of Object.entries(NOVOS_VALORES_PLANOS)) {
      updatePlanoStmt.run(dados.cashback_percentual, nome);
    }

    const updateMetaStmt = db.prepare(`
      UPDATE metas SET recompensa_cashback = ?, recompensa_descricao = ? WHERE titulo = ?
    `);
    for (const [titulo, dados] of Object.entries(NOVAS_RECOMPENSAS_METAS)) {
      updateMetaStmt.run(dados.recompensa_cashback, dados.recompensa_descricao, titulo);
    }
  } catch (error) {
    console.error('[Migração] Erro ao atualizar valores de cashback:', error);
  }
}

/**
 * Popula o banco com dados iniciais e de demonstração
 */
function seedDatabase() {
  const planosExistentes = db.prepare('SELECT COUNT(*) as total FROM planos').get().total;
  if (planosExistentes > 0) {
    return; // Já populado
  }

  const transaction = db.transaction(() => {
    // 1. Inserir os 3 Planos
    const insertPlano = db.prepare(`
      INSERT INTO planos (nome, preco_anual, descricao, max_doacoes_mes, cashback_percentual, destaque_ranking, suporte_prioritario)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    insertPlano.run('Básico', 99.00, 'Ideal para pequenos comércios que querem iniciar suas doações solidárias.', 10, NOVOS_VALORES_PLANOS['Básico'].cashback_percentual, 0, 0);
    insertPlano.run('Profissional', 249.00, 'Perfeito para comércios com fluxo regular de doações e vendas sociais.', 50, NOVOS_VALORES_PLANOS['Profissional'].cashback_percentual, 1, 0);
    insertPlano.run('Premium', 499.00, 'Para grandes empresas e redes com doações ilimitadas e máximo de benefícios.', null, NOVOS_VALORES_PLANOS['Premium'].cashback_percentual, 1, 1);

    // 2. Inserir 5 Metas de Amostra
    const insertMeta = db.prepare(`
      INSERT INTO metas (titulo, descricao, tipo_meta, valor_alvo, recompensa_descricao, recompensa_cashback, recompensa_badge, ativo)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);

    insertMeta.run(
      'Primeiro Passo Solidário',
      'Realize sua primeira doação cadastrada na plataforma.',
      'doacoes_count',
      1,
      NOVAS_RECOMPENSAS_METAS['Primeiro Passo Solidário'].recompensa_descricao,
      NOVAS_RECOMPENSAS_METAS['Primeiro Passo Solidário'].recompensa_cashback,
      'Primeiro Passo',
      1
    );

    insertMeta.run(
      'Guardião dos Alimentos',
      'Doe um total acumulado de 50 kg de alimentos para ONGs parceiras.',
      'kg_doados',
      50,
      NOVAS_RECOMPENSAS_METAS['Guardião dos Alimentos'].recompensa_descricao,
      NOVAS_RECOMPENSAS_METAS['Guardião dos Alimentos'].recompensa_cashback,
      'Guardião dos Alimentos',
      1
    );

    insertMeta.run(
      'Rede do Bem',
      'Atenda 5 ONGs distintas cadastradas na comunidade.',
      'ongs_atendidas',
      5,
      NOVAS_RECOMPENSAS_METAS['Rede do Bem'].recompensa_descricao,
      NOVAS_RECOMPENSAS_METAS['Rede do Bem'].recompensa_cashback,
      'Impacto Social',
      1
    );

    insertMeta.run(
      'Grande Benfeitor',
      'Alcance R$ 2.000,00 em valor estimado de donativos entregues.',
      'doacoes_valor',
      2000,
      NOVAS_RECOMPENSAS_METAS['Grande Benfeitor'].recompensa_descricao,
      NOVAS_RECOMPENSAS_METAS['Grande Benfeitor'].recompensa_cashback,
      'Grande Benfeitor',
      1
    );

    insertMeta.run(
      'Campeão da Solidariedade',
      'Complete 30 doações ao longo do ano.',
      'doacoes_count',
      30,
      NOVAS_RECOMPENSAS_METAS['Campeão da Solidariedade'].recompensa_descricao,
      NOVAS_RECOMPENSAS_METAS['Campeão da Solidariedade'].recompensa_cashback,
      'Campeão da Solidariedade',
      1
    );

    // 3. Usuários Demo (senha: 'demo123')
    const senhaHash = bcrypt.hashSync('demo123', 10);

    const insertUsuario = db.prepare(`
      INSERT INTO usuarios (nome, email, senha_hash, tipo, telefone, avatar_url)
      VALUES (?, ?, ?, ?, ?, ?)
    `);

    // Usuário Comércio Demo
    const comercioUserResult = insertUsuario.run(
      'Supermercado Esperança',
      'comercio@demo.com',
      senhaHash,
      'comercio',
      '(11) 98765-4321',
      'https://images.unsplash.com/photo-1578916171728-46686eac8d58?w=150'
    );
    const comercioUserId = comercioUserResult.lastInsertRowid;

    const insertComercio = db.prepare(`
      INSERT INTO comercios (usuario_id, razao_social, cnpj, endereco, cidade, estado, cep, categoria, descricao)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const comercioResult = insertComercio.run(
      comercioUserId,
      'Supermercado Esperança Ltda',
      '12.345.678/0001-90',
      'Av. Paulista, 1000',
      'São Paulo',
      'SP',
      '01310-100',
      'supermercado',
      'Supermercado comprometido com o combate ao desperdício e apoio comunitário.'
    );
    const comercioId = comercioResult.lastInsertRowid;

    // Usuário ONG Demo
    const ongUserResult = insertUsuario.run(
      'Instituto Prato Cheio',
      'ong@demo.com',
      senhaHash,
      'ong',
      '(11) 91234-5678',
      'https://images.unsplash.com/photo-1593113598332-cd288d649433?w=150'
    );
    const ongUserId = ongUserResult.lastInsertRowid;

    const insertOng = db.prepare(`
      INSERT INTO ongs (usuario_id, razao_social, cnpj, endereco, cidade, estado, cep, area_atuacao, descricao, site_url)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    const ongResult = insertOng.run(
      ongUserId,
      'Instituto Prato Cheio de Assistência Social',
      '98.765.432/0001-10',
      'Rua Solidária, 500',
      'São Paulo',
      'SP',
      '01400-200',
      'alimentacao',
      'ONG dedicada a erradicar a fome fornecendo alimentos frescos e refeições para famílias necessitadas.',
      'https://pratocheio.org.br'
    );
    const ongId = ongResult.lastInsertRowid;

    // Usuário Comércio 2 para alimentar ranking
    const comercio2UserResult = insertUsuario.run(
      'Padaria Pão Dourado',
      'paodourado@demo.com',
      senhaHash,
      'comercio',
      '(11) 99887-1122',
      'https://images.unsplash.com/photo-1509440159596-0249088772ff?w=150'
    );
    const comercio2UserId = comercio2UserResult.lastInsertRowid;
    insertComercio.run(
      comercio2UserId,
      'Panificadora Pão Dourado ME',
      '23.456.789/0001-11',
      'Rua Augusta, 450',
      'São Paulo',
      'SP',
      '01305-000',
      'padaria',
      'Panificadora tradicional que doa pães e bolos ao final de cada expediente.'
    );

    // Usuário Comércio 3 para alimentar ranking
    const comercio3UserResult = insertUsuario.run(
      'Boutique Moda Sustentável',
      'modasustentavel@demo.com',
      senhaHash,
      'comercio',
      '(11) 97711-2233',
      'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=150'
    );
    const comercio3UserId = comercio3UserResult.lastInsertRowid;
    insertComercio.run(
      comercio3UserId,
      'Boutique Moda Sustentável Eireli',
      '34.567.890/0001-22',
      'Alameda Santos, 820',
      'São Paulo',
      'SP',
      '01418-000',
      'loja_roupas',
      'Moda consciente doando peças de coleções anteriores e agasalhos de inverno.'
    );

    // 4. Assinatura do Comércio Demo (Plano Profissional)
    const insertAssinatura = db.prepare(`
      INSERT INTO assinaturas (usuario_id, plano_id, data_inicio, data_fim, status, valor_pago)
      VALUES (?, ?, ?, ?, ?, ?)
    `);
    insertAssinatura.run(comercioUserId, 2, '2026-01-01', '2027-01-01', 'ativa', 249.00);
    insertAssinatura.run(comercio2UserId, 1, '2026-02-01', '2027-02-01', 'ativa', 99.00);
    insertAssinatura.run(comercio3UserId, 3, '2026-01-15', '2027-01-15', 'ativa', 499.00);

    // 5. Doações de Amostra
    const insertDoacao = db.prepare(`
      INSERT INTO doacoes (comercio_id, ong_id, tipo, categoria_item, descricao, quantidade, unidade, valor_estimado, status, data_validade, observacoes)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const doacao1 = insertDoacao.run(
      comercioId,
      ongId,
      'doacao',
      'alimento',
      'Caixas de hortifrúti frescos (tomates, laranjas, batatas)',
      40,
      'kg',
      280.00,
      'entregue',
      '2026-10-25',
      'Retirada realizada com sucesso pela equipe da ONG'
    );

    const doacao2 = insertDoacao.run(
      comercioId,
      ongId,
      'doacao',
      'alimento',
      'Pacotes de arroz tipo 1 e feijão carioca',
      25,
      'unidade',
      150.00,
      'aceita',
      '2027-03-10',
      'Aguardando agendamento de transporte voluntário'
    );

    const doacao3 = insertDoacao.run(
      comercioId,
      null,
      'venda',
      'roupa',
      'Lote de agasalhos e camisetas infantis a preço simbólico de custo',
      50,
      'unidade',
      500.00,
      'pendente',
      null,
      'Disponível para ONGs de acolhimento e proteção à criança'
    );

    const doacao4 = insertDoacao.run(
      comercioId,
      ongId,
      'doacao',
      'higiene',
      'Kits de higiene pessoal (sabonetes, pastas e escovas de dente)',
      30,
      'caixa',
      360.00,
      'em_transito',
      null,
      'Voluntário em rota para entrega na sede da ONG'
    );

    // 6. Progresso de Metas para o Comércio Demo
    const insertProgresso = db.prepare(`
      INSERT INTO progresso_metas (usuario_id, meta_id, valor_atual, concluida, data_conclusao)
      VALUES (?, ?, ?, ?, ?)
    `);

    // Meta 1: Concluída
    insertProgresso.run(comercioUserId, 1, 1, 1, '2026-10-01');
    // Meta 2: 40/50 kg
    insertProgresso.run(comercioUserId, 2, 40, 0, null);
    // Meta 3: 1/5 ONGs
    insertProgresso.run(comercioUserId, 3, 1, 0, null);
    // Meta 4: R$ 790/2000
    insertProgresso.run(comercioUserId, 4, 790.00, 0, null);
    // Meta 5: 4/30 doações
    insertProgresso.run(comercioUserId, 5, 4, 0, null);

    // 7. Entradas de Cashback
    const insertCashback = db.prepare(`
      INSERT INTO cashback (usuario_id, doacao_id, meta_id, valor, tipo, descricao, status)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    // Cashback de doação concluída (3% de R$ 280,00)
    insertCashback.run(
      comercioUserId,
      doacao1.lastInsertRowid,
      null,
      8.40,
      'doacao',
      'Cashback de 3% sobre doação #1 entregue',
      'creditado'
    );

    // Cashback de meta concluída
    insertCashback.run(
      comercioUserId,
      null,
      1,
      10.00,
      'meta',
      'Recompensa pela meta "Primeiro Passo Solidário"',
      'creditado'
    );

    // Cashback pendente de doação aceita (3% de R$ 150,00)
    insertCashback.run(
      comercioUserId,
      doacao2.lastInsertRowid,
      null,
      4.50,
      'doacao',
      'Cashback previsto para doação #2',
      'pendente'
    );

    // 8. Ranking Mensal e Anual
    const insertRanking = db.prepare(`
      INSERT INTO ranking (usuario_id, periodo, tipo_periodo, pontos, total_doacoes, total_valor, posicao)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `);

    // Ranking Mensal (2026-10)
    insertRanking.run(comercioUserId, '2026-10', 'mensal', 420, 4, 790.00, 1);
    insertRanking.run(comercio3UserId, '2026-10', 'mensal', 310, 3, 620.00, 2);
    insertRanking.run(comercio2UserId, '2026-10', 'mensal', 190, 2, 350.00, 3);

    // Ranking Anual (2026)
    insertRanking.run(comercio3UserId, '2026', 'anual', 1580, 15, 4200.00, 1);
    insertRanking.run(comercioUserId, '2026', 'anual', 1250, 12, 3450.00, 2);
    insertRanking.run(comercio2UserId, '2026', 'anual', 890, 9, 1850.00, 3);

    // 9. Notificações
    const insertNotificacao = db.prepare(`
      INSERT INTO notificacoes (usuario_id, titulo, mensagem, tipo, lida)
      VALUES (?, ?, ?, ?, ?)
    `);

    insertNotificacao.run(
      comercioUserId,
      'Doação Aceita!',
      'O Instituto Prato Cheio aceitou sua doação de hortifrúti frescos.',
      'sucesso',
      1
    );

    insertNotificacao.run(
      comercioUserId,
      'Cashback Creditado',
      'Você recebeu R$ 10,00 de cashback pela conquista "Primeiro Passo Solidário".',
      'info',
      0
    );

    insertNotificacao.run(
      ongUserId,
      'Nova Doação Disponível',
      'O Supermercado Esperança cadastrou nova doação de arroz e feijão.',
      'info',
      0
    );
  });

  transaction();
}

module.exports = {
  db,
  initDatabase
};
