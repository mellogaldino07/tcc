# Corrente Solidária - Backend API

Backend completo da plataforma **Corrente Solidária**, conectando empresas e comércios locais a Organizações Não Governamentais (ONGs) para doações e vendas sociais de alimentos, roupas e itens de higiene, com suporte a planos de anuidade, metas solidárias com recompensas, cashbacks automáticos e rankings periódicos.

---

## 🚀 Como Executar

### 1. Instalar as dependências
Navegue até a pasta `server` e instale os pacotes:
```bash
cd server
npm install
```

### 2. Iniciar o servidor
Modo normal:
```bash
npm start
```
Ou diretamente:
```bash
node index.js
```

Modo de desenvolvimento (com auto-reload nativo):
```bash
npm run dev
```

O servidor estará rodando em: `http://localhost:3001`

---

## 🔑 Credenciais de Demonstração (Seed)

| Perfil | E-mail | Senha | Descrição |
|---|---|---|---|
| **Comércio** | `comercio@demo.com` | `demo123` | Supermercado Esperança (Plano Profissional) |
| **ONG** | `ong@demo.com` | `demo123` | Instituto Prato Cheio |
| **Comércio 2** | `paodourado@demo.com` | `demo123` | Panificadora Pão Dourado (Plano Básico) |
| **Comércio 3** | `modasustentavel@demo.com` | `demo123` | Boutique Moda Sustentável (Plano Premium) |

---

## 📌 Rotas da API

### Autenticação (`/api/auth`)
- `POST /api/auth/registro`: Cadastro de usuário (comércio ou ONG).
- `POST /api/auth/login`: Autenticação e obtenção do token JWT.
- `GET /api/auth/me`: Retorna o usuário autenticado via cabeçalho `Authorization: Bearer <token>`.

### Doações e Vendas Sociais (`/api/doacoes`)
- `GET /api/doacoes`: Lista doações (filtradas por perfil: comércio vê as suas, ONG vê as atribuídas ou pendentes abertas).
- `GET /api/doacoes/:id`: Detalhes de uma doação específica.
- `POST /api/doacoes`: Cadastro de nova doação/venda por um comércio.
- `PATCH /api/doacoes/:id/status`: Altera status (`pendente`, `aceita`, `em_transito`, `entregue`, `recusada`, `cancelada`). Quando `entregue`, calcula cashback, avança metas e pontua no ranking automaticamente!

### Ranking Solidário (`/api/ranking`)
- `GET /api/ranking?periodo=mensal`: Ranking mensal ordenado por pontos e valor doado.
- `GET /api/ranking?periodo=anual`: Ranking anual consolidado.

### Dashboard Integrado (`/api/dashboard`)
- `GET /api/dashboard`: Retorna indicadores e métricas sob medida para o perfil autenticado (comércio, ONG ou admin).

### Planos de Anuidade (`/api/planos`)
- `GET /api/planos`: Lista os planos (Básico, Profissional, Premium).
- `POST /api/planos/assinar`: Upgrade ou contratação de plano.

### Cashback Solidário (`/api/cashback`)
- `GET /api/cashback`: Extrato de créditos de doações e recompensas de metas.
- `POST /api/cashback/resgatar`: Solicitação de resgate de saldo via PIX.

### Metas e Recompensas (`/api/metas`)
- `GET /api/metas`: Metas ativas e percentual de progresso do usuário.

### Notificações (`/api/notificacoes`)
- `GET /api/notificacoes`: Notificações do usuário.
- `PATCH /api/notificacoes/:id/lida`: Marca como lida.
- `PATCH /api/notificacoes/ler-todas`: Marca todas como lidas.
