/**
 * Servidor Principal - Corrente Solidária API
 * Conecta comércios e ONGs para doações e vendas sociais,
 * com planos de anuidade, metas, cashback e ranking.
 */

const path = require('path');
const dotenv = require('dotenv');

// Carregar variáveis de ambiente do arquivo server/.env
dotenv.config({ path: path.resolve(__dirname, '.env') });

const express = require('express');
const cors = require('cors');
const { initDatabase } = require('./database');

// Importação das rotas da aplicação
const authRoutes = require('./routes/auth');
const doacoesRoutes = require('./routes/doacoes');
const rankingRoutes = require('./routes/ranking');
const dashboardRoutes = require('./routes/dashboard');
const planosRoutes = require('./routes/planos');
const cashbackRoutes = require('./routes/cashback');
const metasRoutes = require('./routes/metas');
const notificacoesRoutes = require('./routes/notificacoes');
const ongsRoutes = require('./routes/ongs');

// Inicialização da aplicação Express
const app = express();
const PORT = process.env.PORT || 3001;

// Middlewares globais
app.use(cors());
app.use(express.json());

// Inicializar banco de dados SQLite e tabelas/seed
try {
  console.log('[Banco de Dados] Inicializando SQLite e verificando tabelas...');
  initDatabase();
  console.log('[Banco de Dados] Banco pronto e populado com sucesso.');
} catch (error) {
  console.error('[Banco de Dados] Falha ao inicializar o banco:', error);
}

// Rota de status/healthcheck da API
app.get('/', (req, res) => {
  return res.json({
    projeto: 'Corrente Solidária API',
    versao: '1.0.0',
    status: 'online',
    documentacao: {
      auth: '/api/auth (login, registro, me)',
      doacoes: '/api/doacoes',
      ranking: '/api/ranking',
      dashboard: '/api/dashboard',
      planos: '/api/planos',
      cashback: '/api/cashback',
      metas: '/api/metas',
      notificacoes: '/api/notificacoes'
    }
  });
});

app.get('/api/health', (req, res) => {
  return res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Montagem das rotas da API
app.use('/api/auth', authRoutes);
app.use('/api/doacoes', doacoesRoutes);
app.use('/api/ranking', rankingRoutes);
app.use('/api/dashboard', dashboardRoutes);
app.use('/api/planos', planosRoutes);
app.use('/api/cashback', cashbackRoutes);
app.use('/api/metas', metasRoutes);
app.use('/api/notificacoes', notificacoesRoutes);
app.use('/api/ongs', ongsRoutes);

// Tratamento de rotas inexistentes (404)
app.use((req, res) => {
  return res.status(404).json({
    sucesso: false,
    mensagem: `Rota não encontrada: ${req.method} ${req.originalUrl}`
  });
});

// Middleware global de tratamento de erros (500)
app.use((err, req, res, next) => {
  console.error('[Erro não tratado]:', err);
  return res.status(500).json({
    sucesso: false,
    mensagem: 'Ocorreu um erro interno no servidor.',
    erro: err.message
  });
});

// Inicialização do servidor HTTP
app.listen(PORT, () => {
  console.log('====================================================');
  console.log(` Corrente Solidária API rodando na porta ${PORT}`);
  console.log(` URL Local: http://localhost:${PORT}`);
  console.log('----------------------------------------------------');
  console.log(' Credenciais Demo para Testes:');
  console.log(' - Comércio: comercio@demo.com | Senha: demo123');
  console.log(' - ONG:      ong@demo.com      | Senha: demo123');
  console.log('====================================================');
});

module.exports = app;
