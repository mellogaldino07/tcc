/**
 * Middleware de Autenticação JWT
 * Valida o token Bearer no cabeçalho Authorization e anexa o usuário à requisição.
 */

const jwt = require('jsonwebtoken');
const { db } = require('../database');

function authMiddleware(req, res, next) {
  const authHeader = req.headers['authorization'] || req.headers['Authorization'];

  if (!authHeader) {
    return res.status(401).json({
      sucesso: false,
      mensagem: 'Token de autenticação não fornecido.'
    });
  }

  const parts = authHeader.split(' ');
  if (parts.length !== 2 || !/^Bearer$/i.test(parts[0])) {
    return res.status(401).json({
      sucesso: false,
      mensagem: 'Formato de token inválido. Utilize o padrão Bearer <token>.'
    });
  }

  const token = parts[1];
  const secret = process.env.JWT_SECRET || 'corrente-solidaria-secret-key-2026';

  try {
    const decoded = jwt.verify(token, secret);

    // Buscar dados atualizados do usuário no banco
    const usuario = db.prepare(`
      SELECT id, nome, email, tipo, telefone, avatar_url, ativo, criado_em, atualizado_em
      FROM usuarios
      WHERE id = ?
    `).get(decoded.id);

    if (!usuario) {
      return res.status(401).json({
        sucesso: false,
        mensagem: 'Usuário não encontrado.'
      });
    }

    if (usuario.ativo !== 1) {
      return res.status(403).json({
        sucesso: false,
        mensagem: 'Conta de usuário desativada.'
      });
    }

    // Se for comércio, anexa os dados específicos do comércio e assinatura
    if (usuario.tipo === 'comercio') {
      const comercio = db.prepare('SELECT * FROM comercios WHERE usuario_id = ?').get(usuario.id);
      usuario.comercio = comercio || null;
      req.comercio = comercio || null;

      const assinatura = db.prepare(`
        SELECT a.*, p.nome as plano_nome, p.cashback_percentual, p.max_doacoes_mes
        FROM assinaturas a
        JOIN planos p ON a.plano_id = p.id
        WHERE a.usuario_id = ? AND a.status = 'ativa'
        ORDER BY a.id DESC
        LIMIT 1
      `).get(usuario.id);
      usuario.assinatura = assinatura || null;
    }

    // Se for ONG, anexa os dados específicos da ONG
    if (usuario.tipo === 'ong') {
      const ong = db.prepare('SELECT * FROM ongs WHERE usuario_id = ?').get(usuario.id);
      usuario.ong = ong || null;
      req.ong = ong || null;
    }

    req.user = usuario;
    return next();
  } catch (error) {
    return res.status(401).json({
      sucesso: false,
      mensagem: 'Token inválido ou expirado.',
      detalhes: error.message
    });
  }
}

module.exports = authMiddleware;
